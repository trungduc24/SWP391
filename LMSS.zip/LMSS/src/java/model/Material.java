package model;

import java.sql.Timestamp;

public class Material {
    private int materialId;
    private int courseId;
    private String title;
    private String description;
    private String fileUrl;
    private Timestamp uploadedAt;

    public void setMaterialId(int materialId) {
        this.materialId = materialId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public void setUploadedAt(Timestamp uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public int getMaterialId() {
        return materialId;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public Timestamp getUploadedAt() {
        return uploadedAt;
    }

    public Material(int materialId, int courseId, String title, String description, String fileUrl, Timestamp uploadedAt) {
        this.materialId = materialId;
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.fileUrl = fileUrl;
        this.uploadedAt = uploadedAt;
    }
}