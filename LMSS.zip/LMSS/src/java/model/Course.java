package model;

public class Course {
    private int courseId;
    private String name;
    private String code;
    private String room;
    private int lecturerId;
    private int semesterId;
    private int totalSessions;

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }

    public void setTotalSessions(int totalSessions) {
        this.totalSessions = totalSessions;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getRoom() {
        return room;
    }

    public int getLecturerId() {
        return lecturerId;
    }

    public int getSemesterId() {
        return semesterId;
    }

    public int getTotalSessions() {
        return totalSessions;
    }

    public Course(int courseId, String name, String code, String room, int lecturerId, int semesterId, int totalSessions) {
        this.courseId = courseId;
        this.name = name;
        this.code = code;
        this.room = room;
        this.lecturerId = lecturerId;
        this.semesterId = semesterId;
        this.totalSessions = totalSessions;
    }

}
