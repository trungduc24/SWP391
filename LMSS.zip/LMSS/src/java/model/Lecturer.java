package model;

public class Lecturer {
    private int lecturerId;
    private int userId;
    private String fullName;
    private String email;

    // Constructor không tham số
    public Lecturer() {
    }

    // Constructor đầy đủ tham số
    public Lecturer(int lecturerId, int userId, String fullName, String email) {
        this.lecturerId = lecturerId;
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
    }

    // Getter và Setter
    public int getLecturerId() {
        return lecturerId;
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
