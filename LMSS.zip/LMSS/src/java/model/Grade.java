package model;

public class Grade {
    private int gradeId;
    private int studentId;
    private int courseId;
    private int assignmentId;
    private double score;
    private String comment;

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getGradeId() {
        return gradeId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public double getScore() {
        return score;
    }

    public String getComment() {
        return comment;
    }

    public Grade(int gradeId, int studentId, int courseId, int assignmentId, double score, String comment) {
        this.gradeId = gradeId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.assignmentId = assignmentId;
        this.score = score;
        this.comment = comment;
    }

    // Getters & Setters...
}
