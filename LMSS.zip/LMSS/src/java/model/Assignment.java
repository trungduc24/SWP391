package model;

import java.sql.Timestamp;

public class Assignment {
    private int assignmentId;
    private int courseId;
    private String title;
    private String description;
    private Timestamp dueDate;
    private String type;

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDueDate(Timestamp dueDate) {
        this.dueDate = dueDate;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Timestamp getDueDate() {
        return dueDate;
    }

    public String getType() {
        return type;
    }

    public Assignment(int assignmentId, int courseId, String title, String description, Timestamp dueDate, String type) {
        this.assignmentId = assignmentId;
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.type = type;
    }

    // Getters & Setters...
}
