// CourseDAO.java
package dao;

import java.sql.*;
import java.util.*;
import model.Course;
import utils.DBConnection;

public class CourseDAO {
    public List<Course> getAllCourses() throws Exception {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT * FROM courses";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Course c = new Course(
                    rs.getInt("course_id"),
                    rs.getString("name"),
                    rs.getString("code"),
                    rs.getString("room"),
                    rs.getInt("lecturer_id"),
                    rs.getInt("semester_id"),
                    rs.getInt("total_sessions")
                );
                list.add(c);
            }
        }
        return list;
    }
}