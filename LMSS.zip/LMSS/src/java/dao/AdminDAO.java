package dao;

import java.sql.*;
import model.Admin;
import utils.DBConnection;

public class AdminDAO {
    private Connection conn = DBConnection.getConnection();

    public boolean insertAdmin(Admin admin) throws SQLException {
        String sql = "INSERT INTO admins(user_id, full_name, email, phone, avatar_url) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, admin.getUserId());
            ps.setString(2, admin.getFullName());
            ps.setString(3, admin.getEmail());
            ps.setString(4, admin.getPhone());
            ps.setString(5, admin.getAvatarUrl());
            int affected = ps.executeUpdate();
            if (affected == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    admin.setAdminId(rs.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public Admin getAdminByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM admins WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Admin(
                    rs.getInt("admin_id"),
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("avatar_url")
                );
            }
        }
        return null;
    }

    public boolean updateAdmin(Admin admin) throws SQLException {
        String sql = "UPDATE admins SET full_name = ?, email = ?, phone = ?, avatar_url = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, admin.getFullName());
            ps.setString(2, admin.getEmail());
            ps.setString(3, admin.getPhone());
            ps.setString(4, admin.getAvatarUrl());
            ps.setInt(5, admin.getUserId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteAdminByUserId(int userId) throws SQLException {
        String sql = "DELETE FROM admins WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() == 1;
        }
    }
}
