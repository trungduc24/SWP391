package dao;

import java.sql.*;
import model.Attendance;
import utils.DBConnection;

public class AttendanceDAO {
    public void markAttendance(Attendance attendance) throws Exception {
        String sql = "INSERT INTO attendance (student_id, course_id, session_number, status, date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, attendance.getStudentId());
            ps.setInt(2, attendance.getCourseId());
            ps.setInt(3, attendance.getSessionNumber());
            ps.setString(4, attendance.getStatus());
            ps.setDate(5, attendance.getDate());
            ps.executeUpdate();
        }
    }
}
