package dao;

import java.sql.*;
import java.util.*;
import model.Material;
import utils.DBConnection;

public class MaterialDAO {
    public List<Material> getMaterialsByCourse(int courseId) throws Exception {
        List<Material> list = new ArrayList<>();
        String sql = "SELECT * FROM course_materials WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Material m = new Material(
                        rs.getInt("material_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("file_url"),
                        rs.getTimestamp("uploaded_at")
                    );
                    list.add(m);
                }
            }
        }
        return list;
    }
}
