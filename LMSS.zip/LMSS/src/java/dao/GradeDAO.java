package dao;

import model.Grade;
import utils.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GradeDAO {

    public void addGrade(int assignmentId, int studentId, double score, String comment) throws Exception {
        String sql = "INSERT INTO grades (assignment_id, student_id, score, comment) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            ps.setInt(2, studentId);
            ps.setDouble(3, score);
            ps.setString(4, comment);
            ps.executeUpdate();
        }
    }

    public List<Grade> getAllGrades() {
        List<Grade> list = new ArrayList<>();
        String sql = """
        SELECT 
            g.grade_id,
            s.full_name AS student_name,
            s.student_code,
            c.name AS course_name,
            a.title AS assignment_title,
            g.score,
            g.comment
        FROM grades g
        JOIN students s ON g.student_id = s.student_id
        JOIN assignments a ON g.assignment_id = a.assignment_id
        JOIN courses c ON a.course_id = c.course_id
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Grade grade = new Grade();
                grade.setGradeId(rs.getInt("grade_id"));
                grade.setStudentName(rs.getString("student_name"));
                grade.setStudentCode(rs.getString("student_code"));
                grade.setCourseName(rs.getString("course_name"));
                grade.setAssignmentTitle(rs.getString("assignment_title"));
                grade.setScore(rs.getDouble("score"));
                grade.setComment(rs.getString("comment"));
                list.add(grade);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

}
