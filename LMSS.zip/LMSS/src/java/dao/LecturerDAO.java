package dao;

import java.sql.*;
import model.Lecturer;
import utils.DBConnection;

public class LecturerDAO {
    private Connection conn = DBConnection.getConnection();

    public boolean insertLecturer(Lecturer lecturer) throws SQLException {
        String sql = "INSERT INTO lecturers(user_id, full_name, email) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, lecturer.getUserId());
            ps.setString(2, lecturer.getFullName());
            ps.setString(3, lecturer.getEmail());
            int affected = ps.executeUpdate();
            if (affected == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    lecturer.setLecturerId(rs.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public Lecturer getLecturerByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM lecturers WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Lecturer(
                    rs.getInt("lecturer_id"),
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email")
                );
            }
        }
        return null;
    }

    public boolean updateLecturer(Lecturer lecturer) throws SQLException {
        String sql = "UPDATE lecturers SET full_name = ?, email = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, lecturer.getFullName());
            ps.setString(2, lecturer.getEmail());
            ps.setInt(3, lecturer.getUserId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteLecturerByUserId(int userId) throws SQLException {
        String sql = "DELETE FROM lecturers WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() == 1;
        }
    }
}
