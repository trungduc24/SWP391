package dao;

import java.sql.*;
import java.util.*;
import model.Assignment;
import utils.DBConnection;

public class AssignmentDAO {
    public List<Assignment> getAssignmentsByCourse(int courseId) throws Exception {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT * FROM assignments WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Assignment a = new Assignment(
                        rs.getInt("assignment_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getTimestamp("due_date"),
                        rs.getString("type")
                    );
                    list.add(a);
                }
            }
        }
        return list;
    }
}