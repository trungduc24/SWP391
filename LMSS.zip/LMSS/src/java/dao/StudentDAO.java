package dao;

import java.sql.*;
import model.Student;
import utils.DBConnection;

public class StudentDAO {
    private Connection conn = DBConnection.getConnection();

    public boolean insertStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students(user_id, full_name, student_code, email) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, student.getUserId());
            ps.setString(2, student.getFullName());
            ps.setString(3, student.getStudentCode());
            ps.setString(4, student.getEmail());
            int affected = ps.executeUpdate();
            if (affected == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    student.setStudentId(rs.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public Student getStudentByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM students WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Student(
                    rs.getInt("student_id"),
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("student_code"),
                    rs.getString("email")
                );
            }
        }
        return null;
    }

    public boolean updateStudent(Student student) throws SQLException {
        String sql = "UPDATE students SET full_name = ?, student_code = ?, email = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, student.getFullName());
            ps.setString(2, student.getStudentCode());
            ps.setString(3, student.getEmail());
            ps.setInt(4, student.getUserId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteStudentByUserId(int userId) throws SQLException {
        String sql = "DELETE FROM students WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() == 1;
        }
    }
}
