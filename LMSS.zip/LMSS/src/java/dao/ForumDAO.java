package dao;

import java.sql.*;
import java.util.*;
import model.Forum;
import utils.DBConnection;

public class ForumDAO {
    public List<Forum> getForumsByCourse(int courseId) throws Exception {
        List<Forum> list = new ArrayList<>();
        String sql = "SELECT * FROM forums WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Forum f = new Forum(
                        rs.getInt("forum_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getInt("created_by"),
                        rs.getTimestamp("created_at")
                    );
                    list.add(f);
                }
            }
        }
        return list;
    }
}
