package dao;

import dao.GradeDAO;
import model.Grade;

import java.util.List;

public class TestGrades {
    public static void main(String[] args) {
        GradeDAO gradeDAO = new GradeDAO();
        List<Grade> grade = gradeDAO.getAllGrades();

        for (Grade g : grade) {
            System.out.println("Grade ID: " + g.getGradeId());
            System.out.println("Student: " + g.getStudentName() + " (" + g.getStudentCode() + ")");
            System.out.println("Course: " + g.getCourseName());
            System.out.println("Assignment: " + g.getAssignmentTitle());
            System.out.println("Score: " + g.getScore());
            System.out.println("Comment: " + g.getComment());
            System.out.println("----------");
        }
    }
}
