package dao;

import java.sql.*;
import java.time.LocalDateTime;
import model.User;
import utils.DBConnection;

public class UserDAO {
    private Connection conn = DBConnection.getConnection();

    public boolean insertUser(User user) throws SQLException {
        String sql = "INSERT INTO users(username, password, role, avatar_url) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getRole());
            ps.setString(4, user.getAvatarUrl());
            int affected = ps.executeUpdate();
            if (affected == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    user.setUserId(rs.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public User getUserById(int userId) throws SQLException {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role"),
                    rs.getString("avatar_url")
                );
            }
        }
        return null;
    }

    public User getUserByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role"),
                    rs.getString("avatar_url")
                );
            }
        }
        return null;
    }

    // ✅ Cập nhật cả password và avatar_url
    public boolean updateUserProfile(int userId, String hashedPassword, String avatarUrl) throws SQLException {
        String sql = "UPDATE users SET password = ?, avatar_url = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, hashedPassword);
            ps.setString(2, avatarUrl);
            ps.setInt(3, userId);
            return ps.executeUpdate() == 1;
        }
    }

    // Nếu chỉ cập nhật mật khẩu (dành cho thay đổi password đơn lẻ)
    public boolean updatePassword(int userId, String newPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, userId);
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteUser(int userId) throws SQLException {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() == 1;
        }
    }
    public boolean emailExists(String email) throws Exception {
    String sql = "SELECT 1 FROM Users WHERE username = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }
}
    public void savePasswordResetToken(String email, String token, LocalDateTime expiry) throws Exception {
    String sql = "INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.setString(2, token);
        ps.setTimestamp(3, java.sql.Timestamp.valueOf(expiry));
        ps.executeUpdate();
    }
}
    public void updateAvatarUrl(int userId, String avatarUrl) throws Exception {
    String sql = "UPDATE Users SET avatar_url = ? WHERE user_id = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, avatarUrl);
        ps.setInt(2, userId);
        ps.executeUpdate();
    }
}
  public boolean updateProfile(User user) {
    String sql = "UPDATE users SET username = ?, avatar_url = ? WHERE user_id = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
         
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getAvatarUrl());
        ps.setInt(3, user.getUserId());

        int rowsUpdated = ps.executeUpdate();
        return rowsUpdated > 0; // trả về true nếu update thành công
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}
