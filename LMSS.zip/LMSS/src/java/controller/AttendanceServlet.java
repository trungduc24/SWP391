/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.AttendanceDAO;
import model.Attendance;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;

public class AttendanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            int session = Integer.parseInt(request.getParameter("session"));
            String status = request.getParameter("status");
            Date date = Date.valueOf(request.getParameter("date"));

            Attendance attendance = new Attendance(studentId, courseId, session, status, date);
            new AttendanceDAO().markAttendance(attendance);
            response.sendRedirect("attendance.jsp");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
