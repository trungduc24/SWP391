package controller;

import dao.UsersDAO;
import utils.BCryptUtil;
import utils.EmailUtil;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.util.UUID;

public class RegisterServlet extends HttpServlet {

    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        Connection conn = DBConnection.getConnection();

        if (conn == null) {
            throw new ServletException("❌ Không thể kết nối tới cơ sở dữ liệu!");
        }

        userDAO = new UsersDAO(conn);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");
        String role = req.getParameter("role");
        String email = req.getParameter("email");
        String avatarUrl = req.getParameter("avatarUrl");
        String fullName = req.getParameter("fullName");

        // Log debug
        System.out.println("📌 Bắt đầu xử lý đăng ký: " + username);

        if (isEmpty(username) || isEmpty(password) || isEmpty(confirmPassword)
                || isEmpty(role) || isEmpty(email) || isEmpty(fullName)) {
            req.setAttribute("error", "Vui lòng nhập đầy đủ thông tin, bao gồm họ tên và email");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        if (!isValidEmail(email)) {
            req.setAttribute("error", "Email không hợp lệ");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        if (!password.equals(confirmPassword)) {
            req.setAttribute("error", "Mật khẩu xác nhận không khớp");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        try {
            if (userDAO.getUserByUsername(username) != null) {
                req.setAttribute("error", "Tên đăng nhập đã tồn tại");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
                return;
            }

            if (userDAO.isEmailExists(email)) {
                req.setAttribute("error", "Email đã được sử dụng");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
                return;
            }

            String hashedPassword = BCryptUtil.hashPassword(password);

            if (isEmpty(avatarUrl)) {
                avatarUrl = "default-avatar.png";
            }

            String token = generateToken();

            boolean created = userDAO.registerUserWithToken(
                username, hashedPassword, role, email, avatarUrl, token, fullName
            );

            if (created) {
                // Lấy link xác nhận
                String baseURL = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() + req.getContextPath();
                String verifyLink = baseURL + "/verify?token=" + token;

                try {
                    EmailUtil.sendVerificationEmail(email, username, verifyLink);
                } catch (Exception mailErr) {
                    mailErr.printStackTrace();
                    req.setAttribute("error", "Không thể gửi email xác nhận: " + mailErr.getMessage());
                    req.getRequestDispatcher("register.jsp").forward(req, resp);
                    return;
                }

                HttpSession session = req.getSession();
                session.setAttribute("message", "Đăng ký thành công! Vui lòng kiểm tra email để xác nhận tài khoản.");
                resp.sendRedirect("login.jsp");

            } else {
                req.setAttribute("error", "Đăng ký thất bại, vui lòng thử lại.");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            req.getRequestDispatcher("register.jsp").forward(req, resp);
        }
    }

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return email.matches(emailRegex);
    }

    private String generateToken() {
        return UUID.randomUUID().toString(); // Dễ đọc hơn BigInteger
    }
}
