package controller;

import dao.UserDAO;
import model.User;
import utils.BCryptUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;


public class RegisterServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("register.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");
        String role = req.getParameter("role");
        String avatarUrl = req.getParameter("avatarUrl");

        // Kiểm tra input rỗng
        if (isEmpty(username) || isEmpty(password) || isEmpty(confirmPassword) || isEmpty(role)) {
            req.setAttribute("error", "Vui lòng nhập đầy đủ thông tin");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        // Kiểm tra xác nhận mật khẩu
        if (!password.equals(confirmPassword)) {
            req.setAttribute("error", "Mật khẩu xác nhận không khớp");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
            return;
        }

        try {
            // Kiểm tra username đã tồn tại
            if (userDAO.getUserByUsername(username) != null) {
                req.setAttribute("error", "Tên đăng nhập đã tồn tại");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
                return;
            }

            // Hash mật khẩu
            String hashedPassword = BCryptUtil.hashPassword(password);
            if (isEmpty(avatarUrl)) {
                avatarUrl = "default-avatar.png";
            }

            User newUser = new User(0, username, hashedPassword, role, avatarUrl);
            boolean created = userDAO.insertUser(newUser);

            if (created) {
                resp.sendRedirect(req.getContextPath() + "/login.jsp");
                return;
            } else {
                req.setAttribute("error", "Đăng ký thất bại, vui lòng thử lại");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            req.getRequestDispatcher("register.jsp").forward(req, resp);
        }
    }

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
