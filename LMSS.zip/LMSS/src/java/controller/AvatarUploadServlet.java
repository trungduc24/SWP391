package controller;

import dao.UserDAO;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024, // 1MB
    maxFileSize = 5 * 1024 * 1024,   // 5MB
    maxRequestSize = 6 * 1024 * 1024 // 6MB
)
public class AvatarUploadServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    // Đường dẫn thư mục lưu ảnh trên server (thư mục trong project, có thể là ngoài webapp)
    private static final String UPLOAD_DIR = "uploads/avatars";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Lấy user từ session
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");

        // Thư mục lưu file tuyệt đối trên server
        String applicationPath = req.getServletContext().getRealPath("");
        String uploadPath = applicationPath + File.separator + UPLOAD_DIR;

        // Tạo thư mục nếu chưa tồn tại
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        try {
            Part filePart = req.getPart("avatar"); // "avatar" là name của input file
            if (filePart == null || filePart.getSize() == 0) {
                resp.sendRedirect(req.getContextPath() + "/profile.jsp?error=No file selected");
                return;
            }

            // Lấy tên file gốc
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

            // Tạo tên file mới tránh trùng lặp
            String fileExt = "";
            int i = fileName.lastIndexOf('.');
            if (i > 0) {
                fileExt = fileName.substring(i);
            }
            String newFileName = UUID.randomUUID().toString() + fileExt;

            // Đường dẫn file lưu trên server
            String filePath = uploadPath + File.separator + newFileName;

            // Lưu file
            filePart.write(filePath);

            // Đường dẫn lưu trong database (dùng đường dẫn tương đối từ context root)
            String avatarUrl = "/" + UPLOAD_DIR + "/" + newFileName;

            // Cập nhật avatar trong DB
            userDAO.updateAvatarUrl(user.getUserId(), avatarUrl);

            // Cập nhật user trong session
            user.setAvatarUrl(avatarUrl);
            session.setAttribute("user", user);

            resp.sendRedirect(req.getContextPath() + "/profile.jsp?success=Avatar updated");
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath() + "/profile.jsp?error=Upload failed");
        }
    }
}
