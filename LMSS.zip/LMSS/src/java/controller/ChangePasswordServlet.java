package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.User;
import dao.UserDAO;
import utils.BCryptUtil;

import java.io.IOException;

public class ChangePasswordServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Hiển thị trang đổi mật khẩu
        req.getRequestDispatcher("/change-password.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Lấy người dùng từ session
        HttpSession session = req.getSession(false);
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login.html?error=Please login first");
            return;
        }

        // Lấy thông tin từ form
        String currentPassword = req.getParameter("currentPassword");
        String newPassword = req.getParameter("newPassword");
        String confirmPassword = req.getParameter("confirmPassword");

        // Kiểm tra dữ liệu đầu vào
        if (currentPassword == null || newPassword == null || confirmPassword == null ||
            currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            resp.sendRedirect("change-password.jsp?error=Please fill all fields");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            resp.sendRedirect("change-password.jsp?error=New passwords do not match");
            return;
        }

        // Kiểm tra mật khẩu hiện tại
        if (!BCryptUtil.checkPassword(currentPassword, currentUser.getPassword())) {
            resp.sendRedirect("change-password.jsp?error=Current password is incorrect");
            return;
        }

        try {
            // Mã hóa và cập nhật mật khẩu mới
            String hashedPassword = BCryptUtil.hashPassword(newPassword);
            boolean updated = userDAO.updatePassword(currentUser.getUserId(), hashedPassword);

            if (updated) {
                // Cập nhật mật khẩu trong session
                currentUser.setPassword(hashedPassword);
                session.setAttribute("user", currentUser);

                resp.sendRedirect("change-password.jsp?success=Password updated successfully");
            } else {
                resp.sendRedirect("change-password.jsp?error=Failed to update password");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("change-password.jsp?error=Internal server error");
        }
    }
}
