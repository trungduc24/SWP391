package controller;

import dao.UserDAO;
import model.User;
import utils.BCryptUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;


@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // giới hạn 5MB
public class ProfileServlet extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");
        req.setAttribute("user", user);
        req.getRequestDispatcher("/profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        User currentUser = (User) session.getAttribute("user");

        String newPassword = req.getParameter("password");

        try {
            // Xử lý mật khẩu mới
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                String hashedPassword = BCryptUtil.hashPassword(newPassword);
                currentUser.setPassword(hashedPassword);
            }

            // Xử lý file upload avatar
            Part filePart = req.getPart("avatar");
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = extractFileName(filePart);
                // Đổi tên file hoặc tạo tên file duy nhất, ví dụ theo userId
                String savedFileName = "avatar_" + currentUser.getUserId() + fileName.substring(fileName.lastIndexOf('.'));
                // Đường dẫn lưu file (thư mục trong dự án hoặc ổ cứng server)
                String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) uploadDir.mkdir();

                String filePath = uploadPath + File.separator + savedFileName;
                filePart.write(filePath);

                // Cập nhật URL avatar (tùy theo cấu trúc web của bạn)
                String avatarUrl = req.getContextPath() + "/uploads/" + savedFileName;
                // Giả sử User class có trường avatarUrl, bạn thêm getter/setter tương ứng
                currentUser.setAvatarUrl(avatarUrl);
            }

            // Cập nhật password và avatar trong DB
            boolean updated = userDAO.updatePassword(currentUser.getUserId(), currentUser.getPassword());
            // Nếu avatarUrl lưu trong DB thì update thêm (cần hàm update khác hoặc mở rộng updatePassword)

            if (updated) {
                session.setAttribute("user", currentUser);
                req.setAttribute("message", "Cập nhật hồ sơ thành công!");
            } else {
                req.setAttribute("error", "Cập nhật hồ sơ thất bại!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống, vui lòng thử lại.");
        }

        req.setAttribute("user", currentUser);
        req.getRequestDispatcher("/profile.jsp").forward(req, resp);
    }

    // Hàm tách tên file từ Part header
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return "";
    }
}
