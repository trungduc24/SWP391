package controller;

import dao.UserDAO;
import model.User;
import utils.BCryptUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;


public class LoginServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("login.jsp");
        System.out.println("Hello");
    }
    @Override
   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String username = req.getParameter("username");
    String password = req.getParameter("password");
    String roleInput = req.getParameter("role");
    
    try {
        User user = userDAO.getUserByUsername(username);

        if (user == null) {
            req.setAttribute("error", "Tên đăng nhập không tồn tại.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        String userRole = user.getRole().toLowerCase().trim();
        boolean passwordMatches = BCryptUtil.checkPassword(password, user.getPassword());
        boolean roleMatches = roleInput != null && roleInput.equalsIgnoreCase(userRole);

        System.out.println(">>> Login attempt: username=" + username + ", roleInput=" + roleInput + ", userRole=" + userRole);

        if (!passwordMatches) {
            req.setAttribute("error", "Mật khẩu không đúng.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        if (!roleMatches) {
            req.setAttribute("error", "Vai trò không đúng.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        // Nếu hợp lệ
        HttpSession session = req.getSession();
        session.setAttribute("user", user);

        System.out.println(">>> Login success for user: " + username + ", role: " + userRole);

        switch (userRole) {
            case "student":
                resp.sendRedirect(req.getContextPath() + "/student/dashboard.html");
                break;
            case "lecturer":
                resp.sendRedirect(req.getContextPath() + "/lecturer/dashboard.html");
                break;
            case "admin":
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard.html");
                break;
            default:
                req.setAttribute("error", "Vai trò không hợp lệ.");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
                break;
        }

    } catch (SQLException e) {
        e.printStackTrace();
        req.setAttribute("error", "Lỗi cơ sở dữ liệu.");
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    } catch (Exception e) {
        e.printStackTrace();
        req.setAttribute("error", "Lỗi hệ thống.");
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }
}
}