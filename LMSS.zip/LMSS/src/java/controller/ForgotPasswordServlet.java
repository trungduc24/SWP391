package controller;

import dao.UserDAO;
import utils.EmailUtil;
import utils.TokenUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDateTime;


public class ForgotPasswordServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/forgot-password.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");

        try {
            // Kiểm tra email có tồn tại không
            if (!userDAO.emailExists(email)) {
                resp.sendRedirect("forgot-password.jsp?error=Email not found");
                return;
            }

            // Tạo token reset và lưu
            String token = TokenUtil.generateToken();
            LocalDateTime expiry = LocalDateTime.now().plusMinutes(15); // Hết hạn sau 15 phút
            userDAO.savePasswordResetToken(email, token, expiry);

            // Gửi email reset
            String resetLink = req.getRequestURL().toString().replace("forgot-password", "reset-password") + "?token=" + token;
            String subject = "LMS - Reset Your Password";
            String content = "Click the link below to reset your password:\n\n" + resetLink + "\n\nLink expires in 15 minutes.";

            EmailUtil.sendEmail(email, subject, content);

            resp.sendRedirect("forgot-password.jsp?success=Reset link has been sent to your email");
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("forgot-password.jsp?error=Internal server error");
        }
    }
}
