package controller;

import dao.UserDAO;
import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.File;
import java.io.IOException;


@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB max
public class EditProfileServlet extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.html");
            return;
        }
        User user = (User) session.getAttribute("user");
        req.setAttribute("user", user);
        req.getRequestDispatcher("/edit-profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.html");
            return;
        }

        User currentUser = (User) session.getAttribute("user");

        String newUsername = req.getParameter("username");

        try {
            if (newUsername != null && !newUsername.trim().isEmpty()) {
                currentUser.setUsername(newUsername.trim());
            }

            // Xử lý file upload avatar
            Part filePart = req.getPart("avatar");
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = extractFileName(filePart);
                String ext = fileName.substring(fileName.lastIndexOf('.'));
                String savedFileName = "avatar_" + currentUser.getUserId() + ext;

                String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) uploadDir.mkdir();

                String filePath = uploadPath + File.separator + savedFileName;
                filePart.write(filePath);

                String avatarUrl = req.getContextPath() + "/uploads/" + savedFileName;
                currentUser.setAvatarUrl(avatarUrl);
            }

            // Cập nhật database
            boolean updated = userDAO.updateProfile(currentUser);

            if (updated) {
                session.setAttribute("user", currentUser);
                req.setAttribute("message", "Cập nhật hồ sơ thành công!");
            } else {
                req.setAttribute("error", "Cập nhật hồ sơ thất bại!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống, vui lòng thử lại.");
        }

        req.setAttribute("user", currentUser);
        req.getRequestDispatcher("/edit-profile.jsp").forward(req, resp);
    }

    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        for (String token : contentDisp.split(";")) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return "";
    }
}
