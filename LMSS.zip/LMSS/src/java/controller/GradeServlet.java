package controller;

import dao.GradeDAO;
import model.Grade;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/grades")
public class GradeServlet extends HttpServlet {
    private GradeDAO gradeDAO;

    @Override
    public void init() {
        gradeDAO = new GradeDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Lấy danh sách điểm từ DB
        List<Grade> grades = gradeDAO.getAllGrades();

        // Gửi danh sách sang JSP
        req.setAttribute("grades", grades);

        // Forward tới đúng file JSP nằm trong thư mục /admin
        req.getRequestDispatcher("/admin/grades.jsp").forward(req, resp);
    }
}
