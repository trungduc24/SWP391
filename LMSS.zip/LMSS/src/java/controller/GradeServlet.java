package controller;

import dao.GradeDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class GradeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            double score = Double.parseDouble(request.getParameter("score"));
            String comment = request.getParameter("comment");

            new GradeDAO().addGrade(assignmentId, studentId, score, comment);
            response.sendRedirect("grading.jsp");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}