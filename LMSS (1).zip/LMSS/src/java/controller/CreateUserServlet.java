package controller;

import dao.UsersDAO;
import utils.BCryptUtil;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.logging.Level;
import model.User;

public class CreateUserServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(CreateUserServlet.class.getName());
    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        Connection conn = DBConnection.getConnection();
        if (conn == null) {
            throw new ServletException("❌ Không thể kết nối tới cơ sở dữ liệu!");
        }
        userDAO = new UsersDAO(conn);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra đăng nhập và quyền admin
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        // Lấy thông tin từ form
        String username = req.getParameter("username");
        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        String avatarUrl = req.getParameter("avatarUrl");

        if (avatarUrl == null || avatarUrl.trim().isEmpty()) {
            avatarUrl = "default-avatar.png";
        }

        try {
            // Kiểm tra username và email đã tồn tại chưa
            if (userDAO.getUserByUsername(username) != null) {
                req.setAttribute("error", "Tên đăng nhập đã tồn tại");
                req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
                return;
            }

            if (userDAO.isEmailExists(email)) {
                req.setAttribute("error", "Email đã được sử dụng");
                req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
                return;
            }

            // Mã hóa mật khẩu
            String hashedPassword = BCryptUtil.hashPassword(password);

            // Tạo token xác thực email
            String token = UUID.randomUUID().toString();

            // Thêm người dùng vào CSDL
            boolean created = userDAO.registerUserWithToken(
                    username, hashedPassword, role, email, avatarUrl, token, fullName);

            if (created) {
                // Đánh dấu người dùng đã được xác thực (do admin tạo)
                userDAO.verifyEmail(token);

                // Thông báo thành công
                session.setAttribute("message", "Đã tạo người dùng mới thành công!");
                resp.sendRedirect(req.getContextPath() + "/admin/users.jsp");
            } else {
                req.setAttribute("error", "Không thể tạo người dùng mới");
                req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        User currentUser = (User) req.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền tạo người dùng!");
            return;
        }

        // Hiển thị form tạo user
        req.getRequestDispatcher("/admin/create-user.jsp").forward(req, resp);
    }

    /**
     * Ghi log tạo user
     */
    private void logUserCreation(int adminId, String newUsername, String role, String ip, String userAgent) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO system_logs (user_id, action, table_name, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?)";
            try (var stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, adminId);
                stmt.setString(2, "CREATE_USER");
                stmt.setString(3, "users");
                stmt.setString(4, "Created user: " + newUsername + " with role: " + role);
                stmt.setString(5, ip);
                stmt.setString(6, userAgent);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to log user creation", e);
        }
    }

    /**
     * Lấy IP của client
     */
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }

        String xRealIP = request.getHeader("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }

        return request.getRemoteAddr();
    }
}