package controller;

import dao.CourseDAO;
import model.Course;
import model.User;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.util.logging.Level;

public class SearchCourseServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(SearchCourseServlet.class.getName());
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            logger.info("SearchCourseServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize SearchCourseServlet", e);
            throw new ServletException("Failed to initialize SearchCourseServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra đăng nhập
        User currentUser = (User) req.getAttribute("currentUser");
        if (currentUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String query = req.getParameter("q");
        String semester = req.getParameter("semester");
        String lecturer = req.getParameter("lecturer");
        String format = req.getParameter("format"); // json hoặc html

        try {
            List<Course> courses;

            if (query != null && !query.trim().isEmpty()) {
                // Tìm kiếm theo từ khóa
                courses = searchCourses(query.trim(), semester, lecturer);
            } else {
                // Lấy tất cả khóa học nếu không có từ khóa
                courses = courseDAO.getAllCourses();
            }

            // Trả về JSON nếu được yêu cầu (cho AJAX)
            if ("json".equals(format)) {
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write(convertCoursesToJson(courses));
                return;
            }

            // Trả về HTML (trang thường)
            req.setAttribute("courses", courses);
            req.setAttribute("searchQuery", query);
            req.setAttribute("selectedSemester", semester);
            req.setAttribute("selectedLecturer", lecturer);

            // Forward đến trang kết quả tìm kiếm theo role
            String forwardPage = getSearchResultPage(currentUser.getRole());
            req.getRequestDispatcher(forwardPage).forward(req, resp);

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while searching courses", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi cơ sở dữ liệu!");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error while searching courses", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi hệ thống!");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    /**
     * Tìm kiếm khóa học theo từ khóa và bộ lọc
     */
    private List<Course> searchCourses(String query, String semester, String lecturer) throws SQLException {
        List<Course> courses = new ArrayList<>();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT c.course_id, c.name, c.code, c.description, c.room, ");
        sql.append("c.lecturer_id, c.semester_id, c.total_sessions, c.credits, c.max_students, ");
        sql.append("c.is_active, c.created_at, l.full_name as lecturer_name, s.name as semester_name ");
        sql.append("FROM courses c ");
        sql.append("INNER JOIN lecturers l ON c.lecturer_id = l.lecturer_id ");
        sql.append("INNER JOIN semesters s ON c.semester_id = s.semester_id ");
        sql.append("WHERE c.is_active = 1 ");

        List<Object> params = new ArrayList<>();

        // Tìm kiếm theo tên hoặc mã khóa học
        if (query != null && !query.trim().isEmpty()) {
            sql.append("AND (c.name LIKE ? OR c.code LIKE ? OR c.description LIKE ?) ");
            String searchPattern = "%" + query + "%";
            params.add(searchPattern);
            params.add(searchPattern);
            params.add(searchPattern);
        }

        // Lọc theo học kỳ
        if (semester != null && !semester.trim().isEmpty()) {
            try {
                int semesterId = Integer.parseInt(semester);
                sql.append("AND c.semester_id = ? ");
                params.add(semesterId);
            } catch (NumberFormatException e) {
                // Ignore invalid semester ID
            }
        }

        // Lọc theo giảng viên
        if (lecturer != null && !lecturer.trim().isEmpty()) {
            try {
                int lecturerId = Integer.parseInt(lecturer);
                sql.append("AND c.lecturer_id = ? ");
                params.add(lecturerId);
            } catch (NumberFormatException e) {
                // Ignore invalid lecturer ID
            }
        }

        sql.append("ORDER BY c.created_at DESC");

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            // Set parameters
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course(
                            rs.getInt("course_id"),
                            rs.getString("name"),
                            rs.getString("code"),
                            rs.getString("room"),
                            rs.getInt("lecturer_id"),
                            rs.getInt("semester_id"),
                            rs.getInt("total_sessions"));
                    course.setDescription(rs.getString("description"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setActive(rs.getBoolean("is_active"));
                    course.setCreatedAt(rs.getTimestamp("created_at"));

                    courses.add(course);
                }
            }
        }

        return courses;
    }

    /**
     * Chuyển đổi danh sách khóa học thành JSON
     */
    private String convertCoursesToJson(List<Course> courses) {
        StringBuilder json = new StringBuilder();
        json.append("{\"courses\": [");

        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            if (i > 0)
                json.append(",");

            json.append("{");
            json.append("\"id\": ").append(course.getCourseId()).append(",");
            json.append("\"name\": \"").append(escapeJson(course.getName())).append("\",");
            json.append("\"code\": \"").append(escapeJson(course.getCode())).append("\",");
            json.append("\"description\": \"").append(escapeJson(course.getDescription())).append("\",");
            json.append("\"room\": \"").append(escapeJson(course.getRoom())).append("\",");
            json.append("\"lecturerId\": ").append(course.getLecturerId()).append(",");
            json.append("\"semesterId\": ").append(course.getSemesterId()).append(",");
            json.append("\"totalSessions\": ").append(course.getTotalSessions()).append(",");
            json.append("\"credits\": ").append(course.getCredits()).append(",");
            json.append("\"maxStudents\": ").append(course.getMaxStudents());
            json.append("}");
        }

        json.append("], \"total\": ").append(courses.size()).append("}");
        return json.toString();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null)
            return "";
        return str.replace("\"", "\\\"")
                .replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    /**
     * Lấy trang kết quả tìm kiếm theo role
     */
    private String getSearchResultPage(String role) {
        switch (role) {
            case "admin":
                return "/admin/search-results.jsp";
            case "lecturer":
                return "/lecturer/search-results.jsp";
            case "student":
                return "/student/search-results.jsp";
            default:
                return "/search-results.jsp";
        }
    }
}
