package controller;

import dao.UsersDAO;
import dao.StudentDAO;
import dao.LecturerDAO;
import model.User;
import model.Student;
import model.Lecturer;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class AdminUserServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AdminUserServlet.class.getName());
    private StudentDAO studentDAO;
    private LecturerDAO lecturerDAO;

    @Override
    public void init() throws ServletException {
        try {
            studentDAO = new StudentDAO();
            lecturerDAO = new LecturerDAO();
            logger.info("AdminUserServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize AdminUserServlet", e);
            throw new ServletException("Failed to initialize AdminUserServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Kiểm tra quyền admin
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null)
            action = "list";

        try {
            Connection conn = DBConnection.getConnection();
            UsersDAO usersDAO = new UsersDAO(conn);

            switch (action) {
                case "list":
                    listUsers(request, response, usersDAO);
                    break;
                case "create":
                    showCreateForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response, usersDAO);
                    break;
                case "view":
                    viewUser(request, response, usersDAO);
                    break;
                default:
                    listUsers(request, response, usersDAO);
                    break;
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminUserServlet", e);
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Kiểm tra quyền admin
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null)
            action = "list";

        try {
            Connection conn = DBConnection.getConnection();
            UsersDAO usersDAO = new UsersDAO(conn);

            switch (action) {
                case "create":
                    createUser(request, response, usersDAO);
                    break;
                case "update":
                    updateUser(request, response, usersDAO);
                    break;
                case "delete":
                    deleteUser(request, response, usersDAO);
                    break;
                default:
                    listUsers(request, response, usersDAO);
                    break;
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminUserServlet POST", e);
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }

    private void listUsers(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        // Lấy danh sách tất cả users
        List<User> users = usersDAO.getAllUsers();
        request.setAttribute("users", users);

        // Lấy danh sách students
        List<Student> students = studentDAO.getAllStudents();
        request.setAttribute("students", students);

        // Lấy danh sách lecturers
        List<Lecturer> lecturers = lecturerDAO.getAllLecturers();
        request.setAttribute("lecturers", lecturers);

        // Forward đến JSP
        request.getRequestDispatcher("/admin/users.jsp").forward(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/admin/create-user.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        String userIdStr = request.getParameter("id");
        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);
            User user = usersDAO.getUserById(userId);

            if (user == null) {
                response.sendRedirect(request.getContextPath() + "/admin/users?error=user_not_found");
                return;
            }

            request.setAttribute("user", user);
            request.getRequestDispatcher("/admin/edit-user.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
        }
    }

    private void viewUser(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        String userIdStr = request.getParameter("id");
        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);
            User user = usersDAO.getUserById(userId);

            if (user == null) {
                response.sendRedirect(request.getContextPath() + "/admin/users?error=user_not_found");
                return;
            }

            request.setAttribute("user", user);

            // Lấy thông tin chi tiết theo role
            if ("student".equals(user.getRole())) {
                Student student = studentDAO.getStudentByUserId(userId);
                request.setAttribute("student", student);
            } else if ("lecturer".equals(user.getRole())) {
                Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
                request.setAttribute("lecturer", lecturer);
            }

            request.getRequestDispatcher("/admin/view-user.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
        }
    }

    private void createUser(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        // Lấy thông tin từ form
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String email = request.getParameter("email");
        String fullName = request.getParameter("fullName");

        // Validation
        if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty() ||
                role == null || role.trim().isEmpty() ||
                email == null || email.trim().isEmpty()) {

            request.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc");
            request.getRequestDispatcher("/admin/create-user.jsp").forward(request, response);
            return;
        }

        try {
            // Kiểm tra username đã tồn tại
            if (usersDAO.getUserByUsername(username) != null) {
                request.setAttribute("error", "Tên đăng nhập đã tồn tại");
                request.getRequestDispatcher("/admin/create-user.jsp").forward(request, response);
                return;
            }

            // Tạo user mới
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password); // TODO: Hash password
            newUser.setRole(role);
            newUser.setEmail(email);
            newUser.setFullName(fullName);
            newUser.setActive(true);

            boolean success = usersDAO.insertUser(newUser);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/users?success=user_created");
            } else {
                request.setAttribute("error", "Không thể tạo người dùng");
                request.getRequestDispatcher("/admin/create-user.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error creating user", e);
            request.setAttribute("error", "Lỗi database: " + e.getMessage());
            request.getRequestDispatcher("/admin/create-user.jsp").forward(request, response);
        }
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        String userIdStr = request.getParameter("userId");
        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);

            // Lấy thông tin từ form
            String username = request.getParameter("username");
            String role = request.getParameter("role");
            String email = request.getParameter("email");
            String fullName = request.getParameter("fullName");
            String isActiveStr = request.getParameter("isActive");

            // Validation
            if (username == null || username.trim().isEmpty() ||
                    role == null || role.trim().isEmpty() ||
                    email == null || email.trim().isEmpty()) {

                request.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc");
                User user = usersDAO.getUserById(userId);
                request.setAttribute("user", user);
                request.getRequestDispatcher("/admin/edit-user.jsp").forward(request, response);
                return;
            }

            // Lấy user hiện tại
            User user = usersDAO.getUserById(userId);
            if (user == null) {
                response.sendRedirect(request.getContextPath() + "/admin/users?error=user_not_found");
                return;
            }

            // Cập nhật thông tin
            user.setUsername(username);
            user.setRole(role);
            user.setEmail(email);
            user.setFullName(fullName);
            user.setActive("on".equals(isActiveStr));

            boolean success = usersDAO.updateUser(user);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/users?success=user_updated");
            } else {
                request.setAttribute("error", "Không thể cập nhật người dùng");
                request.setAttribute("user", user);
                request.getRequestDispatcher("/admin/edit-user.jsp").forward(request, response);
            }

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating user", e);
            response.sendRedirect(request.getContextPath() + "/admin/users?error=database_error");
        }
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response, UsersDAO usersDAO)
            throws ServletException, IOException, SQLException {

        String userIdStr = request.getParameter("userId");
        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);

            // Kiểm tra user tồn tại
            User user = usersDAO.getUserById(userId);
            if (user == null) {
                response.sendRedirect(request.getContextPath() + "/admin/users?error=user_not_found");
                return;
            }

            // Không cho phép xóa admin cuối cùng
            if ("admin".equals(user.getRole())) {
                List<User> admins = usersDAO.getUsersByRole("admin");
                if (admins.size() <= 1) {
                    response.sendRedirect(request.getContextPath() + "/admin/users?error=cannot_delete_last_admin");
                    return;
                }
            }

            boolean success = usersDAO.deleteUser(userId);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/users?success=user_deleted");
            } else {
                response.sendRedirect(request.getContextPath() + "/admin/users?error=delete_failed");
            }

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/users?error=invalid_id");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error deleting user", e);
            response.sendRedirect(request.getContextPath() + "/admin/users?error=database_error");
        }
    }
}
