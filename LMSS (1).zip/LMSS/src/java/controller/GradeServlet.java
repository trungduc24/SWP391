package controller;

import dao.GradeDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.Grade;

import java.io.IOException;

public class GradeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            double score = Double.parseDouble(request.getParameter("score"));
            String comment = request.getParameter("comment");

            Grade grade = new Grade();
            grade.setTestId(assignmentId); 
            grade.setStudentId(studentId);
            grade.setScore(score);
            grade.setFeedback(comment);
            grade.setGradedBy(1);

            GradeDAO gradeDAO = new GradeDAO();
            int gradeId = gradeDAO.addGrade(grade);

            if (gradeId > 0) {
                response.sendRedirect("grading.jsp?success=true");
            } else {
                response.sendRedirect("grading.jsp?error=add_failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("grading.jsp?error=exception");
        }
    }
}
