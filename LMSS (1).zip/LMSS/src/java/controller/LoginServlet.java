package controller;

import dao.UsersDAO;
import dao.LecturerDAO;
import model.User;
import model.Lecturer;
import utils.BCryptUtil;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;
import java.util.logging.Level;

public class LoginServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(LoginServlet.class.getName());
    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        Connection conn = DBConnection.getConnection();
        userDAO = new UsersDAO(conn);
        logger.info("LoginServlet initialized successfully");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("login.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final String LOGIN_PAGE = "/login.jsp";

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String roleInput = req.getParameter("role");

        try {
            User user = userDAO.getUserByUsername(username);

            if (user == null) {
                req.setAttribute("error", "Tên đăng nhập không tồn tại.");
                req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
                return;
            }

            String userRole = user.getRole() != null ? user.getRole().trim().toLowerCase() : "";
            boolean passwordMatches = false;
            String storedPassword = user.getPassword();

            if (storedPassword != null) {
                if (storedPassword.startsWith("$2a$")) {
                    passwordMatches = BCryptUtil.checkPassword(password, storedPassword);
                } else {
                    passwordMatches = password.equals(storedPassword);
                }
            }

            boolean roleMatches = roleInput != null && roleInput.trim().equalsIgnoreCase(userRole);

            if (!passwordMatches) {
                req.setAttribute("error", "Mật khẩu không đúng.");
                req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
                return;
            }

            if (!roleMatches) {
                req.setAttribute("error", "Vai trò không đúng.");
                req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
                return;
            }

            if (!user.isEmailVerified()) {
                req.setAttribute("error", "Email chưa được xác thực. Vui lòng kiểm tra hộp thư.");
                req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
                return;
            }

            HttpSession session = req.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getUserId());

            switch (userRole) {
                case "student":
                    resp.sendRedirect(req.getContextPath() + "/student/dashboard.jsp");
                    break;
                case "lecturer": {
                    LecturerDAO lecturerDAO = new LecturerDAO();
                    Lecturer lecturer = lecturerDAO.getLecturerByUserId(user.getUserId());
                    if (lecturer != null) {
                        session.setAttribute("lecturer", lecturer);
                    }
                    resp.sendRedirect(req.getContextPath() + "/lecturer/dashboard");
                    break;
                }
                case "admin":
                    resp.sendRedirect(req.getContextPath() + "/courses");
                    break;
                default:
                    req.setAttribute("error", "Vai trò không hợp lệ.");
                    req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
                    break;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi cơ sở dữ liệu.");
            req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống.");
            req.getRequestDispatcher(LOGIN_PAGE).forward(req, resp);
        }
    }
} 
