package controller;

import dao.AssignmentDAO;
import dao.CourseDAO;
import dao.LecturerDAO;
import model.Assignment;
import model.Course;
import model.Lecturer;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

public class LecturerAssignmentServlet extends HttpServlet {

    private AssignmentDAO assignmentDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;

    @Override
    public void init() throws ServletException {
        assignmentDAO = new AssignmentDAO();
        courseDAO = new CourseDAO();
        lecturerDAO = new LecturerDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
//        if (session.getAttribute("user") == null || !"lecturer".equals(session.getAttribute("role"))) {
//            response.sendRedirect(request.getContextPath() + "/login");
//            return;
//        }

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "create":
                    showCreateForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteAssignment(request, response);
                    break;
                case "view":
                    viewAssignment(request, response);
                    break;
                default:
                    listAssignments(request, response);
                    break;
            }
        } catch (Exception ex) {
            request.setAttribute("errorMessage", "Error: " + ex.getMessage());
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        if (session.getAttribute("user") == null || !"lecturer".equals(session.getAttribute("role"))) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "create":
                    createAssignment(request, response);
                    break;
                case "update":
                    updateAssignment(request, response);
                    break;
                default:
                    listAssignments(request, response);
                    break;
            }
        } catch (Exception ex) {
            request.setAttribute("errorMessage", "Error: " + ex.getMessage());
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
        }
    }

    private void listAssignments(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        // Filter by course if courseId is provided
        String courseIdParam = request.getParameter("courseId");
        
        List<Assignment> assignments;
        if (courseIdParam != null && !courseIdParam.isEmpty()) {
            int courseId = Integer.parseInt(courseIdParam);
            Course course = courseDAO.getCourseById(courseId);
            
            // Verify lecturer has access to this course
            if (course.getLecturerId() != lecturer.getLecturerId()) {
                request.setAttribute("errorMessage", "You don't have permission to access this course.");
                request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
                return;
            }
            
            assignments = assignmentDAO.getAssignmentsByCourse(courseId);
            request.setAttribute("courseId", courseId);
            request.setAttribute("courseName", course.getName());
        } else {
            // Get all assignments for the lecturer's courses
            assignments = assignmentDAO.getAssignmentsByLecturerId(1);
        }
        
        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(1);
        
        request.setAttribute("assignments", assignments);
        request.setAttribute("courses", courses);
        request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        // Pre-select course if courseId is provided
        String courseIdParam = request.getParameter("courseId");
        if (courseIdParam != null && !courseIdParam.isEmpty()) {
            int courseId = Integer.parseInt(courseIdParam);
            request.setAttribute("courseId", courseId);
        }
        
        request.setAttribute("courses", courses);
        request.getRequestDispatcher("/lecturer/assignment-form.jsp").forward(request, response);
    }

    private void createAssignment(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        
        // Verify lecturer has access to this course
        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.setAttribute("errorMessage", "You don't have permission to access this course.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String dueDateStr = request.getParameter("dueDate");
        String type = request.getParameter("type");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        java.util.Date parsedDate = dateFormat.parse(dueDateStr);
        Timestamp dueDate = new Timestamp(parsedDate.getTime());
        
        Assignment assignment = new Assignment(0, courseId, title, description, dueDate, type);
        assignmentDAO.createAssignment(assignment);
        
        response.sendRedirect(request.getContextPath() + "/lecturer/assignments?courseId=" + courseId);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        int assignmentId = Integer.parseInt(request.getParameter("id"));
        Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
        
        if (assignment == null) {
            request.setAttribute("errorMessage", "Assignment not found.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        // Verify lecturer has access to this course
        Course course = courseDAO.getCourseById(assignment.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.setAttribute("errorMessage", "You don't have permission to access this assignment.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("assignment", assignment);
        request.setAttribute("courses", courses);
        request.getRequestDispatcher("/lecturer/assignment-form.jsp").forward(request, response);
    }

    private void updateAssignment(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        
        // Verify lecturer has access to this course
        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.setAttribute("errorMessage", "You don't have permission to access this course.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String dueDateStr = request.getParameter("dueDate");
        String type = request.getParameter("type");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        java.util.Date parsedDate = dateFormat.parse(dueDateStr);
        Timestamp dueDate = new Timestamp(parsedDate.getTime());
        
        Assignment assignment = new Assignment(assignmentId, courseId, title, description, dueDate, type);
        assignmentDAO.updateAssignment(assignment);
        
        response.sendRedirect(request.getContextPath() + "/lecturer/assignments?courseId=" + courseId);
    }

    private void deleteAssignment(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        int assignmentId = Integer.parseInt(request.getParameter("id"));
        Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
        
        if (assignment == null) {
            request.setAttribute("errorMessage", "Assignment not found.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        // Verify lecturer has access to this course
        Course course = courseDAO.getCourseById(assignment.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.setAttribute("errorMessage", "You don't have permission to access this assignment.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        assignmentDAO.deleteAssignment(assignmentId);
        
        response.sendRedirect(request.getContextPath() + "/lecturer/assignments?courseId=" + assignment.getCourseId());
    }

    private void viewAssignment(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(userId);
        
        int assignmentId = Integer.parseInt(request.getParameter("id"));
        Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
        
        if (assignment == null) {
            request.setAttribute("errorMessage", "Assignment not found.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        // Verify lecturer has access to this course
        Course course = courseDAO.getCourseById(assignment.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.setAttribute("errorMessage", "You don't have permission to access this assignment.");
            request.getRequestDispatcher("/lecturer/assignments-content.jsp").forward(request, response);
            return;
        }
        
        request.setAttribute("assignment", assignment);
        request.setAttribute("course", course);
        request.getRequestDispatcher("/lecturer/assignment-view.jsp").forward(request, response);
    }
} 