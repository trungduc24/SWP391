package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerServlet is the main servlet for lecturer functionality.
 * It handles routing to specific lecturer servlets based on the request URL.
 */
@MultipartConfig
public class LecturerServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerServlet.class.getName());
    private LecturerDAO lecturerDAO;
    private CourseDAO courseDAO;
    private TestDAO testDAO;
    private MaterialDAO materialDAO;
    private AnnouncementDAO announcementDAO;
    private GradeDAO gradeDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        try {
            lecturerDAO = new LecturerDAO();
            courseDAO = new CourseDAO();
            testDAO = new TestDAO();
            materialDAO = new MaterialDAO();
            announcementDAO = new AnnouncementDAO();
            gradeDAO = new GradeDAO();
            studentDAO = new StudentDAO();
            logger.info("LecturerServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerServlet", e);
            throw new ServletException("Failed to initialize LecturerServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                    return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Route to appropriate servlet based on URL
            if ("/lecturer".equals(servletPath) && (pathInfo == null || "/".equals(pathInfo))) {
                // Redirect to dashboard
                response.sendRedirect(request.getContextPath() + "/lecturer/dashboard");
                    return;
            } else if ("/lec".equals(servletPath) && pathInfo != null) {
                // Handle short URL patterns
                if (pathInfo.startsWith("/dashboard")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/dashboard");
                    return;
                } else if (pathInfo.startsWith("/courses")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/courses" + 
                            (pathInfo.length() > 8 ? pathInfo.substring(8) : ""));
                    return;
                } else if (pathInfo.startsWith("/tests")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/tests" + 
                            (pathInfo.length() > 6 ? pathInfo.substring(6) : ""));
                    return;
                } else if (pathInfo.startsWith("/materials")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/materials" + 
                            (pathInfo.length() > 10 ? pathInfo.substring(10) : ""));
                    return;
                } else if (pathInfo.startsWith("/announcements")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/announcements" + 
                            (pathInfo.length() > 14 ? pathInfo.substring(14) : ""));
                    return;
                } else if (pathInfo.startsWith("/grades")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/grades" + 
                            (pathInfo.length() > 7 ? pathInfo.substring(7) : ""));
                    return;
                } else if (pathInfo.startsWith("/students")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/students" + 
                            (pathInfo.length() > 9 ? pathInfo.substring(9) : ""));
                    return;
                } else if (pathInfo.startsWith("/profile")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/profile");
                    return;
                } else if (pathInfo.startsWith("/settings")) {
                    response.sendRedirect(request.getContextPath() + "/lecturer/profile");
                    return;
                }
            }
            
            // If we get here, the URL pattern wasn't recognized
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        // Forward to doGet for routing
        doGet(request, response);
    }
} 