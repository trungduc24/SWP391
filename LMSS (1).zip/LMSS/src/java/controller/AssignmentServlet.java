/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.AssignmentDAO;
import model.Assignment;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class AssignmentServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        System.out.println("AssignmentServlet initialized successfully");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            List<Assignment> assignments = new AssignmentDAO().getAssignmentsByCourse(courseId);
            request.setAttribute("assignments", assignments);
            request.getRequestDispatcher("/student/assignments.jsp").forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error processing assignment request", e);
        }
    }
}
