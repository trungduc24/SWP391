package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerTestServlet handles all test-related operations for lecturers. This
 * includes creating, viewing, editing, and deleting tests.
 */

@MultipartConfig(
        fileSizeThreshold = 1024 * 1024, // 1 MB
        maxFileSize = 1024 * 1024 * 10, // 10 MB
        maxRequestSize = 1024 * 1024 * 50 // 50 MB
)
public class LecturerTestServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerTestServlet.class.getName());
    private TestDAO testDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private GradeDAO gradeDAO;

    @Override
    public void init() throws ServletException {
        try {
            testDAO = new TestDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            gradeDAO = new GradeDAO();
            logger.info("LecturerTestServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerTestServlet", e);
            throw new ServletException("Failed to initialize LecturerTestServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();

        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            request.setAttribute("lecturer", lecturer);

            // Handle different URL patterns
            if (servletPath.equals("/lecturer/tests/create")) {
                showCreateTestForm(request, response);
            } else if (servletPath.equals("/lecturer/tests") && pathInfo == null) {
                showAllTests(request, response);
            } else if (servletPath.equals("/lecturer/tests") && pathInfo != null) {
                if (pathInfo.startsWith("/view/")) {
                    int testId = Integer.parseInt(pathInfo.substring(6));
                    viewTest(request, response, testId);
                } else if (pathInfo.startsWith("/edit/")) {
                    int testId = Integer.parseInt(pathInfo.substring(6));
                    showEditTestForm(request, response, testId);
                } else if (pathInfo.startsWith("/delete/")) {
                    int testId = Integer.parseInt(pathInfo.substring(8));
                    deleteTest(request, response, testId);
                } else if (pathInfo.startsWith("/results/")) {
                    int testId = Integer.parseInt(pathInfo.substring(9));
                    showTestResults(request, response, testId);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid test ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerTestServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        try {
            if ("create-test".equals(action)) {
                createTest(request, response);
            } else if ("update-test".equals(action)) {
                updateTest(request, response);
            } else if ("delete-test".equals(action)) {
                int testId = Integer.parseInt(request.getParameter("testId"));
                deleteTest(request, response, testId);
            } else if ("submit-grades".equals(action)) {
                submitGrades(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid test ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
        } catch (SQLException | ParseException e) {
            logger.log(Level.SEVERE, "Error in LecturerTestServlet", e);
            throw new ServletException("Error processing request", e);
        }
    }

    private void showAllTests(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get all tests created by this lecturer
        List<Test> tests = testDAO.getTestsByLecturerId(lecturer.getLecturerId());

        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());

        request.setAttribute("tests", tests);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "tests");

        request.getRequestDispatcher("/lecturer/tests.jsp").forward(request, response);
    }

    private void showCreateTestForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());

        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "tests");

        request.getRequestDispatcher("/lecturer/create-test.jsp").forward(request, response);
    }

    private void showEditTestForm(HttpServletRequest request, HttpServletResponse response, int testId)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get test details
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify that this lecturer created the test
        Course course = courseDAO.getCourseById(test.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to edit this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());

        request.setAttribute("test", test);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "tests");

        request.getRequestDispatcher("/lecturer/edit-test.jsp").forward(request, response);
    }

    private void viewTest(HttpServletRequest request, HttpServletResponse response, int testId)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get test details
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify that this lecturer created the test
        Course course = courseDAO.getCourseById(test.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        request.setAttribute("test", test);
        request.setAttribute("course", course);
        request.setAttribute("activeSection", "tests");

        request.getRequestDispatcher("/lecturer/view-test.jsp").forward(request, response);
    }

    private void showTestResults(HttpServletRequest request, HttpServletResponse response, int testId)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get test details
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify that this lecturer created the test
        Course course = courseDAO.getCourseById(test.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view results for this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Get all grades for this test
        List<Grade> grades = gradeDAO.getGradesByTestId(testId);

        request.setAttribute("test", test);
        request.setAttribute("course", course);
        request.setAttribute("grades", grades);
        request.setAttribute("activeSection", "tests");

        request.getRequestDispatcher("/lecturer/test-results.jsp").forward(request, response);
    }

    private void createTest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ParseException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get form data
        String testName = request.getParameter("testName");
        String description = request.getParameter("description");
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String testType = request.getParameter("testType");
        double maxScore = Double.parseDouble(request.getParameter("maxScore"));
        String testDateStr = request.getParameter("testDate");
        String durationStr = request.getParameter("duration");
        String startDate = request.getParameter("startDate");
        String enddate = request.getParameter("endDate");
        // Verify course belongs to lecturer
        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to create tests for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Parse date and duration
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date testDate = dateFormat.parse(testDateStr);
        int duration = Integer.parseInt(durationStr);

        // Create test object
        Test test = new Test();
        test.setTitle(testName);
        test.setDescription(description);
        test.setCourseId(courseId);
        test.setTestType(testType);
        test.setMax_score(maxScore);
        test.setCreatedAt(testDate);
        test.setDeadline(dateFormat.parse(enddate));
        test.setCreatedBy(1);
        test.setDuration_minutes(duration);

        // Save test to database
        int testId = testDAO.createTest(test);

        if (testId > 0) {
            request.getSession().setAttribute("success", "Test created successfully.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests/view/" + testId);
        } else {
            request.getSession().setAttribute("error", "Failed to create test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
        }
    }

    private void updateTest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ParseException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get form data
        int testId = Integer.parseInt(request.getParameter("testId"));
        String testName = request.getParameter("testName");
        String description = request.getParameter("description");
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String testType = request.getParameter("testType");
        double maxScore = Double.parseDouble(request.getParameter("maxScore"));
        String testDateStr = request.getParameter("testDate");
        String durationStr = request.getParameter("duration");
        String endtime = request.getParameter("endtime");
        // Get existing test
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify course belongs to lecturer
        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to update tests for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Parse date and duration
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date testDate = dateFormat.parse(testDateStr);
        int duration = Integer.parseInt(durationStr);

        // Update test object
        test.setTitle(testName);
        test.setDescription(description);
        test.setCourseId(courseId);
        test.setTestType(testType);
        test.setMax_score(maxScore);
        test.setStart_time(testDate);
        test.setDuration_minutes(duration);

        // Save test to database
        boolean success = testDAO.updateTest(test);

        if (success) {
            request.getSession().setAttribute("success", "Test updated successfully.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests/view/" + testId);
        } else {
            request.getSession().setAttribute("error", "Failed to update test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
        }
    }

    private void deleteTest(HttpServletRequest request, HttpServletResponse response, int testId)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");

        // Get existing test
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify course belongs to lecturer
        Course course = courseDAO.getCourseById(test.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to delete this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Delete test from database
        boolean success = testDAO.deleteTest(testId);

        if (success) {
            request.getSession().setAttribute("success", "Test deleted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to delete test.");
        }

        response.sendRedirect(request.getContextPath() + "/lecturer/tests");
    }

    private void submitGrades(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        int testId = Integer.parseInt(request.getParameter("testId"));

        // Get existing test
        Test test = testDAO.getTestById(testId);

        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Verify course belongs to lecturer
        Course course = courseDAO.getCourseById(test.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to submit grades for this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/tests");
            return;
        }

        // Process all student grades
        String[] studentIds = request.getParameterValues("studentId");
        String[] scores = request.getParameterValues("score");
        String[] feedbacks = request.getParameterValues("feedback");

        boolean allSuccess = true;

        if (studentIds != null && scores != null) {
            for (int i = 0; i < studentIds.length; i++) {
                int studentId = Integer.parseInt(studentIds[i]);
                double score = Double.parseDouble(scores[i]);
                String feedback = (feedbacks != null && i < feedbacks.length) ? feedbacks[i] : "";

                // Create or update grade
                Grade grade = new Grade();
                grade.setStudentId(studentId);
                grade.setTestId(testId);
                grade.setScore(score);
                grade.setFeedback(feedback);
                grade.setGradeDate(new Timestamp(new Date().getTime()));

                boolean success = gradeDAO.saveGrade(grade);
                if (!success) {
                    allSuccess = false;
                }
            }
        }

        if (allSuccess) {
            request.getSession().setAttribute("success", "Grades submitted successfully.");
        } else {
            request.getSession().setAttribute("error", "Some grades could not be saved.");
        }

        response.sendRedirect(request.getContextPath() + "/lecturer/tests/results/" + testId);
    }
}
