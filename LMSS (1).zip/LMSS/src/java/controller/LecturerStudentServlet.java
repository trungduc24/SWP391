package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerStudentServlet handles all student-related operations for lecturers.
 * This includes viewing student lists, student details, and managing student enrollments.
 */

public class LecturerStudentServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerStudentServlet.class.getName());
    private StudentDAO studentDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private GradeDAO gradeDAO;

    @Override
    public void init() throws ServletException {
        try {
            studentDAO = new StudentDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            gradeDAO = new GradeDAO();
            logger.info("LecturerStudentServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerStudentServlet", e);
            throw new ServletException("Failed to initialize LecturerStudentServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Handle different URL patterns
            if (servletPath.equals("/lecturer/students") && pathInfo == null) {
                showAllStudents(request, response);
            } else if (servletPath.equals("/lecturer/students") && pathInfo != null) {
                if (pathInfo.startsWith("/view/")) {
                    int studentId = Integer.parseInt(pathInfo.substring(6));
                    viewStudent(request, response, studentId);
                } else if (pathInfo.startsWith("/course/")) {
                    int courseId = Integer.parseInt(pathInfo.substring(8));
                    showCourseStudents(request, response, courseId);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/students");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerStudentServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        
        try {
            if ("search-students".equals(action)) {
                searchStudents(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerStudentServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showAllStudents(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get all students taught by this lecturer
        List<Student> students = studentDAO.getStudentsByLecturerId(lecturer.getLecturerId());
        
        // Get courses for this lecturer
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("students", students);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "students");
        
        request.getRequestDispatcher("/lecturer/students.jsp").forward(request, response);
    }

    private void viewStudent(HttpServletRequest request, HttpServletResponse response, int studentId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get student details
        Student student = studentDAO.getStudentById(studentId);
        
        if (student == null) {
            request.getSession().setAttribute("error", "Student not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/students");
            return;
        }
        
        // Check if this student is enrolled in any of the lecturer's courses
        List<Course> enrolledCourses = courseDAO.getCoursesByStudentId(studentId);
        boolean isEnrolled = enrolledCourses.stream()
                .anyMatch(course -> course.getLecturerId() == lecturer.getLecturerId());
        
        if (!isEnrolled) {
            request.getSession().setAttribute("error", "This student is not enrolled in any of your courses.");
            response.sendRedirect(request.getContextPath() + "/lecturer/students");
            return;
        }
        
        // Filter courses to only those taught by this lecturer
        enrolledCourses.removeIf(course -> course.getLecturerId() != lecturer.getLecturerId());
        
        // Get grades for this student in lecturer's courses
        List<Grade> grades = gradeDAO.getGradesByStudentId(studentId);
        
        // Get user information
        User user = student.getUser();
        
        request.setAttribute("student", student);
        request.setAttribute("user", user);
        request.setAttribute("enrolledCourses", enrolledCourses);
        request.setAttribute("grades", grades);
        request.setAttribute("activeSection", "students");
        
        request.getRequestDispatcher("/lecturer/view-student.jsp").forward(request, response);
    }

    private void showCourseStudents(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get course details
        Course course = courseDAO.getCourseById(courseId);
        
        if (course == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/students");
            return;
        }
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view students for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/students");
            return;
        }
        
        // Get students enrolled in this course
        List<Student> students = studentDAO.getStudentsByCourseId(courseId);
        
        // Get all courses for this lecturer (for dropdown)
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("course", course);
        request.setAttribute("students", students);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "students");
        
        request.getRequestDispatcher("/lecturer/course-students.jsp").forward(request, response);
    }

    private void searchStudents(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        String keyword = request.getParameter("keyword");
        String courseIdParam = request.getParameter("courseId");
        
        List<Student> students;
        
        if (courseIdParam != null && !courseIdParam.isEmpty()) {
            int courseId = Integer.parseInt(courseIdParam);
            
            // Get course details
            Course course = courseDAO.getCourseById(courseId);
            
            // Verify that this lecturer teaches this course
            if (course.getLecturerId() != lecturer.getLecturerId()) {
                request.getSession().setAttribute("error", "You don't have permission to view students for this course.");
                response.sendRedirect(request.getContextPath() + "/lecturer/students");
                return;
            }
            
            // Search students in this course
            students = studentDAO.searchStudentsByCourse(courseId, keyword);
            request.setAttribute("course", course);
        } else {
            // Search all students taught by this lecturer
            students = studentDAO.searchStudentsByLecturer(lecturer.getLecturerId(), keyword);
        }
        
        // Get courses for this lecturer (for dropdown)
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("students", students);
        request.setAttribute("courses", courses);
        request.setAttribute("keyword", keyword);
        request.setAttribute("selectedCourseId", courseIdParam);
        request.setAttribute("activeSection", "students");
        
        request.getRequestDispatcher("/lecturer/students.jsp").forward(request, response);
    }
} 