package controller;

import dao.UsersDAO;
import model.User;
import utils.BCryptUtil;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.logging.Logger;
import java.util.logging.Level;

public class EditUserServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(EditUserServlet.class.getName());
    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        Connection conn = DBConnection.getConnection();
        if (conn == null) {
            throw new ServletException("❌ Không thể kết nối tới cơ sở dữ liệu!");
        }
        userDAO = new UsersDAO(conn);
        logger.info("EditUserServlet initialized successfully");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền sửa thông tin người dùng!");
            return;
        }

        String userIdStr = req.getParameter("id");
        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID người dùng không hợp lệ!");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);
            User userToEdit = userDAO.getUserById(userId);

            if (userToEdit == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy người dùng!");
                return;
            }

            req.setAttribute("userToEdit", userToEdit);
            req.getRequestDispatcher("/admin/edit-user.jsp").forward(req, resp);

        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID người dùng không hợp lệ!");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while getting user for edit", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi cơ sở dữ liệu!");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền sửa thông tin người dùng!");
            return;
        }

        String userIdStr = req.getParameter("userId");
        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String role = req.getParameter("role");
        String fullName = req.getParameter("fullName");
        String newPassword = req.getParameter("password");
        String avatarUrl = req.getParameter("avatarUrl");
        String phone = req.getParameter("phone");
        String department = req.getParameter("department"); // cho lecturer
        String className = req.getParameter("className"); // cho student
        String emailVerifiedStr = req.getParameter("emailVerified");
        String isActiveStr = req.getParameter("isActive");

        // Validate input
        if (userIdStr == null || userIdStr.trim().isEmpty() ||
                username == null || username.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                role == null || role.trim().isEmpty() ||
                fullName == null || fullName.trim().isEmpty()) {

            req.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            doGet(req, resp);
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);

            // Kiểm tra user tồn tại
            User existingUser = userDAO.getUserById(userId);
            if (existingUser == null) {
                req.setAttribute("error", "Không tìm thấy người dùng!");
                doGet(req, resp);
                return;
            }

            // Kiểm tra username và email trùng lặp (trừ chính user đang sửa)
            User userWithSameUsername = userDAO.getUserByUsername(username);
            if (userWithSameUsername != null && userWithSameUsername.getUserId() != userId) {
                req.setAttribute("error", "Tên đăng nhập đã tồn tại!");
                doGet(req, resp);
                return;
            }

            if (userDAO.isEmailExists(email) && !email.equals(existingUser.getEmail())) {
                req.setAttribute("error", "Email đã được sử dụng!");
                doGet(req, resp);
                return;
            }

            // Parse boolean values
            boolean emailVerified = "on".equals(emailVerifiedStr) || "true".equals(emailVerifiedStr);
            boolean isActive = "on".equals(isActiveStr) || "true".equals(isActiveStr);

            // Cập nhật thông tin user
            boolean success = updateUser(userId, username, email, role, fullName, newPassword, avatarUrl, phone,
                    department, className, emailVerified, isActive);

            if (success) {
                // Log hoạt động sửa user
                logUserUpdate(currentUser.getUserId(), userId, username, getClientIP(req), req.getHeader("User-Agent"));

                logger.info("User updated successfully by admin: " + currentUser.getUsername() +
                        " - Updated user: " + username + " (ID: " + userId + ")");

                // Redirect để tránh duplicate submission
                resp.sendRedirect(req.getContextPath() + "/admin/users.jsp?updated=success");
                return;
            } else {
                req.setAttribute("error", "Không thể cập nhật thông tin người dùng!");
            }

        } catch (NumberFormatException e) {
            req.setAttribute("error", "ID người dùng không hợp lệ!");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while updating user", e);
            req.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error while updating user", e);
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
        }

        // Forward về trang edit với thông báo lỗi
        doGet(req, resp);
    }

    /**
     * Cập nhật thông tin user
     */
    private boolean updateUser(int userId, String username, String email, String role, String fullName,
            String newPassword, String avatarUrl, String phone, String department, String className,
            boolean emailVerified, boolean isActive) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try {
                // Cập nhật bảng users
                String userSql = "UPDATE users SET username = ?, email = ?, role = ?, full_name = ?, avatar_url = ?, email_verified = ?, is_active = ?";
                if (newPassword != null && !newPassword.trim().isEmpty()) {
                    userSql += ", password = ?";
                }
                userSql += " WHERE user_id = ?";

                try (PreparedStatement stmt = conn.prepareStatement(userSql)) {
                    stmt.setString(1, username);
                    stmt.setString(2, email);
                    stmt.setString(3, role);
                    stmt.setString(4, fullName);
                    stmt.setString(5, avatarUrl);
                    stmt.setBoolean(6, emailVerified);
                    stmt.setBoolean(7, isActive);

                    int paramIndex = 8;
                    if (newPassword != null && !newPassword.trim().isEmpty()) {
                        stmt.setString(paramIndex++, BCryptUtil.hashPassword(newPassword));
                    }
                    stmt.setInt(paramIndex, userId);

                    stmt.executeUpdate();
                }

                // Cập nhật bảng role-specific
                updateRoleSpecificInfo(conn, userId, role, fullName, phone, department, className);

                conn.commit();
                return true;

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    /**
     * Cập nhật thông tin theo role
     */
    private void updateRoleSpecificInfo(Connection conn, int userId, String role, String fullName,
            String phone, String department, String className) throws SQLException {
        String sql = "";

        switch (role) {
            case "student":
                sql = "UPDATE students SET full_name = ?, phone = ?, class_name = ? WHERE user_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, fullName);
                    stmt.setString(2, phone);
                    stmt.setString(3, className);
                    stmt.setInt(4, userId);
                    stmt.executeUpdate();
                }
                break;

            case "lecturer":
                sql = "UPDATE lecturers SET full_name = ?, phone = ?, department = ? WHERE user_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, fullName);
                    stmt.setString(2, phone);
                    stmt.setString(3, department);
                    stmt.setInt(4, userId);
                    stmt.executeUpdate();
                }
                break;

            case "admin":
                sql = "UPDATE admins SET full_name = ? WHERE user_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, fullName);
                    stmt.setInt(2, userId);
                    stmt.executeUpdate();
                }
                break;
        }
    }

    /**
     * Ghi log cập nhật user
     */
    private void logUserUpdate(int adminId, int updatedUserId, String username, String ip, String userAgent) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO system_logs (user_id, action, table_name, record_id, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, adminId);
                stmt.setString(2, "UPDATE_USER");
                stmt.setString(3, "users");
                stmt.setInt(4, updatedUserId);
                stmt.setString(5, "Updated user: " + username);
                stmt.setString(6, ip);
                stmt.setString(7, userAgent);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to log user update", e);
        }
    }

    /**
     * Lấy IP của client
     */
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }

        String xRealIP = request.getHeader("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }

        return request.getRemoteAddr();
    }
}
