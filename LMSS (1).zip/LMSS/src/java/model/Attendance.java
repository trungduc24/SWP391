package model;

import java.sql.Date;

public class Attendance {
    private int studentId;
    private int courseId;
    private int sessionNumber;
    private String status;
    private Date date;

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public int getSessionNumber() {
        return sessionNumber;
    }

    public String getStatus() {
        return status;
    }

    public Date getDate() {
        return date;
    }

    public Attendance(int studentId, int courseId, int sessionNumber, String status, Date date) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.sessionNumber = sessionNumber;
        this.status = status;
        this.date = date;
    }

}