package model;

public class Student {
    private int studentId;
    private int userId;
    private String fullName;
    private String studentCode;
    private String email;
    private String avatarUrl;
    private User user;
    private int phone;
    private String address;
    public Student() {}

    public Student(int studentId, int userId, String fullName, String studentCode, String email, String avatarUrl) {
        this.studentId = studentId;
        this.userId = userId;
        this.fullName = fullName;
        this.studentCode = studentCode;
        this.email = email;
        this.avatarUrl = avatarUrl;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Student(int studentId, int userId, String fullName, String studentCode, String email, String avatarUrl,int phone,String address, User user) {
        this.studentId = studentId;
        this.userId = userId;
        this.fullName = fullName;
        this.studentCode = studentCode;
        this.email = email;
        this.avatarUrl = avatarUrl;
        this.phone = phone;
        this.user = user;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    // Getter and Setter
    public int getStudentId() {
        return studentId;
    }
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getStudentCode() {
        return studentCode;
    }
    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAvatarUrl() {
        return avatarUrl;
    }
    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
}
