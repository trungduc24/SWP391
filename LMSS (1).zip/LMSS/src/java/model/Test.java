package model;

import java.util.Date;

public class Test {
    private int testId;
    private String title;
    private String description;
    private int courseId;
    private Date deadline;
    private double totalPoints;
    private int createdBy;
    private Date createdAt;
    private String testType;
    private double max_score;
    private Date start_time;
    private Date end_time;
    private int duration_minutes;
    private boolean is_published;
    // Constructor
    public Test() {
    }
    
    public Test(int testId, String title, String description, int courseId, Date deadline, 
                double totalPoints, int createdBy, Date createdAt, String testType) {
        this.testId = testId;
        this.title = title;
        this.description = description;
        this.courseId = courseId;
        this.deadline = deadline;
        this.totalPoints = totalPoints;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.testType = testType;
    }

    public Test(int testId, String title, String description, int courseId, int deadline, double totalPoints, int createdBy, Date createdAt, String testType, double max_score, Date start_time, Date end_time, boolean is_published) {
        this.testId = testId;
        this.title = title;
        this.description = description;
        this.courseId = courseId;
        this.duration_minutes = deadline;
        this.totalPoints = totalPoints;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.testType = testType;
        this.max_score = max_score;
        this.start_time = start_time;
        this.end_time = end_time;
        this.is_published = is_published;
    }

    public int getDuration_minutes() {
        return duration_minutes;
    }

    public void setDuration_minutes(int duration_minutes) {
        this.duration_minutes = duration_minutes;
    }

    public double getMax_score() {
        return max_score;
    }

    public void setMax_score(double max_score) {
        this.max_score = max_score;
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public boolean isIs_published() {
        return is_published;
    }

    public void setIs_published(boolean is_published) {
        this.is_published = is_published;
    }
    
    // Getters and Setters
    public int getTestId() {
        return testId;
    }
    
    public void setTestId(int testId) {
        this.testId = testId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public int getCourseId() {
        return courseId;
    }
    
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
    
    public Date getDeadline() {
        return deadline;
    }
    
    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }
    
    public double getTotalPoints() {
        return totalPoints;
    }
    
    public void setTotalPoints(double totalPoints) {
        this.totalPoints = totalPoints;
    }
    
    public int getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }
    
    public Date getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getTestType() {
        return testType;
    }
    
    public void setTestType(String testType) {
        this.testType = testType;
    }
    
    @Override
    public String toString() {
        return "Test{" +
                "testId=" + testId +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", courseId=" + courseId +
                ", deadline=" + deadline +
                ", totalPoints=" + totalPoints +
                ", createdBy=" + createdBy +
                ", createdAt=" + createdAt +
                ", testType='" + testType + '\'' +
                '}';
    }
} 