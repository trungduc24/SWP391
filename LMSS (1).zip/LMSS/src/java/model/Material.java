package model;

import java.sql.Timestamp;

public class Material {
    private int materialId;
    private String title;
    private String description;
    private String filePath;
    private int courseId;
    private Timestamp uploadDate;
    private int uploadedBy;
    private String materialType;

    private String fileType;
    private long fileSize;
    private boolean isPublic;
    private int downloadCount;

    // Constructor mặc định
    public Material() {
    }

    public Material(int materialId, String title, String description, String filePath,
                    int courseId, Timestamp uploadDate, int uploadedBy, String materialType) {
        this.materialId = materialId;
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.courseId = courseId;
        this.uploadDate = uploadDate;
        this.uploadedBy = uploadedBy;
        this.materialType = materialType;
    }

    public Material(int materialId, String title, String description, String filePath, int courseId,
                    Timestamp uploadDate, int uploadedBy, String materialType,
                    String fileType, long fileSize, boolean isPublic, int downloadCount) {
        this.materialId = materialId;
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.courseId = courseId;
        this.uploadDate = uploadDate;
        this.uploadedBy = uploadedBy;
        this.materialType = materialType;
        this.fileType = fileType;
        this.fileSize = fileSize;
        this.isPublic = isPublic;
        this.downloadCount = downloadCount;
    }

    // Getters và Setters
    public int getMaterialId() {
        return materialId;
    }

    public void setMaterialId(int materialId) {
        this.materialId = materialId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public Timestamp getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Timestamp uploadDate) {
        this.uploadDate = uploadDate;
    }

    public int getUploadedBy() {
        return uploadedBy;
    }

    public void setUploadedBy(int uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public boolean isPublic() {
        return isPublic;
    }

    public void setPublic(boolean isPublic) {
        this.isPublic = isPublic;
    }

    public int getDownloadCount() {
        return downloadCount;
    }

    public void setDownloadCount(int downloadCount) {
        this.downloadCount = downloadCount;
    }

    @Override
    public String toString() {
        return "Material{" +
                "materialId=" + materialId +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", filePath='" + filePath + '\'' +
                ", courseId=" + courseId +
                ", uploadDate=" + uploadDate +
                ", uploadedBy=" + uploadedBy +
                ", materialType='" + materialType + '\'' +
                ", fileType='" + fileType + '\'' +
                ", fileSize=" + fileSize +
                ", isPublic=" + isPublic +
                ", downloadCount=" + downloadCount +
                '}';
    }

    public void setFileUrl(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setUploadedAt(Timestamp timestamp) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
