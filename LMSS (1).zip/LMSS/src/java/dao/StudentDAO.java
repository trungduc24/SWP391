package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Student;
import model.User;
import utils.DBConnection; // Bạn cần tạo class DBConnection để kết nối DB

public class StudentDAO {

    public List<Student> getStudentsByCourse(int courseId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT s.* FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    WHERE e.course_id = ?
                """;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student s = new Student(
                        rs.getInt("student_id"),
                        rs.getInt("user_id"),
                        rs.getString("full_name"),
                        rs.getString("student_code"),
                        rs.getString("email"),
                        rs.getString("avatar_url"));
                list.add(s);
            }
        }
        return list;
    }

    // Thêm student mới
    public boolean insertStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students (user_id, full_name, student_code, email, avatar_url) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, student.getUserId());
            ps.setString(2, student.getFullName());
            ps.setString(3, student.getStudentCode());
            ps.setString(4, student.getEmail());
            ps.setString(5, student.getAvatarUrl());
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    private boolean updateUser(User user) {
        String sql = "UPDATE users SET full_name = ?, email = ?, avatar_url = ?, is_active = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getFullName());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getAvatarUrl());
            stmt.setBoolean(4, user.isActive());
            stmt.setInt(5, user.getUserId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Cập nhật thông tin student
    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET phone = ?, address = ? WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, student.getPhone());
            stmt.setString(2, student.getAddress());
            stmt.setInt(3, student.getStudentId());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                return updateUser(student.getUser());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateStudentPassword(int studentId, String oldPass, String newPass) {
        String sql = "UPDATE users SET password = ? WHERE user_id = (SELECT user_id FROM students WHERE student_id = ?) AND password = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newPass);
            stmt.setInt(2, studentId);
            stmt.setString(3, oldPass);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Xóa student theo student_id
    public boolean deleteStudent(int studentId) throws SQLException {
        String sql = "DELETE FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    // Lấy student theo student_id
    public Student getStudentById(int studentId) throws SQLException {
        String sql = "SELECT * FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    return s;
                }
            }
        }
        return null;
    }

    // Lấy danh sách tất cả student
    public List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Student s = new Student();
                s.setStudentId(rs.getInt("student_id"));
                s.setUserId(rs.getInt("user_id"));
                s.setFullName(rs.getString("full_name"));
                s.setStudentCode(rs.getString("student_code"));
                s.setEmail(rs.getString("email"));
                s.setAvatarUrl(rs.getString("avatar_url"));
                list.add(s);
            }
        }
        return list;
    }public boolean enrollStudent(int userId, int courseId) {
    String sql = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        // cần lấy student_id từ user_id
        int studentId = getStudentIdByUserId(userId);
        stmt.setInt(1, studentId);
        stmt.setInt(2, courseId);
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}

private int getStudentIdByUserId(int userId) throws SQLException {
    String sql = "SELECT student_id FROM students WHERE user_id = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, userId);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("student_id");
        }
    }
    throw new SQLException("Student not found for user_id: " + userId);
}


    // Lấy danh sách sinh viên chưa đăng ký khóa học
    public List<Student> getStudentsNotInCourse(int courseId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, u.username, u.email, u.full_name, u.avatar_url "
                + "FROM students s "
                + "INNER JOIN users u ON s.user_id = u.user_id "
                + "WHERE s.student_id NOT IN ("
                + "    SELECT e.student_id FROM enrollments e "
                + "    WHERE e.course_id = ? AND e.status = 'active'"
                + ") "
                + "ORDER BY u.full_name";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setStudentCode(rs.getString("student_code"));

                    // Set thông tin từ bảng users
                    s.setFullName(rs.getString("full_name"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));

                    list.add(s);
                }
            }
        }
        return list;
    }

    // Đếm số lượng sinh viên
    public int countStudents() throws SQLException {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // Đếm số lượng sinh viên theo giảng viên
   public int getStudentCountByLecturerId(int lecturerId) throws SQLException {
    String sql = """
        SELECT COUNT(DISTINCT s.student_id)
        FROM lecturers l
        JOIN courses c ON l.lecturer_id = c.lecturer_id
        JOIN enrollments e ON c.course_id = e.course_id
        JOIN students s ON e.student_id = s.student_id
        WHERE l.lecturer_id = ?
    """;

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, lecturerId);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
    }

    return 0;
}


    // Lấy danh sách sinh viên theo giảng viên
    public List<Student> getStudentsByLecturerId(int lecturerId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT DISTINCT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    JOIN courses c ON e.course_id = c.course_id
                    WHERE c.lecturer_id = ?
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    // Tìm kiếm sinh viên theo từ khóa
    public List<Student> searchStudentsByLecturer(int lecturerId, String keyword) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT DISTINCT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    JOIN courses c ON e.course_id = c.course_id
                    WHERE c.lecturer_id = ? 
                    AND (s.full_name LIKE ? OR s.student_code LIKE ? OR s.email LIKE ?)
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            String searchTerm = "%" + keyword + "%";
            ps.setString(2, searchTerm);
            ps.setString(3, searchTerm);
            ps.setString(4, searchTerm);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    // Tìm kiếm sinh viên theo khóa học và từ khóa
    public List<Student> searchStudentsByCourse(int courseId, String keyword) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    WHERE e.course_id = ? 
                    AND (s.full_name LIKE ? OR s.student_code LIKE ? OR s.email LIKE ?)
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            String searchTerm = "%" + keyword + "%";
            ps.setString(2, searchTerm);
            ps.setString(3, searchTerm);
            ps.setString(4, searchTerm);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }
    public List<Student> getStudentsByCourseId(int courseId) {
    List<Student> students = new ArrayList<>();
    String sql = """
        SELECT s.* FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        WHERE e.course_id = ?
    """;

    try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, courseId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Student student = new Student();
            student.setStudentId(rs.getInt("student_id"));
            student.setFullName(rs.getString("full_name"));
            student.setEmail(rs.getString("email"));
            student.setPhone(rs.getInt("phone"));
            student.setUserId(rs.getInt("user_id"));
            students.add(student);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return students;
}

public Student getStudentByUserId(int userId) {
    String sql = "SELECT * FROM students WHERE user_id = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, userId);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                Student s = new Student();
                s.setStudentId(rs.getInt("student_id"));
                s.setUserId(rs.getInt("user_id"));
                s.setFullName(rs.getString("full_name"));
                s.setStudentCode(rs.getString("student_code"));
                s.setEmail(rs.getString("email"));
                s.setAvatarUrl(rs.getString("avatar_url"));
                s.setPhone(rs.getInt("phone"));
                s.setAddress(rs.getString("address"));
                return s;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

}
