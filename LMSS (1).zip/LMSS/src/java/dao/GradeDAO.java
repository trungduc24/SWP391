package dao;

import java.sql.Timestamp;
import model.Grade;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class GradeDAO {

    private static final Logger logger = Logger.getLogger(GradeDAO.class.getName());

    public GradeDAO() {
    }

    public int addGrade(Grade grade) {
        String sql = "INSERT INTO Grades (student_id, test_id, score, feedback, graded_by) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, grade.getStudentId());
            pstmt.setInt(2, grade.getTestId());
            pstmt.setDouble(3, grade.getScore());
            pstmt.setString(4, grade.getFeedback());
            pstmt.setInt(5, grade.getGradedBy());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating grade failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating grade failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    public boolean updateGrade(Grade grade) throws SQLException {
        String sql = "UPDATE Grades SET score = ?, feedback = ?, graded_by = ? WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, grade.getScore());
            pstmt.setString(2, grade.getFeedback());
            pstmt.setInt(3, grade.getGradedBy());
            pstmt.setInt(4, grade.getGradeId());

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public boolean deleteGrade(int gradeId) throws SQLException {
        String sql = "DELETE FROM Grades WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gradeId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public Grade getGradeById(int gradeId) throws SQLException {
        String sql = "SELECT * FROM Grades WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gradeId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapGrade(rs);
                }
            }
        }

        return null;
    }

    public List<Grade> getGradesByTestId(int testId) throws SQLException {
        String sql = "SELECT g.*, s.full_name AS student_name "
                + "FROM Grades g "
                + "JOIN Students s ON g.student_id = s.student_id "
                + "WHERE g.test_id = ? "
                + "ORDER BY g.grade_date DESC";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setStudentName(rs.getString("student_name"));
                    grades.add(grade);
                }
            }
        }

        return grades;
    }

    public List<Grade> getGradesByStudentId(int studentId) {
        String sql = "SELECT g.*, t.title AS test_title "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "WHERE g.student_id = ? "
                + "ORDER BY g.grade_date DESC";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setTestTitle(rs.getString("test_title"));
                    grades.add(grade);
                }
            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return grades;
    }

    public Map<String, Integer> getGradeDistribution() throws SQLException {
        Map<String, Integer> distribution = new HashMap<>();

        String sql = """
        SELECT 
            CASE 
                WHEN score >= 90 THEN 'A'
                WHEN score >= 80 THEN 'B'
                WHEN score >= 70 THEN 'C'
                WHEN score >= 60 THEN 'D'
                ELSE 'F'
            END AS grade,
            COUNT(*) AS count
        FROM grades
        GROUP BY 
            CASE 
                WHEN score >= 90 THEN 'A'
                WHEN score >= 80 THEN 'B'
                WHEN score >= 70 THEN 'C'
                WHEN score >= 60 THEN 'D'
                ELSE 'F'
            END
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String grade = rs.getString("grade");
                int count = rs.getInt("count");
                distribution.put(grade, count);
            }
        }

        return distribution;
    }

    public List<Grade> getGradesByCourseId(int courseId) throws SQLException {
        String sql = "SELECT g.*, s.full_name AS student_name, t.title AS test_title "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "JOIN Students s ON g.student_id = s.student_id "
                + "WHERE t.course_id = ? "
                + "ORDER BY t.test_id, s.full_name";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setStudentName(rs.getString("student_name"));
                    grade.setTestTitle(rs.getString("test_title"));
                    grades.add(grade);
                }
            }
        }

        return grades;
    }

    public double getAverageGradeByCourse(int courseId, int studentId) throws SQLException {
        String sql = "SELECT AVG(g.score) AS average_score "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "WHERE t.course_id = ? AND g.student_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);
            pstmt.setInt(2, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("average_score");
                }
            }
        }
        
        return 0.0;
    }
    
    private Grade mapGrade(ResultSet rs) throws SQLException {
        Grade grade = new Grade();
        grade.setGradeId(rs.getInt("grade_id"));
        grade.setStudentId(rs.getInt("student_id"));
        grade.setTestId(rs.getInt("test_id"));
        grade.setScore(rs.getDouble("score"));
        grade.setFeedback(rs.getString("feedback"));
        grade.setGradeDate(rs.getTimestamp("grade_date"));
        grade.setGradedBy(rs.getInt("graded_by"));

        return grade;
    }

    public boolean saveGrade(Grade grade) throws SQLException {
        String sql = "MERGE INTO grades AS target "
                + "USING (SELECT ? AS student_id, ? AS test_id) AS source "
                + "ON target.student_id = source.student_id AND target.test_id = source.test_id "
                + "WHEN MATCHED THEN "
                + "  UPDATE SET score=?, max_score=?, grade_type=?, comment=?, graded_by=?, graded_at=?, course_id=?, assignment_id=NULL "
                + "WHEN NOT MATCHED THEN "
                + "  INSERT (student_id, test_id, score, max_score, grade_type, comment, graded_by, graded_at, course_id) "
                + "  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            int i = 1;
            stmt.setInt(i++, grade.getStudentId());
            stmt.setInt(i++, grade.getTestId());
            stmt.setDouble(i++, grade.getScore());
            stmt.setDouble(i++, grade.getScore());
            stmt.setString(i++, grade.getGrade_type());
            stmt.setString(i++, grade.getFeedback());
            stmt.setInt(i++, grade.getGradedBy());
            stmt.setTimestamp(i++, new Timestamp(grade.getGradeDate().getTime()));
            stmt.setInt(i++, grade.getCourse_id());
            stmt.setInt(i++, grade.getStudentId());
            stmt.setInt(i++, grade.getTestId());
            stmt.setDouble(i++, grade.getScore());
            stmt.setDouble(i++, grade.getMax_score());
            stmt.setString(i++, grade.getGrade_type());
            stmt.setString(i++, grade.getFeedback());
            stmt.setInt(i++, grade.getGradedBy());
            stmt.setTimestamp(i++, new Timestamp(grade.getGradeDate().getTime()));
            stmt.setInt(i++, grade.getCourse_id());
            return stmt.executeUpdate() > 0;
        }
    }

}
