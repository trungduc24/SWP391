package dao;

import model.CourseMaterial;
import utils.DBConnection; // Đảm bảo bạn có lớp DBConnection này

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CourseMaterialDAO {

    public CourseMaterialDAO() {
    }

    // Phương thức thêm tài liệu khóa học mới
    public void addCourseMaterial(CourseMaterial material) throws SQLException {
        // Bỏ qua cột upload_date trong câu lệnh INSERT, để DB tự động gán GETDATE()
        String INSERT_MATERIAL_SQL = "INSERT INTO course_materials (course_id, title, description, file_url) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MATERIAL_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setInt(1, material.getCourseId());
            preparedStatement.setString(2, material.getTitle());
            preparedStatement.setString(3, material.getDescription());
            preparedStatement.setString(4, material.getFileUrl());

            preparedStatement.executeUpdate();

            try (ResultSet rs = preparedStatement.getGeneratedKeys()) {
                if (rs.next()) {
                    material.setMaterialId(rs.getInt(1)); // Set ID tự động tạo
                }
            }
        }
    }

    // Phương thức lấy tất cả tài liệu của một khóa học theo courseId
    public List<CourseMaterial> getMaterialsByCourseId(int courseId) throws SQLException {
        List<CourseMaterial> materials = new ArrayList<>();
        String SELECT_MATERIALS_BY_COURSE_ID_SQL = "SELECT material_id, course_id, title, description, file_url, upload_date FROM course_materials WHERE course_id = ? ORDER BY upload_date DESC";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MATERIALS_BY_COURSE_ID_SQL)) {

            preparedStatement.setInt(1, courseId);
            try (ResultSet rs = preparedStatement.executeQuery()) {
                while (rs.next()) {
                    int materialId = rs.getInt("material_id");
                    String title = rs.getString("title");
                    String description = rs.getString("description");
                    String fileUrl = rs.getString("file_url");
                    // Đọc từ cột upload_date và gán cho uploadedAt
                    LocalDateTime uploadedAt = rs.getTimestamp("upload_date") != null ? rs.getTimestamp("upload_date").toLocalDateTime() : null;

                    materials.add(new CourseMaterial(materialId, courseId, title, description, fileUrl, uploadedAt));
                }
            }
        }
        return materials;
    }

    // Phương thức lấy tài liệu theo materialId
    public CourseMaterial getCourseMaterialById(int materialId) throws SQLException {
        CourseMaterial material = null;
        String SELECT_MATERIAL_BY_ID_SQL = "SELECT material_id, course_id, title, description, file_url, upload_date FROM course_materials WHERE material_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MATERIAL_BY_ID_SQL)) {

            preparedStatement.setInt(1, materialId);
            try (ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    String title = rs.getString("title");
                    String description = rs.getString("description");
                    String fileUrl = rs.getString("file_url");
                    // Đọc từ cột upload_date và gán cho uploadedAt
                    LocalDateTime uploadedAt = rs.getTimestamp("upload_date") != null ? rs.getTimestamp("upload_date").toLocalDateTime() : null;

                    material = new CourseMaterial(materialId, courseId, title, description, fileUrl, uploadedAt);
                }
            }
        }
        return material;
    }

    // Phương thức cập nhật tài liệu khóa học
    public void updateCourseMaterial(CourseMaterial material) throws SQLException {
        // Không cập nhật upload_date ở đây, vì nó thường được đặt là thời gian tạo
        String UPDATE_MATERIAL_SQL = "UPDATE course_materials SET course_id = ?, title = ?, description = ?, file_url = ? WHERE material_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_MATERIAL_SQL)) {

            preparedStatement.setInt(1, material.getCourseId());
            preparedStatement.setString(2, material.getTitle());
            preparedStatement.setString(3, material.getDescription());
            preparedStatement.setString(4, material.getFileUrl());
            preparedStatement.setInt(5, material.getMaterialId());

            preparedStatement.executeUpdate();
        }
    }

    // Phương thức xóa tài liệu khóa học
    public void deleteCourseMaterial(int materialId) throws SQLException {
        String DELETE_MATERIAL_SQL = "DELETE FROM course_materials WHERE material_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_MATERIAL_SQL)) {

            preparedStatement.setInt(1, materialId);
            preparedStatement.executeUpdate();
        }
    }
}