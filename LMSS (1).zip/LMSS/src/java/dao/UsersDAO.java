package dao;

import model.User;
import utils.BCryptUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class UsersDAO {
    private Connection conn;

    public UsersDAO(Connection conn) {
        this.conn = conn;
    }

    public UsersDAO() {

    }


    // Kiểm tra email đã tồn tại chưa
    public boolean isEmailExists(String email) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    // Lấy User theo username
    public User getUserByUsername(String username) throws SQLException {
        String sql = "SELECT user_id, username, password, role, email, avatar_url, email_verified FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("email"),
                            rs.getString("avatar_url"),
                            rs.getBoolean("email_verified"));
                }
            }
        }
        return null;
    }

    // Lấy User theo email
    public User getUserByEmail(String email) throws SQLException {
        String sql = "SELECT user_id, username, password, role, email, avatar_url, email_verified FROM users WHERE email = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("email"),
                            rs.getString("avatar_url"),
                            rs.getBoolean("email_verified"));
                }
            }
        }
        return null;
    }

    // Lấy User theo token xác thực email
    public User getUserByVerificationToken(String token) throws SQLException {
        String sql = "SELECT user_id, username, password, role, email, avatar_url, email_verified FROM users WHERE email_verification_token = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, token);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("email"),
                            rs.getString("avatar_url"),
                            rs.getBoolean("email_verified"));
                }
            }
        }
        return null;
    }

    // Đăng ký user mới (mật khẩu đã được mã hóa trước khi gọi hàm này)
    // Đăng ký user mới bằng cách gọi stored procedure RegisterUser
    public boolean registerUserWithToken(String username, String hashedPassword, String role,
            String email, String avatarUrl, String token, String fullName) throws SQLException {
        // Lưu trực tiếp token và avatar_url sau khi gọi SP vì SP hiện không hỗ trợ các
        // cột này
        String callSP = "{CALL RegisterUser(?, ?, ?, ?, ?)}";

        try {
            conn.setAutoCommit(false); // Bắt đầu transaction

            // 1. Gọi stored procedure để thêm vào bảng users + students/lecturers/admins
            try (CallableStatement stmt = conn.prepareCall(callSP)) {
                stmt.setString(1, username);
                stmt.setString(2, hashedPassword);
                stmt.setString(3, role);
                stmt.setString(4, email);
                stmt.setString(5, fullName);
                stmt.execute();
            }

            // 2. Lấy user_id vừa insert
            int userId = -1;
            String getIdSql = "SELECT user_id FROM users WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(getIdSql)) {
                stmt.setString(1, username);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        userId = rs.getInt("user_id");
                    } else {
                        conn.rollback();
                        return false;
                    }
                }
            }

            // 3. Cập nhật avatar_url và email_verification_token (vì SP không xử lý 2 cột
            // này)
            String updateSql = "UPDATE users SET avatar_url = ?, email_verified = 0, email_verification_token = ? WHERE user_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                stmt.setString(1, avatarUrl);
                stmt.setString(2, token);
                stmt.setInt(3, userId);
                stmt.executeUpdate();
            }

            conn.commit(); // Commit tất cả
            return true;

        } catch (SQLException e) {
            conn.rollback(); // Rollback nếu lỗi
            e.printStackTrace();
            return false;
        } finally {
            conn.setAutoCommit(true); // Khôi phục auto-commit
        }
    }

    // Cập nhật trạng thái xác thực email
    public boolean verifyEmail(String token) throws SQLException {
        String sql = "UPDATE users SET email_verified = 1, email_verification_token = NULL WHERE email_verification_token = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, token);
            int rows = stmt.executeUpdate();
            return rows > 0;
        }
    }

    // Kiểm tra đăng nhập (username + password)
    public User checkLogin(String username, String password) throws SQLException {
        User user = getUserByUsername(username);
        if (user != null) {
            // So sánh mật khẩu nhập vào với mật khẩu đã hash
            if (BCryptUtil.checkPassword(password, user.getPassword())) {
                if (user.isEmailVerified()) {
                    return user;
                } else {
                    throw new SQLException("Email chưa được xác thực.");
                }
            }
        }
        return null;
    }

    // Lưu token reset password vào bảng password_resets
    public boolean savePasswordResetToken(int userId, String token) throws SQLException {
        String sql = "INSERT INTO password_resets (user_id, token) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setString(2, token);
            int rows = stmt.executeUpdate();
            return rows > 0;
        }
    }

    public boolean updatePasswordByToken(String token, String hashedPassword) throws SQLException {
        String sql = "UPDATE Users SET password = ?, token = NULL WHERE token = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hashedPassword);
            stmt.setString(2, token);
            return stmt.executeUpdate() > 0;
        }
    }

    // Lấy User theo token reset password, kiểm tra token chưa bị dùng và còn hiệu
    // lực (15 phút)
    public User getUserByResetToken(String token) throws SQLException {
        String sql = "SELECT u.user_id, u.username, u.password, u.role, u.email, u.avatar_url, u.email_verified, pr.created_at, pr.is_used "
                + "FROM users u JOIN password_resets pr ON u.user_id = pr.user_id "
                + "WHERE pr.token = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, token);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Timestamp createdAt = rs.getTimestamp("created_at");
                    boolean isUsed = rs.getBoolean("is_used");
                    if (!isUsed && createdAt != null) {
                        LocalDateTime createdTime = createdAt.toLocalDateTime();
                        LocalDateTime expiryTime = createdTime.plusMinutes(15);
                        if (expiryTime.isAfter(LocalDateTime.now())) {
                            return new User(
                                    rs.getInt("user_id"),
                                    rs.getString("username"),
                                    rs.getString("password"),
                                    rs.getString("role"),
                                    rs.getString("email"),
                                    rs.getString("avatar_url"),
                                    rs.getBoolean("email_verified"));
                        }
                    }
                }
            }
        }
        return null;
    }

    // Đánh dấu token reset password đã dùng
    public boolean markTokenAsUsed(String token) throws SQLException {
        String sql = "UPDATE password_resets SET is_used = 1 WHERE token = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, token);
            int rows = stmt.executeUpdate();
            return rows > 0;
        }
    }

    // Cập nhật mật khẩu mới (hash đã được tạo sẵn)
    public boolean updatePassword(int userId, String hashedPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hashedPassword);
            stmt.setInt(2, userId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        }
    }

    // Lấy user theo ID
    public User getUserById(int userId) throws SQLException {
        String sql = "SELECT user_id, username, password, role, email, full_name, avatar_url, email_verified, is_active FROM users WHERE user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("email"),
                            rs.getString("full_name"),
                            rs.getString("avatar_url"),
                            rs.getBoolean("email_verified"),
                            rs.getBoolean("is_active"));
                }
            }
        }
        return null;
    }

    // Lấy tất cả users
    public List<User> getAllUsers()  {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, password, role, email, full_name, avatar_url, email_verified, is_active FROM users ORDER BY user_id";
        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User user = new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("email"),
                        rs.getString("full_name"),
                        rs.getString("avatar_url"),
                        rs.getBoolean("email_verified"),
                        rs.getBoolean("is_active"));
                users.add(user);
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return users;
    }

    // Lấy users theo role
    public List<User> getUsersByRole(String role) throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, password, role, email, full_name, avatar_url, email_verified, is_active FROM users WHERE role = ? ORDER BY user_id";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, role);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    User user = new User(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("email"),
                            rs.getString("full_name"),
                            rs.getString("avatar_url"),
                            rs.getBoolean("email_verified"),
                            rs.getBoolean("is_active"));
                    users.add(user);
                }
            }
        }
        return users;
    }

    // Thêm user mới
    public boolean insertUser(User user) throws SQLException {
        String sql = "INSERT INTO users (username, password, role, email, full_name, avatar_url, email_verified, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole());
            stmt.setString(4, user.getEmail());
            stmt.setString(5, user.getFullName());
            stmt.setString(6, user.getAvatarUrl());
            stmt.setBoolean(7, user.isEmailVerified());
            stmt.setBoolean(8, user.isActive());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }

    // Cập nhật user
    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE users SET username = ?, role = ?, email = ?, full_name = ?, avatar_url = ?, email_verified = ?, is_active = ?, updated_at = GETDATE() WHERE user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getRole());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getFullName());
            stmt.setString(5, user.getAvatarUrl());
            stmt.setBoolean(6, user.isEmailVerified());
            stmt.setBoolean(7, user.isActive());
            stmt.setInt(8, user.getUserId());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }

    // Xóa user
    public boolean deleteUser(int userId) throws SQLException {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }
}
