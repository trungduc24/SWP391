package dao;

import model.Test;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestDAO {

    private static final Logger logger = Logger.getLogger(TestDAO.class.getName());

    public TestDAO() {
    }

    public int createTest(Test test) throws SQLException {
        String sql = "INSERT INTO tests (title, description, course_id, test_type, duration_minutes, max_score, start_time, end_time, created_by, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, test.getTitle());
            pstmt.setString(2, test.getDescription());
            pstmt.setInt(3, test.getCourseId());
            pstmt.setString(4, test.getTestType());
            pstmt.setInt(5, test.getDuration_minutes());
            pstmt.setDouble(6, test.getMax_score());
            pstmt.setTimestamp(7, new Timestamp(test.getStart_time().getTime()));
            pstmt.setTimestamp(8, new Timestamp(test.getEnd_time().getTime()));
            pstmt.setInt(9, test.getCreatedBy());
            pstmt.setTimestamp(10, new Timestamp(test.getCreatedAt().getTime()));

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating test failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating test failed, no ID obtained.");
                }
            }
        }
    }

    public boolean updateTest(Test test) throws SQLException {
        String sql = "UPDATE tests SET title = ?, description = ?, course_id = ?, test_type = ?, duration_minutes = ?, max_score = ?, start_time = ?, end_time = ? WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, test.getTitle());
            stmt.setString(2, test.getDescription());
            stmt.setInt(3, test.getCourseId());
            stmt.setString(4, test.getTestType());
            stmt.setInt(5, test.getDuration_minutes());
            stmt.setDouble(6, test.getMax_score());
            stmt.setTimestamp(7, new Timestamp(test.getStart_time().getTime()));
            stmt.setTimestamp(8, new Timestamp(test.getEnd_time().getTime()));
            stmt.setInt(9, test.getTestId());

            return stmt.executeUpdate() > 0;
        }
    }

    public List<Test> getUpcomingTestsByStudentId(int studentId) {
        List<Test> tests = new ArrayList<>();
        String sql = """
        SELECT t.* FROM tests t
        JOIN courses c ON t.course_id = c.course_id
        JOIN enrollments e ON c.course_id = e.course_id
        WHERE e.student_id = ? AND t.test_date > NOW()
        ORDER BY t.test_date ASC
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Test test = new Test();
                test.setTestId(rs.getInt("test_id"));
                test.setCourseId(rs.getInt("course_id"));
                test.setTitle(rs.getString("title"));
                test.setStart_time(rs.getTimestamp("test_date"));
                tests.add(test);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tests;
    }

    public boolean deleteTest(int testId) throws SQLException {
        String sql = "DELETE FROM tests WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public Test getTestById(int testId) throws SQLException {
        String sql = "SELECT * FROM tests WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapTest(rs);
                }
            }
        }

        return null;
    }

    public List<Test> getTestsByCourseId(int courseId) throws SQLException {
        String sql = "SELECT * FROM tests WHERE course_id = ? ORDER BY start_time";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }

        return tests;
    }

    public List<Test> getTestsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT t.* FROM tests t "
                + "JOIN courses c ON t.course_id = c.course_id "
                + "WHERE c.lecturer_id = ? "
                + "ORDER BY t.start_time";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }

        return tests;
    }

    private Test mapTest(ResultSet rs) throws SQLException {
        Test test = new Test();
        test.setTestId(rs.getInt("test_id"));
        test.setTitle(rs.getString("title"));
        test.setDescription(rs.getString("description"));
        test.setCourseId(rs.getInt("course_id"));
        test.setTestType(rs.getString("test_type"));
        test.setDuration_minutes(rs.getInt("duration_minutes"));
        test.setMax_score(rs.getDouble("max_score"));
        test.setStart_time(rs.getTimestamp("start_time"));
        test.setEnd_time(rs.getTimestamp("end_time"));
        test.setCreatedBy(rs.getInt("created_by"));
        test.setCreatedAt(rs.getTimestamp("created_at"));
        return test;
    }

    public List<Test> getTestsByStudentId(int studentId, int lecturerId) throws SQLException {
        String sql = "SELECT DISTINCT t.* FROM Tests t "
                + "JOIN Courses c ON t.course_id = c.course_id "
                + "JOIN Enrollments e ON c.course_id = e.course_id "
                + "WHERE e.student_id = ? AND c.lecturer_id = ?";

        List<Test> tests = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }
        return tests;
    }

    public List<Test> getUpcomingTestsByLecturerId(int lecturerId, int i) {
        String sql = "SELECT t.* FROM Tests t "
                + "JOIN Courses c ON t.course_id = c.course_id "
                + "WHERE c.lecturer_id = ? AND t.deadline > NOW() "
                + "ORDER BY t.deadline ASC LIMIT ?, 5";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);
            pstmt.setInt(2, i);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error getting upcoming tests for lecturer", e);
        }

        return tests;
    }

    public int countTestsByLecturerId(int lecturerId) throws SQLException {
        String sql = """
        SELECT COUNT(*) AS total
        FROM tests t
        JOIN courses c ON t.course_id = c.course_id
        WHERE c.lecturer_id = ?
    """;

        int total = 0;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    total = rs.getInt("total");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error in countTestsByLecturerId: " + e.getMessage());
            throw e;
        }

        return total;
    }

}
