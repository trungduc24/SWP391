package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {
    private static final String USER = "sa";
    private static final String PASSWORD = "123";
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=LMS_System;encrypt=false;trustServerCertificate=true";

    // Trả về một Connection mới cho mỗi request
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // Tải driver JDBC
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Tạo kết nối mới
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Kết nối mới đã được tạo.");
        } catch (ClassNotFoundException e) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "❌ Không tìm thấy driver JDBC", e);
        } catch (SQLException e) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "❌ Lỗi khi kết nối CSDL", e);
        }
        return conn;
    }

    // Đóng kết nối được truyền vào
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("✅ Kết nối đã được đóng.");
            } catch (SQLException e) {
                Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "❌ Lỗi khi đóng connection", e);
            }
        }
    }

    // Hàm main để test kết nối CSDL
    public static void main(String[] args) {
        Connection conn = DBConnection.getConnection();
        if (conn != null) {
            System.out.println("🎉 Kết nối CSDL thành công!");
        } else {
            System.out.println("⚠️ Kết nối CSDL thất bại!");
        }

        // Đóng kết nối sau khi test xong
        DBConnection.closeConnection(conn);
    }
}
