package filter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;
import jakarta.servlet.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Authentication Filter để kiểm tra quyền truy cập
 * Áp dụng cho tất cả các URL trừ những trang public
 */
public class AuthenticationFilter implements Filter {
    
    // Danh sách các trang không cần đăng nhập
    private static final List<String> PUBLIC_PATHS = Arrays.asList(
        "/login.jsp",
        "/register.jsp",
        "/forgot-password.jsp",
        "/reset-password.jsp",
        "/verify-result.jsp",
        "/login",
        "/register",
        "/forgot-password",
        "/reset-password",
        "/verify",
        "/google-login"
    );
    
    // Danh sách các tài nguyên tĩnh
    private static final List<String> STATIC_RESOURCES = Arrays.asList(
        ".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".woff", ".woff2", ".ttf"
    );

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("✅ AuthenticationFilter initialized");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = requestURI.substring(contextPath.length());
        
        // Bỏ qua các tài nguyên tĩnh
        if (isStaticResource(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // Bỏ qua các trang public
        if (isPublicPath(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // Kiểm tra session
        HttpSession session = httpRequest.getSession(false);
        User user = null;
        
        if (session != null) {
            user = (User) session.getAttribute("user");
        }
        
        // Nếu chưa đăng nhập, chuyển về trang login
        if (user == null) {
            System.out.println("🚫 Unauthorized access to: " + path + " - Redirecting to login");
            httpResponse.sendRedirect(contextPath + "/login.jsp");
            return;
        }
        
        // Kiểm tra quyền truy cập theo role
        if (!hasPermission(user, path)) {
            System.out.println("🚫 Access denied for user: " + user.getUsername() + 
                             " (role: " + user.getRole() + ") to path: " + path);
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, 
                                 "Bạn không có quyền truy cập trang này!");
            return;
        }
        
        // Thêm user vào request attribute để các servlet có thể sử dụng
        httpRequest.setAttribute("currentUser", user);
        
        // Tiếp tục xử lý request
        chain.doFilter(request, response);
    }
    
    /**
     * Kiểm tra xem path có phải là tài nguyên tĩnh không
     */
    private boolean isStaticResource(String path) {
        return STATIC_RESOURCES.stream().anyMatch(path::endsWith);
    }
    
    /**
     * Kiểm tra xem path có phải là trang public không
     */
    private boolean isPublicPath(String path) {
        return PUBLIC_PATHS.stream().anyMatch(publicPath -> 
            path.equals(publicPath) || path.startsWith(publicPath + "/"));
    }
    
    /**
     * Kiểm tra quyền truy cập của user đối với path
     */
    private boolean hasPermission(User user, String path) {
        String role = user.getRole().toLowerCase();
        
        // Admin có quyền truy cập tất cả
        if ("admin".equals(role)) {
            return true;
        }
        
        // Kiểm tra quyền theo role
        if (path.startsWith("/admin/")) {
            return "admin".equals(role);
        } else if (path.startsWith("/lecturer/")) {
            return "lecturer".equals(role) || "admin".equals(role);
        } else if (path.startsWith("/student/")) {
            return "student".equals(role) || "admin".equals(role);
        }
        
        // Các servlet chung - kiểm tra chi tiết
        return hasServletPermission(user, path);
    }
    
    /**
     * Kiểm tra quyền truy cập các servlet
     */
    private boolean hasServletPermission(User user, String path) {
        String role = user.getRole().toLowerCase();
        
        switch (path) {
            // Servlet chung cho tất cả user đã đăng nhập
            case "/logout":
            case "/profile":
                return true;
                
            // Course management
            case "/courses":
                return true; // Tất cả có thể xem danh sách khóa học
                
            case "/create-course":
            case "/edit-course":
            case "/delete-course":
                return "lecturer".equals(role) || "admin".equals(role);
                
            case "/enroll-course":
            case "/drop-course":
                return "student".equals(role);
                
            // User management - chỉ admin
            case "/create-user":
            case "/edit-user":
            case "/delete-user":
            case "/users":
                return "admin".equals(role);
                
            // Assignment & Test management
            case "/create-assignment":
            case "/edit-assignment":
            case "/delete-assignment":
            case "/create-test":
            case "/edit-test":
            case "/delete-test":
            case "/grade":
                return "lecturer".equals(role) || "admin".equals(role);
                
            case "/submit-assignment":
            case "/take-test":
                return "student".equals(role);
                
            // Material management
            case "/upload-material":
            case "/delete-material":
                return "lecturer".equals(role) || "admin".equals(role);
                
            case "/download-material":
                return true; // Tất cả có thể download
                
            // Reports & Statistics - admin và lecturer
            case "/reports":
            case "/statistics":
            case "/export-data":
                return "admin".equals(role) || "lecturer".equals(role);
                
            // Semester management - chỉ admin
            case "/create-semester":
            case "/edit-semester":
            case "/delete-semester":
                return "admin".equals(role);
                
            // Announcements
            case "/create-announcement":
            case "/edit-announcement":
            case "/delete-announcement":
                return "lecturer".equals(role) || "admin".equals(role);
                
            case "/announcements":
                return true; // Tất cả có thể xem thông báo
                
            // Forum
            case "/create-forum":
            case "/delete-forum":
                return "lecturer".equals(role) || "admin".equals(role);
                
            case "/forum":
            case "/create-post":
            case "/reply-post":
                return true; // Tất cả có thể tham gia forum
                
            // Attendance - lecturer và admin
            case "/attendance":
            case "/mark-attendance":
                return "lecturer".equals(role) || "admin".equals(role);
                
            // Feedback
            case "/feedback":
                return "student".equals(role); // Chỉ student có thể gửi feedback
                
            case "/view-feedback":
                return "lecturer".equals(role) || "admin".equals(role);
                
            default:
                // Mặc định cho phép truy cập nếu không có rule cụ thể
                return true;
        }
    }

    @Override
    public void destroy() {
        System.out.println("🔄 AuthenticationFilter destroyed");
    }
}
