# PowerShell script to start Tomcat 10.1.15 for LMSS
Write-Host "========================================" -ForegroundColor Green
Write-Host "   STARTING TOMCAT 10.1.15 FOR LMSS" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

# Set environment variables for Tomcat 10
$env:CATALINA_HOME = "D:\swp_jsp\jsp_servlet\LMSS\apache-tomcat-10.1.15"
$env:CATALINA_BASE = "D:\swp_jsp\jsp_servlet\LMSS\apache-tomcat-10.1.15"
$env:JAVA_HOME = "C:\Program Files\Java\jdk-24"

Write-Host "CATALINA_HOME: $env:CATALINA_HOME" -ForegroundColor Yellow
Write-Host "CATALINA_BASE: $env:CATALINA_BASE" -ForegroundColor Yellow
Write-Host "JAVA_HOME: $env:JAVA_HOME" -ForegroundColor Yellow

# Stop any existing Java processes
Write-Host "[1] Stopping any existing Tomcat processes..." -ForegroundColor Cyan
try {
    Get-Process -Name "java" -ErrorAction SilentlyContinue | Stop-Process -Force
    Write-Host "Existing Java processes stopped." -ForegroundColor Green
} catch {
    Write-Host "No existing Java processes found." -ForegroundColor Yellow
}

# Wait a moment
Start-Sleep -Seconds 3

# Start Tomcat 10.1.15
Write-Host "[2] Starting Tomcat 10.1.15..." -ForegroundColor Cyan
Set-Location -Path "$env:CATALINA_HOME\bin"

# Execute startup.bat
& ".\startup.bat"

# Wait for server to start
Write-Host "[3] Waiting for server to start..." -ForegroundColor Cyan
Start-Sleep -Seconds 15

# Check if port 8080 is listening
Write-Host "[4] Checking server status..." -ForegroundColor Cyan
$portCheck = netstat -an | Select-String ":8080.*LISTENING"
if ($portCheck) {
    Write-Host "Server is running on port 8080!" -ForegroundColor Green
    
    # Open LMSS Application
    Write-Host "[5] Opening LMSS Application..." -ForegroundColor Cyan
    Start-Process "http://localhost:8080/LMSS"
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "   LMSS IS NOW RUNNING ON TOMCAT 10!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Available URLs:" -ForegroundColor White
    Write-Host "- Home: http://localhost:8080/LMSS" -ForegroundColor Cyan
    Write-Host "- Lecturer: http://localhost:8080/LMSS/lecturer" -ForegroundColor Cyan
    Write-Host "- Student: http://localhost:8080/LMSS/student" -ForegroundColor Cyan
    Write-Host "- Admin: http://localhost:8080/LMSS/admin" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Press any key to stop the server..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
    # Stop Tomcat
    Write-Host "[6] Stopping Tomcat..." -ForegroundColor Cyan
    & ".\shutdown.bat"
    
    Write-Host "Server stopped. Press any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} else {
    Write-Host "Failed to start server on port 8080!" -ForegroundColor Red
    Write-Host "Please check the logs for errors." -ForegroundColor Yellow
}
