package dao;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Notification;


public class NotificationDAO {
    
    // Lấy danh sách thông báo của student
    public List<Notification> getNotificationsByUserId(int userId) {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT notification_id, user_id, title, message, notification_type, " +
                    "is_read, action_url, created_at, read_at " +
                    "FROM notifications " +
                    "WHERE user_id = ? " +
                    "ORDER BY created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Notification notification = new Notification();
                notification.setNotificationId(rs.getInt("notification_id"));
                notification.setUserId(rs.getInt("user_id"));
                notification.setTitle(rs.getString("title"));
                notification.setMessage(rs.getString("message"));
                notification.setNotificationType(rs.getString("notification_type"));
                notification.setRead(rs.getBoolean("is_read"));
                notification.setActionUrl(rs.getString("action_url"));
                notification.setCreatedAt(rs.getTimestamp("created_at"));
                notification.setReadAt(rs.getTimestamp("read_at"));
                notifications.add(notification);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notifications;
    }
    
    // Lấy số lượng thông báo chưa đọc
    public int getUnreadNotificationCount(int userId) {
        String sql = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Đánh dấu thông báo đã đọc
    public boolean markNotificationAsRead(int notificationId) {
        String sql = "UPDATE notifications SET is_read = 1, read_at = GETDATE() WHERE notification_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, notificationId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Đánh dấu tất cả thông báo đã đọc
    public boolean markAllNotificationsAsRead(int userId) {
        String sql = "UPDATE notifications SET is_read = 1, read_at = GETDATE() WHERE user_id = ? AND is_read = 0";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Tạo thông báo mới
    public boolean createNotification(Notification notification) {
        String sql = "INSERT INTO notifications (user_id, title, message, notification_type, action_url) " +
                    "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, notification.getUserId());
            stmt.setString(2, notification.getTitle());
            stmt.setString(3, notification.getMessage());
            stmt.setString(4, notification.getNotificationType());
            stmt.setString(5, notification.getActionUrl());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}