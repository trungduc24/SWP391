package dao;

import java.sql.Timestamp;
import model.Grade;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class GradeDAO {

    private static final Logger logger = Logger.getLogger(GradeDAO.class.getName());

    public GradeDAO() {
    }

    public int addGrade(Grade grade) {
        String sql = "INSERT INTO Grades (student_id, test_id, score, feedback, graded_by) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, grade.getStudentId());
            pstmt.setInt(2, grade.getTestId());
            pstmt.setDouble(3, grade.getScore());
            pstmt.setString(4, grade.getFeedback());
            pstmt.setInt(5, grade.getGradedBy());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating grade failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating grade failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    public boolean updateGrade(Grade grade) throws SQLException {
        String sql = "UPDATE Grades SET score = ?, feedback = ?, graded_by = ? WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, grade.getScore());
            pstmt.setString(2, grade.getFeedback());
            pstmt.setInt(3, grade.getGradedBy());
            pstmt.setInt(4, grade.getGradeId());

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public boolean deleteGrade(int gradeId) throws SQLException {
        String sql = "DELETE FROM Grades WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gradeId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public Grade getGradeById(int gradeId) throws SQLException {
        String sql = "SELECT * FROM Grades WHERE grade_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, gradeId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapGrade(rs);
                }
            }
        }

        return null;
    }

    public List<Grade> getGradesByTestId(int testId) throws SQLException {
        String sql = "SELECT g.*, s.full_name AS student_name "
                + "FROM Grades g "
                + "JOIN Students s ON g.student_id = s.student_id "
                + "WHERE g.test_id = ? "
                + "ORDER BY g.grade_date DESC";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setStudentName(rs.getString("student_name"));
                    grades.add(grade);
                }
            }
        }

        return grades;
    }

    public List<Grade> getGradesByStudentId(int studentId) {
        String sql = "SELECT g.*, t.title AS test_title "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "WHERE g.student_id = ? "
                + "ORDER BY g.grade_date DESC";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setTestTitle(rs.getString("test_title"));
                    grades.add(grade);
                }
            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return grades;
    }

    public Map<String, Integer> getGradeDistribution() throws SQLException {
        Map<String, Integer> distribution = new HashMap<>();

        String sql = """
        SELECT 
            CASE 
                WHEN score >= 90 THEN 'A'
                WHEN score >= 80 THEN 'B'
                WHEN score >= 70 THEN 'C'
                WHEN score >= 60 THEN 'D'
                ELSE 'F'
            END AS grade,
            COUNT(*) AS count
        FROM grades
        GROUP BY 
            CASE 
                WHEN score >= 90 THEN 'A'
                WHEN score >= 80 THEN 'B'
                WHEN score >= 70 THEN 'C'
                WHEN score >= 60 THEN 'D'
                ELSE 'F'
            END
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String grade = rs.getString("grade");
                int count = rs.getInt("count");
                distribution.put(grade, count);
            }
        }

        return distribution;
    }

    public List<Grade> getGradesByCourseId(int courseId) throws SQLException {
        String sql = "SELECT g.*, s.full_name AS student_name, t.title AS test_title "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "JOIN Students s ON g.student_id = s.student_id "
                + "WHERE t.course_id = ? "
                + "ORDER BY t.test_id, s.full_name";
        List<Grade> grades = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Grade grade = mapGrade(rs);
                    grade.setStudentName(rs.getString("student_name"));
                    grade.setTestTitle(rs.getString("test_title"));
                    grades.add(grade);
                }
            }
        }

        return grades;
    }

    public double getAverageGradeByCourse(int courseId, int studentId) throws SQLException {
        String sql = "SELECT AVG(g.score) AS average_score "
                + "FROM Grades g "
                + "JOIN Tests t ON g.test_id = t.test_id "
                + "WHERE t.course_id = ? AND g.student_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);
            pstmt.setInt(2, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("average_score");
                }
            }
        }
        
        return 0.0;
    }
    
    private Grade mapGrade(ResultSet rs) throws SQLException {
        Grade grade = new Grade();
        grade.setGradeId(rs.getInt("grade_id"));
        grade.setStudentId(rs.getInt("student_id"));
        grade.setTestId(rs.getInt("test_id"));
        grade.setScore(rs.getDouble("score"));
        grade.setFeedback(rs.getString("feedback"));
        grade.setGradeDate(rs.getTimestamp("grade_date"));
        grade.setGradedBy(rs.getInt("graded_by"));

        return grade;
    }

    public boolean saveGrade(Grade grade) throws SQLException {
        String sql = "MERGE INTO grades AS target "
                + "USING (SELECT ? AS student_id, ? AS test_id) AS source "
                + "ON target.student_id = source.student_id AND target.test_id = source.test_id "
                + "WHEN MATCHED THEN "
                + "  UPDATE SET score=?, max_score=?, grade_type=?, comment=?, graded_by=?, graded_at=?, course_id=?, assignment_id=NULL "
                + "WHEN NOT MATCHED THEN "
                + "  INSERT (student_id, test_id, score, max_score, grade_type, comment, graded_by, graded_at, course_id) "
                + "  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            int i = 1;
            stmt.setInt(i++, grade.getStudentId());
            stmt.setInt(i++, grade.getTestId());
            stmt.setDouble(i++, grade.getScore());
            stmt.setDouble(i++, grade.getScore());
            stmt.setString(i++, grade.getGrade_type());
            stmt.setString(i++, grade.getFeedback());
            stmt.setInt(i++, grade.getGradedBy());
            stmt.setTimestamp(i++, new Timestamp(grade.getGradeDate().getTime()));
            stmt.setInt(i++, grade.getCourse_id());
            stmt.setInt(i++, grade.getStudentId());
            stmt.setInt(i++, grade.getTestId());
            stmt.setDouble(i++, grade.getScore());
            stmt.setDouble(i++, grade.getMax_score());
            stmt.setString(i++, grade.getGrade_type());
            stmt.setString(i++, grade.getFeedback());
            stmt.setInt(i++, grade.getGradedBy());
            stmt.setTimestamp(i++, new Timestamp(grade.getGradeDate().getTime()));
            stmt.setInt(i++, grade.getCourse_id());
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Lấy điểm số chi tiết của sinh viên với thông tin khóa học
     */
    public List<Map<String, Object>> getDetailedGradesByStudentId(int studentId) throws SQLException {
        List<Map<String, Object>> grades = new ArrayList<>();
        
        String sql = """
            SELECT g.grade_id, g.score, g.max_score, g.grade_type, g.comment, g.graded_at,
                   c.name as course_name, c.code as course_code, c.credits,
                   s.name as semester_name, s.code as semester_code,
                   a.title as assignment_title, a.assignment_type,
                   t.title as test_title, t.test_type,
                   l.full_name as lecturer_name
            FROM grades g
            INNER JOIN courses c ON g.course_id = c.course_id
            INNER JOIN semesters s ON c.semester_id = s.semester_id
            INNER JOIN lecturers l ON c.lecturer_id = l.lecturer_id
            LEFT JOIN assignments a ON g.assignment_id = a.assignment_id
            LEFT JOIN tests t ON g.test_id = t.test_id
            WHERE g.student_id = ?
            ORDER BY g.graded_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> grade = new HashMap<>();
                grade.put("grade_id", rs.getInt("grade_id"));
                grade.put("score", rs.getDouble("score"));
                grade.put("max_score", rs.getDouble("max_score"));
                grade.put("grade_type", rs.getString("grade_type"));
                grade.put("comment", rs.getString("comment"));
                grade.put("graded_at", rs.getTimestamp("graded_at"));
                grade.put("course_name", rs.getString("course_name"));
                grade.put("course_code", rs.getString("course_code"));
                grade.put("credits", rs.getInt("credits"));
                grade.put("semester_name", rs.getString("semester_name"));
                grade.put("semester_code", rs.getString("semester_code"));
                grade.put("assignment_title", rs.getString("assignment_title"));
                grade.put("assignment_type", rs.getString("assignment_type"));
                grade.put("test_title", rs.getString("test_title"));
                grade.put("test_type", rs.getString("test_type"));
                grade.put("lecturer_name", rs.getString("lecturer_name"));
                
                // Tính điểm theo thang 10
                double normalizedScore = (rs.getDouble("score") / rs.getDouble("max_score")) * 10;
                grade.put("normalized_score", normalizedScore);
                
                grades.add(grade);
            }
        }
        
        return grades;
    }
    
    /**
     * Tính GPA của sinh viên
     */
    public double calculateGPA(int studentId) throws SQLException {
        String sql = """
            SELECT AVG(
                CASE 
                    WHEN g.grade_type = 'final' THEN (g.score / g.max_score) * 10
                    ELSE NULL 
                END
            ) as gpa
            FROM grades g
            WHERE g.student_id = ? AND g.grade_type = 'final'
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                double gpa = rs.getDouble("gpa");
                return Math.round(gpa * 100.0) / 100.0; // Làm tròn 2 chữ số thập phân
            }
        }
        
        return 0.0;
    }
    
    /**
     * Thống kê môn học (đạt/không đạt)
     */
    public Map<String, Integer> getCourseStatistics(int studentId) throws SQLException {
        Map<String, Integer> stats = new HashMap<>();
        
        String sql = """
            SELECT 
                COUNT(CASE WHEN (g.score / g.max_score) * 10 >= 5 THEN 1 END) as passed,
                COUNT(CASE WHEN (g.score / g.max_score) * 10 < 5 THEN 1 END) as failed,
                COUNT(*) as total
            FROM grades g
            WHERE g.student_id = ? AND g.grade_type = 'final'
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                stats.put("passed", rs.getInt("passed"));
                stats.put("failed", rs.getInt("failed"));
                stats.put("total", rs.getInt("total"));
            }
        }
        
        return stats;
    }
    
    /**
     * Lấy GPA theo semester
     */
    public Map<String, Double> getGPABySemester(int studentId) throws SQLException {
        Map<String, Double> semesterGPAs = new HashMap<>();
        
        String sql = """
            SELECT s.code as semester_code, s.name as semester_name, s.start_date,
                   AVG((g.score / g.max_score) * 10) as avg_score
            FROM grades g
            INNER JOIN courses c ON g.course_id = c.course_id
            INNER JOIN semesters s ON c.semester_id = s.semester_id
            WHERE g.student_id = ? AND g.grade_type = 'final'
            GROUP BY s.semester_id, s.code, s.name, s.start_date
            ORDER BY s.start_date DESC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                String semesterCode = rs.getString("semester_code");
                double avgScore = rs.getDouble("avg_score");
                semesterGPAs.put(semesterCode, Math.round(avgScore * 100.0) / 100.0);
            }
        }
        
        return semesterGPAs;
    }
    
    /**
     * Lấy xu hướng điểm số trong N tháng gần nhất
     */
    public List<Map<String, Object>> getGradesTrend(int studentId, int months) throws SQLException {
        List<Map<String, Object>> trend = new ArrayList<>();
        
        String sql = """
            SELECT 
                YEAR(g.graded_at) as year,
                MONTH(g.graded_at) as month,
                AVG((g.score / g.max_score) * 10) as avg_score,
                COUNT(*) as grade_count
            FROM grades g
            WHERE g.student_id = ? 
                AND g.graded_at >= DATEADD(month, -?, GETDATE())
            GROUP BY YEAR(g.graded_at), MONTH(g.graded_at)
            ORDER BY YEAR(g.graded_at) DESC, MONTH(g.graded_at) DESC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, months);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> monthData = new HashMap<>();
                monthData.put("year", rs.getInt("year"));
                monthData.put("month", rs.getInt("month"));
                monthData.put("avg_score", Math.round(rs.getDouble("avg_score") * 100.0) / 100.0);
                monthData.put("grade_count", rs.getInt("grade_count"));
                
                trend.add(monthData);
            }
        }
        
        return trend;
    }
    
    /**
     * Thống kê theo loại điểm
     */
    public Map<String, Double> getGradeTypeStatistics(int studentId) throws SQLException {
        Map<String, Double> typeStats = new HashMap<>();
        
        String sql = """
            SELECT 
                g.grade_type,
                AVG((g.score / g.max_score) * 10) as avg_score,
                COUNT(*) as count
            FROM grades g
            WHERE g.student_id = ?
            GROUP BY g.grade_type
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                String gradeType = rs.getString("grade_type");
                double avgScore = rs.getDouble("avg_score");
                typeStats.put(gradeType, Math.round(avgScore * 100.0) / 100.0);
            }
        }
        
        return typeStats;
    }

}
