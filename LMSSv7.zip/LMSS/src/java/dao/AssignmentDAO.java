package dao;

import java.sql.*;
import java.util.*;
import model.Assignment;
import utils.DBConnection;

public class AssignmentDAO {
    public List<Assignment> getAssignmentsByCourse(int courseId) throws Exception {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT * FROM assignments WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Assignment a = new Assignment(
                        rs.getInt("assignment_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getTimestamp("due_date"),
                        rs.getString("assignment_type")  // Sửa từ "type" thành "assignment_type"
                    );
                    list.add(a);
                }
            }
        }
        return list;
    }
    
    public List<Assignment> getAssignmentsByStudentId(int studentId) throws Exception {
        List<Assignment> list = new ArrayList<>();
        String sql = """
            SELECT DISTINCT a.* FROM assignments a
            JOIN courses c ON a.course_id = c.course_id
            JOIN enrollments e ON c.course_id = e.course_id
            WHERE e.student_id = ? AND e.status = 'active'
            ORDER BY a.due_date ASC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Assignment a = new Assignment(
                        rs.getInt("assignment_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getTimestamp("due_date"),
                        rs.getString("assignment_type")  // Sửa để chỉ dùng assignment_type
                    );
                    list.add(a);
                }
            }
        }
        return list;
    }
    
    public Assignment getAssignmentById(int assignmentId) throws Exception {
        String sql = "SELECT * FROM assignments WHERE assignment_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Assignment(
                        rs.getInt("assignment_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getTimestamp("due_date"),
                        rs.getString("assignment_type")  // Sửa từ "type" thành "assignment_type"
                    );
                }
            }
        }
        return null;
    }
    
    public boolean createAssignment(Assignment assignment) throws Exception {
        String sql = "INSERT INTO assignments (course_id, title, description, due_date, assignment_type, created_by) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignment.getCourseId());
            ps.setString(2, assignment.getTitle());
            ps.setString(3, assignment.getDescription());
            ps.setTimestamp(4, assignment.getDueDate());
            ps.setString(5, assignment.getType());  // Sẽ insert vào cột assignment_type
            ps.setInt(6, 1); // Tạm thời set created_by = 1, sau này có thể truyền từ session
            return ps.executeUpdate() > 0;
        }
    }
    
    public boolean updateAssignment(Assignment assignment) throws Exception {
        String sql = "UPDATE assignments SET title = ?, description = ?, due_date = ?, assignment_type = ? WHERE assignment_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, assignment.getTitle());
            ps.setString(2, assignment.getDescription());
            ps.setTimestamp(3, assignment.getDueDate());
            ps.setString(4, assignment.getType());  // Update cột assignment_type
            ps.setInt(5, assignment.getAssignmentId());
            return ps.executeUpdate() > 0;
        }
    }
    
    public boolean deleteAssignment(int assignmentId) throws Exception {
        String sql = "DELETE FROM assignments WHERE assignment_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            return ps.executeUpdate() > 0;
        }
    }
    
    public int getAssignmentCountByCourseId(int courseId) throws Exception {
        String sql = "SELECT COUNT(*) FROM assignments WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
    
    public List<Assignment> getAssignmentsByLecturerId(int lecturerId) throws Exception {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT a.* FROM assignments a JOIN courses c ON a.course_id = c.course_id WHERE c.lecturer_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Assignment a = new Assignment(
                        rs.getInt("assignment_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getTimestamp("due_date"),
                        rs.getString("assignment_type")  // Sửa từ "type" thành "assignment_type"
                    );
                    list.add(a);
                }
            }
        }
        return list;
    }
        // Lấy bài tập sắp tới của sinh viên
    public List<Assignment> getUpcomingAssignmentsByStudent(int studentId) {
        List<Assignment> assignments = new ArrayList<>();
        String sql = "SELECT a.assignment_id, a.title, a.description, a.due_date, " +
                    "a.max_score, a.assignment_type, c.name as course_name, " +
                    "c.code as course_code, s.submission_id " +
                    "FROM assignments a " +
                    "JOIN courses c ON a.course_id = c.course_id " +
                    "JOIN enrollments e ON c.course_id = e.course_id " +
                    "LEFT JOIN submissions s ON a.assignment_id = s.assignment_id AND s.student_id = ? " +
                    "WHERE e.student_id = ? AND e.status = 'active' " +
                    "AND a.due_date > GETDATE() " +
                    "ORDER BY a.due_date ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Assignment assignment = new Assignment();
                assignment.setAssignmentId(rs.getInt("assignment_id"));
                assignment.setTitle(rs.getString("title"));
                assignment.setDescription(rs.getString("description"));
                assignment.setDueDate(rs.getTimestamp("due_date"));
                assignment.setMaxScore(rs.getFloat("max_score"));
                assignment.setAssignmentType(rs.getString("assignment_type"));
                assignment.setCourseName(rs.getString("course_name"));
                assignment.setCourseCode(rs.getString("course_code"));
                assignment.setSubmitted(rs.getObject("submission_id") != null);
                
                assignments.add(assignment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return assignments;
    }
}