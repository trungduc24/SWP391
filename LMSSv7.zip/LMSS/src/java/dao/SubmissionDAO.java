package dao;

import java.sql.*;
import java.util.*;
import model.Submission;
import utils.DBConnection;

public class SubmissionDAO {
    
    // Tạo hoặc cập nhật submission
    public boolean submitAssignment(Submission submission) throws SQLException {
        String checkSql = "SELECT submission_id FROM submissions WHERE assignment_id = ? AND student_id = ?";
        String insertSql = "INSERT INTO submissions (assignment_id, student_id, submission_text, file_url, status) VALUES (?, ?, ?, ?, ?)";
        String updateSql = "UPDATE submissions SET submission_text = ?, file_url = ?, submitted_at = GETDATE(), status = ? WHERE assignment_id = ? AND student_id = ?";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Kiểm tra xem đã nộp bài chưa
            boolean hasSubmitted = false;
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setInt(1, submission.getAssignmentId());
                checkPs.setInt(2, submission.getStudentId());
                try (ResultSet rs = checkPs.executeQuery()) {
                    hasSubmitted = rs.next();
                }
            }
            
            // Xác định trạng thái (kiểm tra hạn nộp)
            String status = determineSubmissionStatus(submission.getAssignmentId());
            
            if (hasSubmitted) {
                // Cập nhật submission
                try (PreparedStatement updatePs = conn.prepareStatement(updateSql)) {
                    updatePs.setString(1, submission.getSubmissionText());
                    updatePs.setString(2, submission.getFileUrl());
                    updatePs.setString(3, status);
                    updatePs.setInt(4, submission.getAssignmentId());
                    updatePs.setInt(5, submission.getStudentId());
                    return updatePs.executeUpdate() > 0;
                }
            } else {
                // Tạo submission mới
                try (PreparedStatement insertPs = conn.prepareStatement(insertSql)) {
                    insertPs.setInt(1, submission.getAssignmentId());
                    insertPs.setInt(2, submission.getStudentId());
                    insertPs.setString(3, submission.getSubmissionText());
                    insertPs.setString(4, submission.getFileUrl());
                    insertPs.setString(5, status);
                    return insertPs.executeUpdate() > 0;
                }
            }
        }
    }
    
    // Lấy submission của sinh viên cho assignment
    public Submission getSubmissionByStudentAndAssignment(int studentId, int assignmentId) throws SQLException {
        String sql = """
            SELECT s.*, a.title as assignment_title, c.name as course_name, st.full_name as student_name
            FROM submissions s
            JOIN assignments a ON s.assignment_id = a.assignment_id
            JOIN courses c ON a.course_id = c.course_id
            JOIN students st ON s.student_id = st.student_id
            WHERE s.student_id = ? AND s.assignment_id = ?
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, assignmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Submission submission = new Submission(
                        rs.getInt("submission_id"),
                        rs.getInt("assignment_id"),
                        rs.getInt("student_id"),
                        rs.getString("submission_text"),
                        rs.getString("file_url"),
                        rs.getTimestamp("submitted_at"),
                        rs.getObject("score", Double.class),
                        rs.getString("feedback"),
                        rs.getString("status"),
                        rs.getObject("graded_by", Integer.class),
                        rs.getTimestamp("graded_at")
                    );
                    submission.setAssignmentTitle(rs.getString("assignment_title"));
                    submission.setCourseName(rs.getString("course_name"));
                    submission.setStudentName(rs.getString("student_name"));
                    return submission;
                }
            }
        }
        return null;
    }
    
    // Lấy tất cả submissions của sinh viên
    public List<Submission> getSubmissionsByStudent(int studentId) throws SQLException {
        List<Submission> submissions = new ArrayList<>();
        String sql = """
            SELECT s.*, a.title as assignment_title, c.name as course_name, a.due_date,
                   st.full_name as student_name
            FROM submissions s
            JOIN assignments a ON s.assignment_id = a.assignment_id
            JOIN courses c ON a.course_id = c.course_id
            JOIN students st ON s.student_id = st.student_id
            WHERE s.student_id = ?
            ORDER BY s.submitted_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Submission submission = new Submission(
                        rs.getInt("submission_id"),
                        rs.getInt("assignment_id"),
                        rs.getInt("student_id"),
                        rs.getString("submission_text"),
                        rs.getString("file_url"),
                        rs.getTimestamp("submitted_at"),
                        rs.getObject("score", Double.class),
                        rs.getString("feedback"),
                        rs.getString("status"),
                        rs.getObject("graded_by", Integer.class),
                        rs.getTimestamp("graded_at")
                    );
                    submission.setAssignmentTitle(rs.getString("assignment_title"));
                    submission.setCourseName(rs.getString("course_name"));
                    submission.setStudentName(rs.getString("student_name"));
                    submissions.add(submission);
                }
            }
        }
        return submissions;
    }
    
    // Lấy submissions cho assignment (dành cho giảng viên)
    public List<Submission> getSubmissionsByAssignment(int assignmentId) throws SQLException {
        List<Submission> submissions = new ArrayList<>();
        String sql = """
            SELECT s.*, a.title as assignment_title, c.name as course_name,
                   st.full_name as student_name, st.student_code
            FROM submissions s
            JOIN assignments a ON s.assignment_id = a.assignment_id
            JOIN courses c ON a.course_id = c.course_id
            JOIN students st ON s.student_id = st.student_id
            WHERE s.assignment_id = ?
            ORDER BY s.submitted_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Submission submission = new Submission(
                        rs.getInt("submission_id"),
                        rs.getInt("assignment_id"),
                        rs.getInt("student_id"),
                        rs.getString("submission_text"),
                        rs.getString("file_url"),
                        rs.getTimestamp("submitted_at"),
                        rs.getObject("score", Double.class),
                        rs.getString("feedback"),
                        rs.getString("status"),
                        rs.getObject("graded_by", Integer.class),
                        rs.getTimestamp("graded_at")
                    );
                    submission.setAssignmentTitle(rs.getString("assignment_title"));
                    submission.setCourseName(rs.getString("course_name"));
                    submission.setStudentName(rs.getString("student_name"));
                    submissions.add(submission);
                }
            }
        }
        return submissions;
    }
    
    // Xác định trạng thái submission (kiểm tra hạn nộp)
    private String determineSubmissionStatus(int assignmentId) throws SQLException {
        String sql = "SELECT due_date FROM assignments WHERE assignment_id = ?";
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Timestamp dueDate = rs.getTimestamp("due_date");
                    if (dueDate != null && new Timestamp(System.currentTimeMillis()).after(dueDate)) {
                        return "late";
                    }
                }
            }
        }
        return "submitted";
    }
}