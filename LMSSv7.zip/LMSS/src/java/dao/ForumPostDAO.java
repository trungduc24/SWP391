package dao;

import java.sql.*;
import java.util.*;
import model.ForumPost;
import utils.DBConnection;

public class ForumPostDAO {
    
    public List<ForumPost> getPostsByForumId(int forumId) throws Exception {
        List<ForumPost> list = new ArrayList<>();
        String sql = """
                    SELECT p.*, u.full_name, u.avatar_url 
                    FROM forum_posts p
                    JOIN users u ON p.user_id = u.user_id
                    WHERE p.forum_id = ?
                    ORDER BY p.created_at ASC
                """;
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, forumId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ForumPost post = new ForumPost(
                        rs.getInt("post_id"),
                        rs.getInt("forum_id"),
                        rs.getInt("user_id"),
                        rs.getString("content"),
                        rs.getTimestamp("created_at"),
                        rs.getString("full_name"),
                        rs.getString("avatar_url")
                    );
                    list.add(post);
                }
            }
        }
        return list;
    }
    
    public ForumPost getPostById(int postId) throws Exception {
        String sql = """
                    SELECT p.*, u.full_name, u.avatar_url 
                    FROM forum_posts p
                    JOIN users u ON p.user_id = u.user_id
                    WHERE p.post_id = ?
                """;
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, postId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new ForumPost(
                        rs.getInt("post_id"),
                        rs.getInt("forum_id"),
                        rs.getInt("user_id"),
                        rs.getString("content"),
                        rs.getTimestamp("created_at"),
                        rs.getString("full_name"),
                        rs.getString("avatar_url")
                    );
                }
            }
        }
        return null;
    }
    
    public int createPost(ForumPost post) throws Exception {
        String sql = "INSERT INTO forum_posts (forum_id, user_id, content, created_at) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, post.getForumId());
            ps.setInt(2, post.getUserId());
            ps.setString(3, post.getContent());
            
            // If createdAt is null, use current timestamp
            if (post.getCreatedAt() == null) {
                ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            } else {
                ps.setTimestamp(4, post.getCreatedAt());
            }
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating forum post failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating forum post failed, no ID obtained.");
                }
            }
        }
    }
    
    public boolean updatePost(ForumPost post) throws Exception {
        String sql = "UPDATE forum_posts SET content = ? WHERE post_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, post.getContent());
            ps.setInt(2, post.getPostId());
            ps.setInt(3, post.getUserId()); // Ensure the user is the owner of the post
            return ps.executeUpdate() > 0;
        }
    }
    
    public boolean deletePost(int postId, int userId) throws Exception {
        String sql = "DELETE FROM forum_posts WHERE post_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, postId);
            ps.setInt(2, userId); // Ensure the user is the owner of the post
            return ps.executeUpdate() > 0;
        }
    }
    
    // Allow admins or lecturers to delete any post
    public boolean adminDeletePost(int postId) throws Exception {
        String sql = "DELETE FROM forum_posts WHERE post_id = ?";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, postId);
            return ps.executeUpdate() > 0;
        }
    }
    
    public int countPostsByForumId(int forumId) throws Exception {
        String sql = "SELECT COUNT(*) FROM forum_posts WHERE forum_id = ?";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, forumId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
    
    public List<ForumPost> getRecentPostsByUser(int userId, int limit) throws Exception {
        List<ForumPost> list = new ArrayList<>();
        String sql = """
                    SELECT p.*, u.full_name, u.avatar_url, f.title as forum_title
                    FROM forum_posts p
                    JOIN users u ON p.user_id = u.user_id
                    JOIN forums f ON p.forum_id = f.forum_id
                    WHERE p.user_id = ?
                    ORDER BY p.created_at DESC
                    LIMIT ?
                """;
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ForumPost post = new ForumPost(
                        rs.getInt("post_id"),
                        rs.getInt("forum_id"),
                        rs.getInt("user_id"),
                        rs.getString("content"),
                        rs.getTimestamp("created_at"),
                        rs.getString("full_name"),
                        rs.getString("avatar_url")
                    );
                    list.add(post);
                }
            }
        }
        return list;
    }
} 