package dao;

import model.Course;
import utils.DBConnection; // Đảm bảo bạn có lớp DBConnection này

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.CourseDisplayModel;

public class CourseDAO {

    public CourseDAO() {
    }

    // Thêm khóa học mới
    public boolean addCourse(Course course) throws SQLException {
        String INSERT_COURSE_SQL = "INSERT INTO courses (name, code, description, room, lecturer_id, semester_id, total_sessions, credits, max_students, schedule, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE())";

        System.out.println("=== DEBUG: addCourse called ===");
        System.out.println("Course name: " + course.getName());
        System.out.println("Course code: " + course.getCode());
        System.out.println("Lecturer ID: " + course.getLecturerId());
        System.out.println("Semester ID: " + course.getSemesterId());
        System.out.println("SQL: " + INSERT_COURSE_SQL);

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_COURSE_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, course.getName());
            preparedStatement.setString(2, course.getCode());
            preparedStatement.setString(3, course.getDescription());
            preparedStatement.setString(4, course.getRoom());
            preparedStatement.setInt(5, course.getLecturerId());
            preparedStatement.setInt(6, course.getSemesterId());
            preparedStatement.setInt(7, course.getTotalSessions());
            preparedStatement.setInt(8, course.getCredits());
            preparedStatement.setInt(9, course.getMaxStudents());
            preparedStatement.setString(10, course.getSchedule());
            preparedStatement.setString(11, course.isActive() ? "active" : "inactive");

            System.out.println("About to execute SQL...");
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Rows affected: " + rowsAffected);

            if (rowsAffected > 0) {
                try (ResultSet rs = preparedStatement.getGeneratedKeys()) {
                    if (rs.next()) {
                        course.setCourseId(rs.getInt(1));
                        System.out.println("Course created with ID: " + course.getCourseId());
                    } else {
                        System.out.println("No generated keys returned!");
                    }
                }
                System.out.println("=== DEBUG: addCourse completed ===");
                return true;
            }

        } catch (SQLException e) {
            System.out.println("SQL Error in addCourse: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }

        return false;
    }

    public List<Course> getAvailableCoursesForStudent(int studentId) {
        List<Course> courses = new ArrayList<>();

        String sql = """
        SELECT * FROM courses
        WHERE course_id NOT IN (
            SELECT course_id FROM enrollments WHERE student_id = ?
        ) AND status = 1
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setActive(rs.getBoolean("status"));
                    course.setCreatedAt(rs.getTimestamp("created_at"));

                    courses.add(course);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }

    // Lấy tất cả khóa học
    public List<Course> getAllCourses() throws SQLException {
        List<Course> courses = new ArrayList<>();
        String SELECT_ALL_COURSES_SQL = "SELECT course_id, name, code, description, room, lecturer_id, semester_id, total_sessions, credits, max_students, status, schedule, created_at FROM courses";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_COURSES_SQL); ResultSet rs = preparedStatement.executeQuery()) {

            while (rs.next()) {
                int courseId = rs.getInt("course_id");
                String name = rs.getString("name");
                String code = rs.getString("code");
                String description = rs.getString("description");
                String room = rs.getString("room");
                int lecturerId = rs.getInt("lecturer_id");
                int semesterId = rs.getInt("semester_id");
                int totalSessions = rs.getInt("total_sessions");
                int credits = rs.getInt("credits");
                int maxStudents = rs.getInt("max_students");
                String status = rs.getString("status");
                String schedule = rs.getString("schedule");

                Course course = new Course(courseId, name, code, room, lecturerId, semesterId, totalSessions);
                course.setDescription(description);
                course.setCredits(credits);
                course.setMaxStudents(maxStudents);
                course.setSchedule(schedule);
                course.setActive("active".equals(status));
                course.setCreatedAt(rs.getTimestamp("created_at"));
                courses.add(course);
            }
        }
        return courses;
    }

    // Lấy khóa học theo ID
    public Course getCourseById(int courseId) throws SQLException {
        Course course = null;
        String SELECT_COURSE_BY_ID_SQL = "SELECT course_id, name, code, room, lecturer_id, semester_id, total_sessions FROM courses WHERE course_id = ?";
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_COURSE_BY_ID_SQL)) {
            preparedStatement.setInt(1, courseId);
            try (ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("name");
                    String code = rs.getString("code");
                    String room = rs.getString("room");
                    int lecturerId = rs.getInt("lecturer_id");
                    int semesterId = rs.getInt("semester_id");
                    int totalSessions = rs.getInt("total_sessions");
                    course = new Course(courseId, name, code, room, lecturerId, semesterId, totalSessions);
                }
            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return course;
    }

    // Lấy khóa học theo mã code
    public Course getCourseByCode(String code) throws SQLException {
        Course course = null;
        String SELECT_COURSE_BY_CODE_SQL = "SELECT course_id, name, code, room, lecturer_id, semester_id, total_sessions FROM courses WHERE code = ?";
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_COURSE_BY_CODE_SQL)) {
            preparedStatement.setString(1, code);
            try (ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    String name = rs.getString("name");
                    String courseCode = rs.getString("code");
                    String room = rs.getString("room");
                    int lecturerId = rs.getInt("lecturer_id");
                    int semesterId = rs.getInt("semester_id");
                    int totalSessions = rs.getInt("total_sessions");
                    course = new Course(courseId, name, courseCode, room, lecturerId, semesterId, totalSessions);
                }
            }
        }
        return course;
    }

    // Lấy khóa học theo lecturer ID
    public List<Course> getCoursesByLecturer(int lecturerId) throws SQLException {
        List<Course> courses = new ArrayList<>();
        String SELECT_COURSES_BY_LECTURER_SQL = "SELECT course_id, name, code, description, room, lecturer_id, semester_id, total_sessions, credits, max_students, is_active FROM courses WHERE lecturer_id = ? ORDER BY created_at DESC";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_COURSES_BY_LECTURER_SQL)) {
            preparedStatement.setInt(1, lecturerId);
            try (ResultSet rs = preparedStatement.executeQuery()) {
                while (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    String name = rs.getString("name");
                    String code = rs.getString("code");
                    String description = rs.getString("description");
                    String room = rs.getString("room");
                    int semesterId = rs.getInt("semester_id");
                    int totalSessions = rs.getInt("total_sessions");
                    int credits = rs.getInt("credits");
                    int maxStudents = rs.getInt("max_students");
                    boolean isActive = rs.getBoolean("is_active");

                    Course course = new Course(courseId, name, code, room, lecturerId, semesterId, totalSessions);
                    course.setDescription(description);
                    course.setCredits(credits);
                    course.setMaxStudents(maxStudents);
                    course.setActive(isActive);
                    courses.add(course);
                }
            }
        }
        return courses;
    }

    // Xóa khóa học
    public boolean deleteCourse(int courseId) {
        String DELETE_COURSE_SQL = "DELETE FROM courses WHERE course_id = ?";
        System.out.println("CourseDAO.deleteCourse - SQL: " + DELETE_COURSE_SQL);
        System.out.println("CourseDAO.deleteCourse - Course ID: " + courseId);

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(DELETE_COURSE_SQL)) {

            preparedStatement.setInt(1, courseId);
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("CourseDAO.deleteCourse - Rows affected: " + rowsAffected);

            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Delete course failed: " + e.getMessage());
            return false;
        }
    }

    // Cập nhật khóa học
    public boolean updateCourse(Course course) throws SQLException {
        String UPDATE_COURSE_SQL = "UPDATE courses SET name = ?, code = ?, description = ?, room = ?, semester_id = ?, "
                + "total_sessions = ?, credits = ?, max_students = ?, schedule = ?, status = ?, updated_at = GETDATE() "
                + "WHERE course_id = ?";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_COURSE_SQL)) {

            preparedStatement.setString(1, course.getName());
            preparedStatement.setString(2, course.getCode());
            preparedStatement.setString(3, course.getDescription());
            preparedStatement.setString(4, course.getRoom());
            preparedStatement.setInt(5, course.getSemesterId());
            preparedStatement.setInt(6, course.getTotalSessions());
            preparedStatement.setInt(7, course.getCredits());
            preparedStatement.setInt(8, course.getMaxStudents());
            preparedStatement.setString(9, course.getSchedule());
            preparedStatement.setString(10, course.isActive() ? "active" : "inactive");
            preparedStatement.setInt(11, course.getCourseId());

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Update course - Rows affected: " + rowsAffected);
            return rowsAffected > 0;
        }
    }

    // Lấy khóa học đầy đủ thông tin theo ID
    public Course getCourseByIdFull(int courseId) throws SQLException {
        Course course = null;
        String SELECT_COURSE_FULL_SQL = "SELECT * FROM courses WHERE course_id = ?";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_COURSE_FULL_SQL)) {
            preparedStatement.setInt(1, courseId);

            try (ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setSemesterId(rs.getInt("semester_id"));

                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setActive(rs.getBoolean("is_active"));
                    course.setCreatedAt(rs.getTimestamp("created_at"));
                }
            }
        }
        return course;
    }

    // Lấy danh sách khóa học theo lecturer ID
    public List<Course> getCoursesByLecturerId(int lecturerId) throws SQLException {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM courses WHERE lecturer_id = ? ORDER BY created_at DESC";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setSemesterId(rs.getInt("semester_id"));

                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setSchedule(rs.getString("schedule"));
                    String status = rs.getString("status");
                    course.setActive("active".equals(status));
                    course.setCreatedAt(rs.getTimestamp("created_at"));
                    courses.add(course);
                }
            }
        }
        return courses;
    }

    // Đếm tổng số khóa học
    public int countCourses() throws SQLException {
        String COUNT_COURSES_SQL = "SELECT COUNT(*) FROM courses";
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(COUNT_COURSES_SQL); ResultSet rs = preparedStatement.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        CourseDAO courseDAO = new CourseDAO();

        try {
            int testLecturerId = 1; // ✅ Thay bằng `lecturer_id` thực tế trong DB của bạn
            List<Course> courses = courseDAO.getCoursesByLecturerId(testLecturerId);

            if (courses.isEmpty()) {
                System.out.println("Không có khóa học nào cho giảng viên ID = " + testLecturerId);
            } else {
                System.out.println("Danh sách khóa học:");
                for (Course course : courses) {
                    System.out.println(" - ID: " + course.getCourseId());
                    System.out.println("   Tên: " + course.getName());
                    System.out.println("   Mã: " + course.getCode());
                    System.out.println("   Phòng: " + course.getRoom());
                    System.out.println("   Lịch học: " + course.getSchedule());
                    System.out.println("   Số tín chỉ: " + course.getCredits());
                    System.out.println("   Trạng thái: " + (course.isActive() ? "Đang mở" : "Đóng"));
                    System.out.println("--------------");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Lỗi khi lấy danh sách khóa học.");
        }
    }

    // Đếm số khóa học đang hoạt động
    public int countActiveCourses() throws SQLException {
        String COUNT_ACTIVE_COURSES_SQL = "SELECT COUNT(*) FROM courses WHERE status = 'active'";
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(COUNT_ACTIVE_COURSES_SQL); ResultSet rs = preparedStatement.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // Đếm số khóa học không hoạt động
    public int countInactiveCourses() throws SQLException {
        String COUNT_INACTIVE_COURSES_SQL = "SELECT COUNT(*) FROM courses WHERE status = 'inactive'";
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(COUNT_INACTIVE_COURSES_SQL); ResultSet rs = preparedStatement.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // Tìm kiếm khóa học theo tên hoặc mã
    public List<Course> searchCourses(String keyword) throws SQLException {
        List<Course> courses = new ArrayList<>();
        String SEARCH_COURSES_SQL = "SELECT * FROM courses WHERE name LIKE ? OR code LIKE ?";

        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SEARCH_COURSES_SQL)) {

            preparedStatement.setString(1, "%" + keyword + "%");
            preparedStatement.setString(2, "%" + keyword + "%");

            try (ResultSet rs = preparedStatement.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setActive("active".equals(rs.getString("status")));
                    course.setCreatedAt(rs.getTimestamp("created_at"));
                    courses.add(course);
                }
            }
        }

        return courses;
    }

    private Course extractCourseFromResultSet(ResultSet rs) throws SQLException {
        Course course = new Course();
        course.setCourseId(rs.getInt("course_id"));
        course.setName(rs.getString("name"));
        course.setCode(rs.getString("code"));
        course.setDescription(rs.getString("description"));
        course.setRoom(rs.getString("room"));
        course.setLecturerId(rs.getInt("lecturer_id"));
        course.setSemesterId(rs.getInt("semester_id"));
        course.setTotalSessions(rs.getInt("total_sessions"));
        course.setCredits(rs.getInt("credits"));
        course.setMaxStudents(rs.getInt("max_students"));
        course.setSchedule(rs.getString("schedule"));
        course.setActive(rs.getBoolean("status"));
        course.setCreatedAt(rs.getTimestamp("created_at"));
        return course;
    }

    public List<Course> searchCoursesByLecturer(int lecturerId, String keyword) {
        List<Course> courses = new ArrayList<>();
        String sql = """
        SELECT * FROM courses 
        WHERE lecturer_id = ? AND (name LIKE ? OR code LIKE ?)
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Course course = extractCourseFromResultSet(rs);
                courses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    public List<Course> searchCoursesByLecturerAndSemester(int lecturerId, int semesterId, String keyword) {
        List<Course> courses = new ArrayList<>();
        String sql = """
        SELECT * FROM courses 
        WHERE lecturer_id = ? AND semester_id = ? AND (name LIKE ? OR code LIKE ?)
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ps.setInt(2, semesterId);
            ps.setString(3, "%" + keyword + "%");
            ps.setString(4, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Course course = extractCourseFromResultSet(rs);
                courses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    public List<Course> getCoursesByStudentId(int studentId) throws SQLException {
        List<Course> courses = new ArrayList<>();

        String sql = "SELECT c.* FROM courses c "
                + "JOIN enrollments e ON c.course_id = e.course_id "
                + "WHERE e.student_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setCreatedAt(rs.getTimestamp("created_at"));

                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error in getCoursesByStudentId: " + e.getMessage());
            throw e;
        }

        return courses;
    }

    public List<CourseDisplayModel> getEnrolledCoursesWithDetails(int studentId) throws SQLException {
        List<CourseDisplayModel> courses = new ArrayList<>();

        String sql = """
        SELECT 
            c.course_id, c.name, c.code, c.description, c.room, c.schedule,
            c.total_sessions, c.credits, c.max_students, c.status,
            l.lecturer_id, l.full_name as lecturer_name, l.lecturer_code, l.department as lecturer_department,
            s.semester_id, s.name as semester_name,
            e.enrollment_id, e.current_session, e.status as enrollment_status, e.final_grade,
            COUNT(e2.enrollment_id) as enrolled_students
        FROM courses c
        INNER JOIN enrollments e ON c.course_id = e.course_id
        INNER JOIN lecturers l ON c.lecturer_id = l.lecturer_id
        INNER JOIN semesters s ON c.semester_id = s.semester_id
        LEFT JOIN enrollments e2 ON c.course_id = e2.course_id AND e2.status = 'active'
        WHERE e.student_id = ? AND e.status = 'active'
        GROUP BY c.course_id, c.name, c.code, c.description, c.room, c.schedule,
                 c.total_sessions, c.credits, c.max_students, c.status,
                 l.lecturer_id, l.full_name, l.lecturer_code, l.department,
                 s.semester_id, s.name,
                 e.enrollment_id, e.current_session, e.status, e.final_grade
        ORDER BY c.name
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    CourseDisplayModel course = new CourseDisplayModel();

                    // Thông tin khóa học
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setStatus(rs.getString("status"));

                    // Thông tin giảng viên
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setLecturerName(rs.getString("lecturer_name"));
                    course.setLecturerCode(rs.getString("lecturer_code"));
                    course.setLecturerDepartment(rs.getString("lecturer_department"));

                    // Thông tin học kỳ
                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setSemesterName(rs.getString("semester_name"));

                    // Thông tin tiến độ
                    course.setEnrollmentId(rs.getInt("enrollment_id"));
                    course.setCurrentSession(rs.getInt("current_session"));
                    course.setEnrollmentStatus(rs.getString("enrollment_status"));
                    course.setFinalGrade(rs.getObject("final_grade", Double.class));
                    course.setEnrolledStudents(rs.getInt("enrolled_students"));

                    // Tính phần trăm tiến độ
                    int progressPercentage = (int) Math.round(
                            (double) course.getCurrentSession() / course.getTotalSessions() * 100
                    );
                    course.setProgressPercentage(progressPercentage);

                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error in getEnrolledCoursesWithDetails: " + e.getMessage());
            throw e;
        }

        return courses;
    }

// Thêm method để lấy các khóa học có thể đăng ký với thông tin chi tiết
    public List<CourseDisplayModel> getAvailableCoursesWithDetails(int studentId) throws SQLException {
        List<CourseDisplayModel> courses = new ArrayList<>();

        String sql = """
        SELECT 
            c.course_id, c.name, c.code, c.description, c.room, c.schedule,
            c.total_sessions, c.credits, c.max_students, c.status,
            l.lecturer_id, l.full_name as lecturer_name, l.lecturer_code, l.department as lecturer_department,
            s.semester_id, s.name as semester_name,
            COUNT(e.enrollment_id) as enrolled_students
        FROM courses c
        INNER JOIN lecturers l ON c.lecturer_id = l.lecturer_id
        INNER JOIN semesters s ON c.semester_id = s.semester_id
        LEFT JOIN enrollments e ON c.course_id = e.course_id AND e.status = 'active'
        WHERE c.status = 'active' 
        AND c.course_id NOT IN (
            SELECT course_id FROM enrollments 
            WHERE student_id = ? AND status = 'active'
        )
        AND s.is_active = 1
        GROUP BY c.course_id, c.name, c.code, c.description, c.room, c.schedule,
                 c.total_sessions, c.credits, c.max_students, c.status,
                 l.lecturer_id, l.full_name, l.lecturer_code, l.department,
                 s.semester_id, s.name
        HAVING COUNT(e.enrollment_id) < c.max_students
        ORDER BY c.name
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    CourseDisplayModel course = new CourseDisplayModel();

                    // Thông tin khóa học
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setStatus(rs.getString("status"));

                    // Thông tin giảng viên
                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setLecturerName(rs.getString("lecturer_name"));
                    course.setLecturerCode(rs.getString("lecturer_code"));
                    course.setLecturerDepartment(rs.getString("lecturer_department"));

                    // Thông tin học kỳ
                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setSemesterName(rs.getString("semester_name"));

                    // Thông tin đăng ký
                    course.setEnrolledStudents(rs.getInt("enrolled_students"));
                    course.setCurrentSession(0); // Chưa đăng ký nên chưa có tiến độ
                    course.setProgressPercentage(0); // Chưa đăng ký
                    course.setEnrollmentStatus("available"); // Có thể đăng ký

                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error in getAvailableCoursesWithDetails: " + e.getMessage());
            throw e;
        }

        return courses;
    }

// Method tìm kiếm khóa học có thể đăng ký
    public List<CourseDisplayModel> searchAvailableCoursesWithDetails(int studentId, String keyword, Integer semesterId) throws SQLException {
        List<CourseDisplayModel> courses = new ArrayList<>();

        StringBuilder sql = new StringBuilder("""
        SELECT 
            c.course_id, c.name, c.code, c.description, c.room, c.schedule,
            c.total_sessions, c.credits, c.max_students, c.status,
            l.lecturer_id, l.full_name as lecturer_name, l.lecturer_code, l.department as lecturer_department,
            s.semester_id, s.name as semester_name,
            COUNT(e.enrollment_id) as enrolled_students
        FROM courses c
        INNER JOIN lecturers l ON c.lecturer_id = l.lecturer_id
        INNER JOIN semesters s ON c.semester_id = s.semester_id
        LEFT JOIN enrollments e ON c.course_id = e.course_id AND e.status = 'active'
        WHERE c.status = 'active' 
        AND c.course_id NOT IN (
            SELECT course_id FROM enrollments 
            WHERE student_id = ? AND status = 'active'
        )
        AND s.is_active = 1
    """);

        // Thêm điều kiện tìm kiếm
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (c.name LIKE ? OR c.code LIKE ? OR l.full_name LIKE ?)");
        }

        if (semesterId != null) {
            sql.append(" AND c.semester_id = ?");
        }

        sql.append("""
        GROUP BY c.course_id, c.name, c.code, c.description, c.room, c.schedule,
                 c.total_sessions, c.credits, c.max_students, c.status,
                 l.lecturer_id, l.full_name, l.lecturer_code, l.department,
                 s.semester_id, s.name
        HAVING COUNT(e.enrollment_id) < c.max_students
        ORDER BY c.name
    """);

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            pstmt.setInt(paramIndex++, studentId);

            if (keyword != null && !keyword.trim().isEmpty()) {
                String searchPattern = "%" + keyword.trim() + "%";
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
            }

            if (semesterId != null) {
                pstmt.setInt(paramIndex++, semesterId);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    CourseDisplayModel course = new CourseDisplayModel();

                    // Mapping tương tự như method trên
                    course.setCourseId(rs.getInt("course_id"));
                    course.setName(rs.getString("name"));
                    course.setCode(rs.getString("code"));
                    course.setDescription(rs.getString("description"));
                    course.setRoom(rs.getString("room"));
                    course.setSchedule(rs.getString("schedule"));
                    course.setTotalSessions(rs.getInt("total_sessions"));
                    course.setCredits(rs.getInt("credits"));
                    course.setMaxStudents(rs.getInt("max_students"));
                    course.setStatus(rs.getString("status"));

                    course.setLecturerId(rs.getInt("lecturer_id"));
                    course.setLecturerName(rs.getString("lecturer_name"));
                    course.setLecturerCode(rs.getString("lecturer_code"));
                    course.setLecturerDepartment(rs.getString("lecturer_department"));

                    course.setSemesterId(rs.getInt("semester_id"));
                    course.setSemesterName(rs.getString("semester_name"));

                    course.setEnrolledStudents(rs.getInt("enrolled_students"));
                    course.setCurrentSession(0);
                    course.setProgressPercentage(0);
                    course.setEnrollmentStatus("available");

                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error in searchAvailableCoursesWithDetails: " + e.getMessage());
            throw e;
        }

        return courses;
    }

    // Lấy danh sách khóa học đang học của sinh viên
    public List<Course> getEnrolledCoursesByStudent(int studentId) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.course_id, c.name, c.code, c.description, c.room, c.schedule, "
                + "c.total_sessions, c.credits, l.full_name as lecturer_name, "
                + "e.current_session, e.enrollment_date "
                + "FROM courses c "
                + "JOIN enrollments e ON c.course_id = e.course_id "
                + "JOIN lecturers l ON c.lecturer_id = l.lecturer_id "
                + "WHERE e.student_id = ? AND e.status = 'active' "
                + "ORDER BY c.name";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));
                course.setName(rs.getString("name"));
                course.setCode(rs.getString("code"));
                course.setDescription(rs.getString("description"));
                course.setRoom(rs.getString("room"));
                course.setSchedule(rs.getString("schedule"));
                course.setTotalSessions(rs.getInt("total_sessions"));
                course.setCredits(rs.getInt("credits"));
//                course.setLecturerName(rs.getString("lecturer_name"));
//                course.setCurrentSession(rs.getInt("current_session"));
//                course.setEnrollmentDate(rs.getTimestamp("enrollment_date"));

                courses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }
    

}
