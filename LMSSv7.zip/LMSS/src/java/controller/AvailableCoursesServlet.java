package controller;

import dao.CourseDAO;
import dao.StudentDAO;
import dao.SemesterDAO;
import model.CourseDisplayModel;
import model.Student;
import model.User;
import model.Semester;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

@WebServlet("/student/available-courses")
public class AvailableCoursesServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AvailableCoursesServlet.class.getName());
    private CourseDAO courseDAO;
    private StudentDAO studentDAO;
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            studentDAO = new StudentDAO();
            semesterDAO = new SemesterDAO();
            logger.info("AvailableCoursesServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize AvailableCoursesServlet", e);
            throw new ServletException("Failed to initialize AvailableCoursesServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra session và quyền truy cập
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        if (!"student".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ sinh viên mới có quyền truy cập!");
            return;
        }

        try {
            // Lấy thông tin sinh viên
            Student student = studentDAO.getStudentByUserId(currentUser.getUserId());
            if (student == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin sinh viên!");
                return;
            }

            // Lấy tham số tìm kiếm và filter
            String keyword = request.getParameter("keyword");
            String semesterParam = request.getParameter("semester");
            Integer semesterId = null;
            
            if (semesterParam != null && !semesterParam.trim().isEmpty()) {
                try {
                    semesterId = Integer.parseInt(semesterParam);
                } catch (NumberFormatException e) {
                    // Ignore invalid semester ID
                }
            }

            // Lấy danh sách khóa học có thể đăng ký
            List<CourseDisplayModel> availableCourses;
            if (keyword != null && !keyword.trim().isEmpty() || semesterId != null) {
                availableCourses = courseDAO.searchAvailableCoursesWithDetails(student.getStudentId(), keyword, semesterId);
            } else {
                availableCourses = courseDAO.getAvailableCoursesWithDetails(student.getStudentId());
            }
            
            // Lấy danh sách học kỳ để hiển thị filter
            List<Semester> semesters = semesterDAO.getActiveSemesters();
            
            // Đặt attributes cho JSP
            request.setAttribute("availableCourses", availableCourses);
            request.setAttribute("semesters", semesters);
            request.setAttribute("student", student);
            request.setAttribute("currentUser", currentUser);
            request.setAttribute("keyword", keyword);
            request.setAttribute("selectedSemester", semesterId);

            // Log hoạt động
            logger.info("Student " + currentUser.getUsername() + " accessed available courses page with " + 
                       availableCourses.size() + " courses");

            // Forward tới JSP
            request.getRequestDispatcher("/student/available-courses.jsp").forward(request, response);

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AvailableCoursesServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error in AvailableCoursesServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Xử lý form search
        doGet(request, response);
    }
}