package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/exam-result")
public class ExamResultServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(ExamResultServlet.class.getName());
    
    private TestDAO testDAO;
    private TestSubmissionDAO submissionDAO;
    private TestQuestionDAO questionDAO;
    private StudentDAO studentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            testDAO = new TestDAO();
            submissionDAO = new TestSubmissionDAO();
            questionDAO = new TestQuestionDAO();
            studentDAO = new StudentDAO();
            logger.info("ExamResultServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize ExamResultServlet", e);
            throw new ServletException("Failed to initialize ExamResultServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String testIdStr = request.getParameter("testId");
        if (testIdStr == null) {
            session.setAttribute("error", "Không tìm thấy bài kiểm tra");
            response.sendRedirect(request.getContextPath() + "/student/courses");
            return;
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            int testId = Integer.parseInt(testIdStr);
            
            Test test = testDAO.getTestById(testId);
            TestSubmission submission = submissionDAO.getSubmissionByTestAndStudent(testId, student.getStudentId());
            
            if (test == null || submission == null || !submission.isSubmitted()) {
                session.setAttribute("error", "Kết quả bài kiểm tra không tồn tại hoặc bài thi chưa hoàn thành");
                response.sendRedirect(request.getContextPath() + "/student/course-detail?id=" + (test != null ? test.getCourseId() : ""));
                return;
            }
            
            // Lấy câu trả lời với thông tin chi tiết
            List<TestAnswer> answers = submissionDAO.getDetailedAnswersBySubmission(submission.getTestSubmissionId());
            
            request.setAttribute("test", test);
            request.setAttribute("submission", submission);
            request.setAttribute("answers", answers);
            request.setAttribute("student", student);
            
            request.getRequestDispatcher("/student/exam-result.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid test ID: " + testIdStr, e);
            session.setAttribute("error", "ID bài kiểm tra không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/courses");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in ExamResultServlet", e);
            session.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/courses");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in ExamResultServlet", e);
            session.setAttribute("error", "Đã xảy ra lỗi: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/courses");
        }
    }
} 