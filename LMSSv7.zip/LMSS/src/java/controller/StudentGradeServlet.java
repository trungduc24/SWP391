package controller;

import dao.GradeDAO;
import dao.StudentDAO;
import dao.SemesterDAO;
import model.User;
import model.Student;
import model.Grade;
import model.Semester;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Logger;

@WebServlet("/student/grades")
public class StudentGradeServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(StudentGradeServlet.class.getName());
    
    private GradeDAO gradeDAO;
    private StudentDAO studentDAO;
    private SemesterDAO semesterDAO;
    
    @Override
    public void init() throws ServletException {
        super.init();
        gradeDAO = new GradeDAO();
        studentDAO = new StudentDAO();
        semesterDAO = new SemesterDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            if (student == null) {
                response.sendRedirect("../error.jsp");
                return;
            }
            
            showGradeStatistics(request, response, student);
            
        } catch (SQLException e) {
            logger.severe("Error loading grade statistics: " + e.getMessage());
            response.sendRedirect("../error.jsp");
        }
    }
    
    private void showGradeStatistics(HttpServletRequest request, HttpServletResponse response, Student student)
            throws ServletException, IOException, SQLException {
        
        int studentId = student.getStudentId();
        
        // Lấy tất cả điểm số của sinh viên
        List<Map<String, Object>> studentGrades = gradeDAO.getDetailedGradesByStudentId(studentId);
        
        // Tính GPA
        double gpa = gradeDAO.calculateGPA(studentId);
        
        // Thống kê môn học
        Map<String, Integer> courseStats = gradeDAO.getCourseStatistics(studentId);
        
        // Lấy danh sách semester
        List<Semester> semesters = semesterDAO.getAllSemesters();
        
        // Thống kê theo semester
        Map<String, Double> semesterGPAs = gradeDAO.getGPABySemester(studentId);
        
        // Xu hướng điểm số (6 tháng gần nhất)
        List<Map<String, Object>> gradesTrend = gradeDAO.getGradesTrend(studentId, 6);
        
        // Thống kê theo loại điểm
        Map<String, Double> gradeTypeStats = gradeDAO.getGradeTypeStatistics(studentId);
        
        // Set attributes
        request.setAttribute("studentGrades", studentGrades);
        request.setAttribute("gpa", gpa);
        request.setAttribute("courseStats", courseStats);
        request.setAttribute("semesters", semesters);
        request.setAttribute("semesterGPAs", semesterGPAs);
        request.setAttribute("gradesTrend", gradesTrend);
        request.setAttribute("gradeTypeStats", gradeTypeStats);
        
        // Forward đến JSP
        request.getRequestDispatcher("/student/grades.jsp").forward(request, response);
    }
}