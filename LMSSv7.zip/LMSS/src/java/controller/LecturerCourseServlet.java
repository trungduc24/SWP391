package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;

/**
 * LecturerCourseServlet handles all course-related operations for lecturers.
 * This includes creating, viewing, editing, and deleting courses.
 */

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1 MB
    maxFileSize = 1024 * 1024 * 10,       // 10 MB
    maxRequestSize = 1024 * 1024 * 50     // 50 MB
)
public class LecturerCourseServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerCourseServlet.class.getName());
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private SemesterDAO semesterDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            semesterDAO = new SemesterDAO();
            studentDAO = new StudentDAO();
            logger.info("LecturerCourseServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerCourseServlet", e);
            throw new ServletException("Failed to initialize LecturerCourseServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Handle different URL patterns
            if (servletPath.equals("/lecturer/courses/create")) {
                showCreateCourseForm(request, response);
            } else if (servletPath.equals("/lecturer/courses/search")) {
                searchCourses(request, response);
            } else if (servletPath.equals("/lecturer/courses") && pathInfo == null) {
                showMyCourses(request, response);
            } else if (servletPath.equals("/lecturer/courses") && pathInfo != null) {
                if (pathInfo.startsWith("/view/")) {
                    int courseId = Integer.parseInt(pathInfo.substring(6));
                    viewCourse(request, response, courseId);
                } else if (pathInfo.startsWith("/edit/")) {
                    int courseId = Integer.parseInt(pathInfo.substring(6));
                    showEditCourseForm(request, response, courseId);
                } else if (pathInfo.startsWith("/delete/")) {
                    int courseId = Integer.parseInt(pathInfo.substring(8));
                    deleteCourse(request, response, courseId);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid course ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerCourseServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        String action = request.getParameter("action");
        
        try {
            if ("create-course".equals(action)) {
                createCourse(request, response);
            } else if ("update-course".equals(action)) {
                updateCourse(request, response);
            } else if ("delete-course".equals(action)) {
                int courseId = Integer.parseInt(request.getParameter("courseId"));
                deleteCourse(request, response, courseId);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid course ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerCourseServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showMyCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Load courses of the lecturer
        List<Course> myCourses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        List<Semester> semesters = semesterDAO.getAllSemesters();
        
        request.setAttribute("myCourses", myCourses);
        request.setAttribute("semesters", semesters);
        request.setAttribute("activeSection", "courses");
        
        request.getRequestDispatcher("/lecturer/courses.jsp").forward(request, response);
    }

    private void showCreateCourseForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        List<Semester> semesters = semesterDAO.getAllSemesters();
        request.setAttribute("semesters", semesters);
        request.setAttribute("activeSection", "courses");
        
        request.getRequestDispatcher("/lecturer/create-course.jsp").forward(request, response);
    }

    private void showEditCourseForm(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        Course course = courseDAO.getCourseById(courseId);
        
        if (course == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Check if lecturer owns this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to edit this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        List<Semester> semesters = semesterDAO.getAllSemesters();
        
        request.setAttribute("course", course);
        request.setAttribute("semesters", semesters);
        request.setAttribute("activeSection", "courses");
        
        request.getRequestDispatcher("/lecturer/edit-course.jsp").forward(request, response);
    }

    private void viewCourse(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        Course course = courseDAO.getCourseByIdFull(courseId);
        
        if (course == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Check if lecturer owns this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Get semester information
        Semester semester = semesterDAO.getSemesterById(course.getSemesterId());
        
        // Get enrolled students
        List<Student> enrolledStudents = studentDAO.getStudentsByCourseId(courseId);
        
        request.setAttribute("course", course);
        request.setAttribute("semester", semester);
        request.setAttribute("enrolledStudents", enrolledStudents);
        request.setAttribute("activeSection", "courses");
        
        request.getRequestDispatcher("/lecturer/view-course.jsp").forward(request, response);
    }

    private void createCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get form data
        String courseCode = request.getParameter("courseCode");
        String courseName = request.getParameter("courseName");
        String description = request.getParameter("description");
        int semesterId = Integer.parseInt(request.getParameter("semesterId"));
        int credits = Integer.parseInt(request.getParameter("credits"));
        boolean isActive = "on".equals(request.getParameter("isActive"));
        
        // Create course object
        Course course = new Course();
        course.setCode(courseCode);
        course.setName(courseName);
        course.setDescription(description);
        course.setSemesterId(semesterId);
        course.setLecturerId(lecturer.getLecturerId());
        course.setCredits(credits);
        course.setActive(isActive);
        
        // Save course to database
        boolean addCourse  = courseDAO.addCourse(course);
        
        if (addCourse) {
            request.getSession().setAttribute("success", "Course created successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to create course.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/courses");
    }

    private void updateCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get form data
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String courseCode = request.getParameter("courseCode");
        String courseName = request.getParameter("courseName");
        String description = request.getParameter("description");
        int semesterId = Integer.parseInt(request.getParameter("semesterId"));
        int credits = Integer.parseInt(request.getParameter("credits"));
        boolean isActive = "on".equals(request.getParameter("isActive"));
        
        // Get existing course
        Course existingCourse = courseDAO.getCourseById(courseId);
        
        if (existingCourse == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Check if lecturer owns this course
        if (existingCourse.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to update this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Update course object
        existingCourse.setCode(courseCode);
        existingCourse.setName(courseName);
        existingCourse.setDescription(description);
        existingCourse.setSemesterId(semesterId);
        existingCourse.setCredits(credits);
        existingCourse.setActive(isActive);
        
        // Save course to database
        boolean success = courseDAO.updateCourse(existingCourse);
        
        if (success) {
            request.getSession().setAttribute("success", "Course updated successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to update course.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/courses");
    }

    private void deleteCourse(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get existing course
        Course existingCourse = courseDAO.getCourseById(courseId);
        
        if (existingCourse == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Check if lecturer owns this course
        if (existingCourse.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to delete this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/courses");
            return;
        }
        
        // Delete course from database
        boolean success = courseDAO.deleteCourse(courseId);
        
        if (success) {
            request.getSession().setAttribute("success", "Course deleted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to delete course.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/courses");
    }

    private void searchCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        String keyword = request.getParameter("keyword");
        int semesterId = 0;
        String semesterIdParam = request.getParameter("semesterId");
        if (semesterIdParam != null && !semesterIdParam.isEmpty()) {
            semesterId = Integer.parseInt(semesterIdParam);
        }
        
        List<Course> searchResults;
        if (semesterId > 0) {
            searchResults = courseDAO.searchCoursesByLecturerAndSemester(lecturer.getLecturerId(), semesterId, keyword);
        } else {
            searchResults = courseDAO.searchCoursesByLecturer(lecturer.getLecturerId(), keyword);
        }
        
        List<Semester> semesters = semesterDAO.getAllSemesters();
        
        request.setAttribute("myCourses", searchResults);
        request.setAttribute("semesters", semesters);
        request.setAttribute("keyword", keyword);
        request.setAttribute("selectedSemesterId", semesterId);
        request.setAttribute("activeSection", "courses");
        
        request.getRequestDispatcher("/lecturer/courses.jsp").forward(request, response);
    }
} 