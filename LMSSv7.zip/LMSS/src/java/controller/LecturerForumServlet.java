package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LecturerForumServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(LecturerForumServlet.class.getName());
    private ForumDAO forumDAO;
    private ForumPostDAO forumPostDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;

    @Override
    public void init() throws ServletException {
        try {
            forumDAO = new ForumDAO();
            forumPostDAO = new ForumPostDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            logger.info("LecturerForumServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerForumServlet", e);
            throw new ServletException("Failed to initialize LecturerForumServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            String pathInfo = request.getPathInfo();
            String action = request.getParameter("action");
            
            if (pathInfo == null || pathInfo.equals("/")) {
                // List all forums for the lecturer
                listLecturerForums(request, response, lecturer.getLecturerId());
            } else if (pathInfo.matches("/\\d+")) {
                // View a specific forum
                int forumId = Integer.parseInt(pathInfo.substring(1));
                viewForum(request, response, forumId, lecturer.getLecturerId());
            } else if (pathInfo.equals("/create")) {
                // Show form to create a new forum
                showCreateForm(request, response, lecturer.getLecturerId());
            } else if (pathInfo.equals("/edit") && action != null && action.equals("forum")) {
                // Show form to edit an existing forum
                int forumId = Integer.parseInt(request.getParameter("id"));
                showEditForm(request, response, forumId, lecturer.getLecturerId());
            } else if (pathInfo.equals("/delete") && action != null && action.equals("forum")) {
                // Delete a forum
                int forumId = Integer.parseInt(request.getParameter("id"));
                deleteForum(request, response, forumId, lecturer.getLecturerId());
            } else if (pathInfo.matches("/\\d+/posts") && action != null && action.equals("create")) {
                // Show form to create a new post in a forum
                int forumId = Integer.parseInt(pathInfo.substring(1, pathInfo.indexOf("/posts")));
                viewForum(request, response, forumId, lecturer.getLecturerId());
            } else if (pathInfo.matches("/posts/\\d+") && action != null && action.equals("edit")) {
                // Show form to edit an existing post
                int postId = Integer.parseInt(pathInfo.substring(7));
                showEditPostForm(request, response, postId, currentUser.getUserId());
            } else if (pathInfo.matches("/posts/\\d+") && action != null && action.equals("delete")) {
                // Delete a post
                int postId = Integer.parseInt(pathInfo.substring(7));
                deletePost(request, response, postId, lecturer.getLecturerId());
            } else {
                // Invalid URL pattern
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in LecturerForumServlet", e);
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            String pathInfo = request.getPathInfo();
            String action = request.getParameter("action");
            
            if (pathInfo != null && pathInfo.equals("/create") && action != null && action.equals("forum")) {
                // Create a new forum
                createForum(request, response, lecturer.getLecturerId());
            } else if (pathInfo != null && pathInfo.equals("/update") && action != null && action.equals("forum")) {
                // Update an existing forum
                updateForum(request, response);
            } else if (pathInfo != null && pathInfo.matches("/\\d+/posts") && action != null && action.equals("create")) {
                // Create a new post in a forum
                int forumId = Integer.parseInt(pathInfo.substring(1, pathInfo.indexOf("/posts")));
                createPost(request, response, forumId, currentUser.getUserId());
            } else if (pathInfo != null && pathInfo.equals("/posts/update") && action != null && action.equals("post")) {
                // Update an existing post
                updatePost(request, response, currentUser.getUserId());
            } else {
                // Invalid URL pattern
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in LecturerForumServlet doPost", e);
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    private void listLecturerForums(HttpServletRequest request, HttpServletResponse response, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            List<Forum> forums = forumDAO.getForumsByLecturerId(lecturerId);
            request.setAttribute("forums", forums);
            request.getRequestDispatcher("/lecturer/forums.jsp").forward(request, response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error listing forums", e);
            throw new ServletException("Error listing forums", e);
        }
    }

    private void viewForum(HttpServletRequest request, HttpServletResponse response, int forumId, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            Forum forum = forumDAO.getForumById(forumId);
            if (forum == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Forum not found");
                return;
            }

            // Check if the lecturer has access to this forum
            Course course = courseDAO.getCourseById(forum.getCourseId());
            if (course == null || course.getLecturerId() != lecturerId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to view this forum");
                return;
            }

            List<ForumPost> posts = forumPostDAO.getPostsByForumId(forumId);
            request.setAttribute("forum", forum);
            request.setAttribute("posts", posts);
            request.setAttribute("course", course);
            request.getRequestDispatcher("/lecturer/forum-view.jsp").forward(request, response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error viewing forum", e);
            throw new ServletException("Error viewing forum", e);
        }
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            List<Course> courses = courseDAO.getCoursesByLecturerId(lecturerId);
            request.setAttribute("courses", courses);
            request.getRequestDispatcher("/lecturer/forum-form.jsp").forward(request, response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error showing create form", e);
            throw new ServletException("Error showing create form", e);
        }
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response, int forumId, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            Forum forum = forumDAO.getForumById(forumId);
            if (forum == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Forum not found");
                return;
            }

            // Check if the lecturer has access to this forum
            Course course = courseDAO.getCourseById(forum.getCourseId());
            if (course == null || course.getLecturerId() != lecturerId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to edit this forum");
                return;
            }

            request.setAttribute("forum", forum);
            request.setAttribute("course", course);
            request.getRequestDispatcher("/lecturer/forum-form.jsp").forward(request, response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error showing edit form", e);
            throw new ServletException("Error showing edit form", e);
        }
    }

    private void createForum(HttpServletRequest request, HttpServletResponse response, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            String title = request.getParameter("title");

            // Check if the lecturer has access to this course
            Course course = courseDAO.getCourseById(courseId);
            if (course == null || course.getLecturerId() != lecturerId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to create a forum for this course");
                return;
            }

            Forum forum = new Forum();
            forum.setCourseId(courseId);
            forum.setTitle(title);
            forum.setCreatedBy(lecturerId);
            forum.setCreatedAt(new Timestamp(System.currentTimeMillis()));

            int forumId = forumDAO.createForum(forum);
            response.sendRedirect(request.getContextPath() + "/lecturer/forums/" + forumId);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating forum", e);
            throw new ServletException("Error creating forum", e);
        }
    }

    private void updateForum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        try {
            int forumId = Integer.parseInt(request.getParameter("forumId"));
            String title = request.getParameter("title");

            Forum forum = forumDAO.getForumById(forumId);
            if (forum == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Forum not found");
                return;
            }

            forum.setTitle(title);
            forumDAO.updateForum(forum);
            response.sendRedirect(request.getContextPath() + "/lecturer/forums/" + forumId);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error updating forum", e);
            throw new ServletException("Error updating forum", e);
        }
    }

    private void deleteForum(HttpServletRequest request, HttpServletResponse response, int forumId, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            Forum forum = forumDAO.getForumById(forumId);
            if (forum == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Forum not found");
                return;
            }

            // Check if the lecturer has access to this forum
            Course course = courseDAO.getCourseById(forum.getCourseId());
            if (course == null || course.getLecturerId() != lecturerId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to delete this forum");
                return;
            }

            forumDAO.deleteForum(forumId);
            response.sendRedirect(request.getContextPath() + "/lecturer/forums");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting forum", e);
            throw new ServletException("Error deleting forum", e);
        }
    }

    private void createPost(HttpServletRequest request, HttpServletResponse response, int forumId, int userId)
            throws SQLException, ServletException, IOException {
        try {
            String content = request.getParameter("content");

            ForumPost post = new ForumPost();
            post.setForumId(forumId);
            post.setUserId(userId);
            post.setContent(content);
            post.setCreatedAt(new Timestamp(System.currentTimeMillis()));

            forumPostDAO.createPost(post);
            response.sendRedirect(request.getContextPath() + "/lecturer/forums/" + forumId);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating post", e);
            throw new ServletException("Error creating post", e);
        }
    }

    private void showEditPostForm(HttpServletRequest request, HttpServletResponse response, int postId, int userId)
            throws SQLException, ServletException, IOException {
        try {
            ForumPost post = forumPostDAO.getPostById(postId);
            if (post == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Post not found");
                return;
            }

            // Check if the user is the owner of the post
            if (post.getUserId() != userId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to edit this post");
                return;
            }

            request.setAttribute("post", post);
            request.getRequestDispatcher("/lecturer/post-form.jsp").forward(request, response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error showing edit post form", e);
            throw new ServletException("Error showing edit post form", e);
        }
    }

    private void updatePost(HttpServletRequest request, HttpServletResponse response, int userId)
            throws SQLException, ServletException, IOException {
        try {
            int postId = Integer.parseInt(request.getParameter("postId"));
            String content = request.getParameter("content");

            ForumPost post = forumPostDAO.getPostById(postId);
            if (post == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Post not found");
                return;
            }

            // Check if the user is the owner of the post
            if (post.getUserId() != userId) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You don't have permission to edit this post");
                return;
            }

            post.setContent(content);
            forumPostDAO.updatePost(post);
            response.sendRedirect(request.getContextPath() + "/lecturer/forums/" + post.getForumId());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error updating post", e);
            throw new ServletException("Error updating post", e);
        }
    }

    private void deletePost(HttpServletRequest request, HttpServletResponse response, int postId, int lecturerId)
            throws SQLException, ServletException, IOException {
        try {
            ForumPost post = forumPostDAO.getPostById(postId);
            if (post == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Post not found");
                return;
            }

            // Lecturer can delete any post in their forums
            forumPostDAO.adminDeletePost(postId);

            // Redirect back to the forum page
            response.sendRedirect(request.getContextPath() + "/lecturer/forums/" + post.getForumId());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting post", e);
            throw new ServletException("Error deleting post", e);
        }
    }
} 