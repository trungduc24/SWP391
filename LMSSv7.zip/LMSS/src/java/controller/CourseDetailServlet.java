package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;

@WebServlet("/student/course-detail")
public class CourseDetailServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(CourseDetailServlet.class.getName());
    
    private CourseDAO courseDAO;
    private StudentDAO studentDAO;
    private MaterialDAO materialDAO;
    private EnrollmentDAO enrollmentDAO;
    private AssignmentDAO assignmentDAO;
    private SubmissionDAO submissionDAO;
    private TestDAO testDAO;
    private TestSubmissionDAO testSubmissionDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            courseDAO = new CourseDAO();
            studentDAO = new StudentDAO();
            materialDAO = new MaterialDAO();
            enrollmentDAO = new EnrollmentDAO();
            assignmentDAO = new AssignmentDAO();
            submissionDAO = new SubmissionDAO();
            testDAO = new TestDAO();
            testSubmissionDAO = new TestSubmissionDAO();
            logger.info("CourseDetailServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize CourseDetailServlet", e);
            throw new ServletException("Failed to initialize CourseDetailServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Kiểm tra authentication và authorization
            User currentUser = validateUserAccess(request, response);
            if (currentUser == null) return;
            
            // Validate và lấy course ID
            int courseId = validateAndGetCourseId(request, response);
            if (courseId == -1) return;
            
            // Lấy thông tin sinh viên
            Student student = getStudentInfo(currentUser, response);
            if (student == null) return;
            
            // Kiểm tra quyền truy cập khóa học
            if (!checkCourseAccess(student.getStudentId(), courseId, response)) return;
            
            // Load dữ liệu khóa học
            CourseData courseData = loadCourseData(courseId, student.getStudentId());
            if (courseData == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy khóa học!");
                return;
            }
            
            // Set attributes cho JSP
            setCourseAttributes(request, courseData, student, currentUser);
            
            // Log activity
            logCourseAccess(currentUser, courseId, courseData);
            
            // Forward to JSP
            request.getRequestDispatcher("/student/course-detail.jsp").forward(request, response);
            
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in CourseDetailServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Đã xảy ra lỗi hệ thống!");
        }
    }
    
    private User validateUserAccess(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        if (!"student".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ sinh viên mới có quyền truy cập!");
            return null;
        }
        
        return currentUser;
    }
    
    private int validateAndGetCourseId(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String courseIdParam = request.getParameter("id");
        if (courseIdParam == null || courseIdParam.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID khóa học không hợp lệ!");
            return -1;
        }
        
        try {
            return Integer.parseInt(courseIdParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID khóa học không hợp lệ!");
            return -1;
        }
    }
    
    private Student getStudentInfo(User currentUser, HttpServletResponse response) 
            throws IOException, SQLException {
        Student student = studentDAO.getStudentByUserId(currentUser.getUserId());
        if (student == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin sinh viên!");
            return null;
        }
        return student;
    }
    
    private boolean checkCourseAccess(int studentId, int courseId, HttpServletResponse response) 
            throws IOException, SQLException {
        if (!enrollmentDAO.isStudentEnrolledInCourse(studentId, courseId)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn chưa đăng ký khóa học này!");
            return false;
        }
        return true;
    }
    
    private CourseData loadCourseData(int courseId, int studentId) throws Exception {
        // Lấy thông tin khóa học
        CourseDisplayModel course = getCourseDetail(courseId, studentId);
        if (course == null) return null;
        
        // Lấy materials
        List<Material> materials = materialDAO.getMaterialsByCourseId(courseId);
        
        // Lấy assignments
        List<Assignment> assignments = assignmentDAO.getAssignmentsByCourse(courseId);
        
        // Lấy submissions
        Map<Integer, Submission> submissions = getStudentSubmissions(studentId, assignments);
        
        // Lấy và phân loại tests
        TestData testData = loadAndClassifyTests(courseId, studentId);
        
        return new CourseData(course, materials, assignments, submissions, testData);
    }
    
    private CourseDisplayModel getCourseDetail(int courseId, int studentId) throws SQLException {
        List<CourseDisplayModel> courses = courseDAO.getEnrolledCoursesWithDetails(studentId);
        return courses.stream()
                .filter(course -> course.getCourseId() == courseId)
                .findFirst()
                .orElse(null);
    }
    
    private Map<Integer, Submission> getStudentSubmissions(int studentId, List<Assignment> assignments) 
            throws SQLException {
        Map<Integer, Submission> submissions = new HashMap<>();
        List<Submission> studentSubmissions = submissionDAO.getSubmissionsByStudent(studentId);
        
        for (Submission submission : studentSubmissions) {
            // Chỉ lấy submissions cho assignments trong khóa học này
            boolean isAssignmentInCourse = assignments.stream()
                .anyMatch(a -> a.getAssignmentId() == submission.getAssignmentId());
            if (isAssignmentInCourse) {
                submissions.put(submission.getAssignmentId(), submission);
            }
        }
        
        return submissions;
    }
    
    private TestData loadAndClassifyTests(int courseId, int studentId) throws SQLException {
        // Lấy tất cả tests của khóa học
        List<Test> allTests = testDAO.getTestsByCourseId(courseId);
        
        // Phân loại tests theo thời gian
        Timestamp now = new Timestamp(System.currentTimeMillis());
        List<Test> upcomingTests = new ArrayList<>();
        List<Test> currentTests = new ArrayList<>();
        List<Test> pastTests = new ArrayList<>();
        
        for (Test test : allTests) {
            if (test.getStartTime() != null && test.getEndTime() != null) {
                if (test.getStartTime().after(now)) {
                    // Test chưa bắt đầu
                    upcomingTests.add(test);
                } else if (test.getEndTime().before(now)) {
                    // Test đã kết thúc
                    pastTests.add(test);
                } else {
                    // Test đang diễn ra
                    currentTests.add(test);
                }
            } else {
                // Nếu không có thời gian, coi như upcoming
                upcomingTests.add(test);
            }
        }
        
        // Sắp xếp tests
        upcomingTests.sort(Comparator.comparing(Test::getStartTime, Comparator.nullsLast(Comparator.naturalOrder())));
        currentTests.sort(Comparator.comparing(Test::getEndTime, Comparator.nullsLast(Comparator.naturalOrder())));
        pastTests.sort(Comparator.comparing(Test::getEndTime, Comparator.nullsLast(Comparator.reverseOrder())));
        
        // Lấy test submissions
        Map<Integer, TestSubmission> testSubmissions = loadTestSubmissions(allTests, studentId);
        
        return new TestData(upcomingTests, currentTests, pastTests, testSubmissions);
    }
    
    private Map<Integer, TestSubmission> loadTestSubmissions(List<Test> allTests, int studentId) {
        Map<Integer, TestSubmission> testSubmissions = new HashMap<>();
        
        try {
            for (Test test : allTests) {
                TestSubmission testSubmission = testSubmissionDAO.getSubmissionByTestAndStudent(test.getTestId(), studentId);
                if (testSubmission != null) {
                    testSubmissions.put(test.getTestId(), testSubmission);
                }
            }
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error loading test submissions", e);
        }
        
        return testSubmissions;
    }
    
    private void setCourseAttributes(HttpServletRequest request, CourseData courseData, 
                                    Student student, User currentUser) {
        request.setAttribute("course", courseData.getCourse());
        request.setAttribute("materials", courseData.getMaterials());
        request.setAttribute("assignments", courseData.getAssignments());
        request.setAttribute("submissions", courseData.getSubmissions());
        request.setAttribute("upcomingTests", courseData.getTestData().getUpcomingTests());
        request.setAttribute("currentTests", courseData.getTestData().getCurrentTests());
        request.setAttribute("pastTests", courseData.getTestData().getPastTests());
        request.setAttribute("testSubmissions", courseData.getTestData().getTestSubmissions());
        request.setAttribute("student", student);
        request.setAttribute("currentUser", currentUser);
    }
    
    private void logCourseAccess(User currentUser, int courseId, CourseData courseData) {
        TestData testData = courseData.getTestData();
        logger.info(String.format("Student %s accessed course detail: %d with %d assignments and %d tests " +
                   "(upcoming: %d, current: %d, past: %d)",
                   currentUser.getUsername(), courseId, 
                   courseData.getAssignments().size(), 
                   testData.getTotalTests(),
                   testData.getUpcomingTests().size(),
                   testData.getCurrentTests().size(),
                   testData.getPastTests().size()));
    }
    
    // Inner classes for data organization
    private static class CourseData {
        private final CourseDisplayModel course;
        private final List<Material> materials;
        private final List<Assignment> assignments;
        private final Map<Integer, Submission> submissions;
        private final TestData testData;
        
        public CourseData(CourseDisplayModel course, List<Material> materials, 
                         List<Assignment> assignments, Map<Integer, Submission> submissions,
                         TestData testData) {
            this.course = course;
            this.materials = materials;
            this.assignments = assignments;
            this.submissions = submissions;
            this.testData = testData;
        }
        
        public CourseDisplayModel getCourse() { return course; }
        public List<Material> getMaterials() { return materials; }
        public List<Assignment> getAssignments() { return assignments; }
        public Map<Integer, Submission> getSubmissions() { return submissions; }
        public TestData getTestData() { return testData; }
    }
    
    private static class TestData {
        private final List<Test> upcomingTests;
        private final List<Test> currentTests;
        private final List<Test> pastTests;
        private final Map<Integer, TestSubmission> testSubmissions;
        
        public TestData(List<Test> upcomingTests, List<Test> currentTests, 
                       List<Test> pastTests, Map<Integer, TestSubmission> testSubmissions) {
            this.upcomingTests = upcomingTests;
            this.currentTests = currentTests;
            this.pastTests = pastTests;
            this.testSubmissions = testSubmissions;
        }
        
        public List<Test> getUpcomingTests() { return upcomingTests; }
        public List<Test> getCurrentTests() { return currentTests; }
        public List<Test> getPastTests() { return pastTests; }
        public Map<Integer, TestSubmission> getTestSubmissions() { return testSubmissions; }
        
        public int getTotalTests() {
            return upcomingTests.size() + currentTests.size() + pastTests.size();
        }
    }
}