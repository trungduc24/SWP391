package controller;

import dao.MaterialDAO;
import dao.StudentDAO;
import dao.EnrollmentDAO;
import model.Material;
import model.Student;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.*;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.logging.Logger;
import java.util.logging.Level;

@WebServlet("/student/download-material")
public class DownloadMaterialServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(DownloadMaterialServlet.class.getName());
    
    private MaterialDAO materialDAO;
    private StudentDAO studentDAO;
    private EnrollmentDAO enrollmentDAO;

    @Override
    public void init() throws ServletException {
        try {
            materialDAO = new MaterialDAO();
            studentDAO = new StudentDAO();
            enrollmentDAO = new EnrollmentDAO();
            logger.info("DownloadMaterialServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize DownloadMaterialServlet", e);
            throw new ServletException("Failed to initialize DownloadMaterialServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra session và quyền truy cập
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Vui lòng đăng nhập!");
            return;
        }
        
        if (!"student".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ sinh viên mới có quyền tải tài liệu!");
            return;
        }

        // Lấy ID tài liệu từ parameter
        String materialIdParam = request.getParameter("id");
        if (materialIdParam == null || materialIdParam.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID tài liệu không hợp lệ!");
            return;
        }

        try {
            int materialId = Integer.parseInt(materialIdParam);
            
            // Lấy thông tin sinh viên
            Student student = studentDAO.getStudentByUserId(currentUser.getUserId());
            if (student == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin sinh viên!");
                return;
            }

            // Kiểm tra quyền truy cập tài liệu
            if (!materialDAO.canAccessMaterial(materialId, student.getStudentId())) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền tải tài liệu này!");
                return;
            }

            // Lấy thông tin tài liệu
            Material material = materialDAO.getMaterialById(materialId);
            if (material == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy tài liệu!");
                return;
            }

            // Tạo URL tải trực tiếp
            String downloadUrl = createDownloadUrl(request, material);
            
            // Cập nhật số lần download
            materialDAO.incrementDownloadCount(materialId);

            // Log hoạt động
            logger.info("Student " + currentUser.getUsername() + " requested download for material: " + materialId);

            // Redirect tới link tải
            response.sendRedirect(downloadUrl);

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID tài liệu không hợp lệ!");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in DownloadMaterialServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error in DownloadMaterialServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi hệ thống: " + e.getMessage());
        }
    }

    private String createDownloadUrl(HttpServletRequest request, Material material) throws IOException {
        // Tạo URL tải trực tiếp từ đường dẫn file
        String contextPath = request.getContextPath();
        String filePath = material.getFilePath();
        
        // Kiểm tra xem file có tồn tại không
        String realPath = getServletContext().getRealPath("/") + filePath;
        Path path = Paths.get(realPath);
        
        if (!Files.exists(path)) {
            throw new IOException("File không tồn tại trên server!");
        }
        
        // Tạo URL tải trực tiếp
        String downloadUrl = contextPath + "/" + filePath;
        
        // Nếu có title, có thể thêm vào URL params để hiển thị tên file đẹp hơn
        if (material.getTitle() != null && !material.getTitle().trim().isEmpty()) {
            downloadUrl += "?title=" + URLEncoder.encode(material.getTitle(), "UTF-8");
        }
        
        return downloadUrl;
    }
}