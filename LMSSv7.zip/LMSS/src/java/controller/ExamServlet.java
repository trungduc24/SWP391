package controller;

import dao.*;
import model.*;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/exam/*")
public class ExamServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(ExamServlet.class.getName());
    
    private TestDAO testDAO;
    private TestQuestionDAO questionDAO;
    private TestSubmissionDAO submissionDAO;
    private StudentDAO studentDAO;
    private EnrollmentDAO enrollmentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            testDAO = new TestDAO();
            questionDAO = new TestQuestionDAO();
            submissionDAO = new TestSubmissionDAO();
            studentDAO = new StudentDAO();
            enrollmentDAO = new EnrollmentDAO();
            logger.info("ExamServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize ExamServlet", e);
            throw new ServletException("Failed to initialize ExamServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/list";
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            request.setAttribute("student", student);
            
            switch (pathInfo) {
                case "/list":
                    showExamList(request, response, student);
                    break;
                case "/start":
                    startExam(request, response, student);
                    break;
                case "/take":
                    takeExam(request, response, student);
                    break;
                case "/result":
                    showResult(request, response, student);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/student/exam/list");
                    break;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in ExamServlet", e);
            session.setAttribute("error", "Đã xảy ra lỗi: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/dashboard");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
            return;
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            
            switch (pathInfo) {
                case "/save-answer":
                    saveAnswer(request, response, student);
                    break;
                case "/submit":
                    submitExam(request, response, student);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/student/exam/list");
                    break;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in ExamServlet POST", e);
            session.setAttribute("error", "Đã xảy ra lỗi: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
        }
    }
    
    private void showExamList(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        // Lấy danh sách tests từ các khóa học đã đăng ký
        List<Test> availableTests = testDAO.getAvailableTestsByStudentId(student.getStudentId());
        
        request.setAttribute("tests", availableTests);
        request.getRequestDispatcher("/student/exam-list.jsp").forward(request, response);
    }
    
    private void startExam(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String testIdStr = request.getParameter("testId");
        
        if (testIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
            return;
        }
        
        try {
            int testId = Integer.parseInt(testIdStr);
            Test test = testDAO.getTestById(testId);
            
            if (test == null) {
                request.getSession().setAttribute("error", "Bài kiểm tra không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), test.getCourseId())) {
                request.getSession().setAttribute("error", "Bạn không có quyền truy cập bài kiểm tra này");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            // Kiểm tra thời gian làm bài
            Date now = new Date();
            if (test.getStart_time() != null && now.before(test.getStart_time())) {
                request.getSession().setAttribute("error", "Bài kiểm tra chưa bắt đầu");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            if (test.getEnd_time() != null && now.after(test.getEnd_time())) {
                request.getSession().setAttribute("error", "Bài kiểm tra đã kết thúc");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            // Kiểm tra đã làm bài chưa
            TestSubmission existingSubmission = submissionDAO.getSubmissionByTestAndStudent(testId, student.getStudentId());
            if (existingSubmission != null) {
                if (existingSubmission.isSubmitted()) {
                    response.sendRedirect(request.getContextPath() + "/student/exam/result?testId=" + testId);
                    return;
                } else {
                    // Tiếp tục làm bài
                    response.sendRedirect(request.getContextPath() + "/student/exam/take?testId=" + testId);
                    return;
                }
            }
            
            // Bắt đầu làm bài mới
            int submissionId = submissionDAO.startTestSubmission(testId, student.getStudentId());
            
            response.sendRedirect(request.getContextPath() + "/student/exam/take?testId=" + testId);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
        }
    }
    
    private void takeExam(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String testIdStr = request.getParameter("testId");
        
        if (testIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
            return;
        }
        
        try {
            int testId = Integer.parseInt(testIdStr);
            Test test = testDAO.getTestById(testId);
            TestSubmission submission = submissionDAO.getSubmissionByTestAndStudent(testId, student.getStudentId());
            
            if (test == null || submission == null) {
                request.getSession().setAttribute("error", "Bài kiểm tra không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            if (submission.isSubmitted()) {
                response.sendRedirect(request.getContextPath() + "/student/exam/result?testId=" + testId);
                return;
            }
            
            // Lấy câu hỏi và các câu trả lời đã có
            List<TestQuestion> questions = questionDAO.getQuestionsByTestId(testId);
            List<TestAnswer> answers = submissionDAO.getAnswersBySubmission(submission.getTestSubmissionId());
            
            request.setAttribute("test", test);
            request.setAttribute("submission", submission);
            request.setAttribute("questions", questions);
            request.setAttribute("answers", answers);
            
            request.getRequestDispatcher("/student/exam-take.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
        }
    }
    
    private void saveAnswer(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String submissionIdStr = request.getParameter("submissionId");
        String questionIdStr = request.getParameter("questionId");
        String selectedOptionIdStr = request.getParameter("selectedOptionId");
        
        if (submissionIdStr == null || questionIdStr == null) {
            response.getWriter().write("{\"success\": false, \"message\": \"Tham số không hợp lệ\"}");
            return;
        }
        
        try {
            int submissionId = Integer.parseInt(submissionIdStr);
            int questionId = Integer.parseInt(questionIdStr);
            Integer selectedOptionId = selectedOptionIdStr != null ? Integer.parseInt(selectedOptionIdStr) : null;
            
            // Lấy thông tin câu hỏi và option
            TestQuestion question = questionDAO.getQuestionById(questionId);
            TestQuestionOption selectedOption = null;
            
            if (selectedOptionId != null) {
                selectedOption = questionDAO.getOptionById(selectedOptionId);
            }
            
            // Tạo answer
            TestAnswer answer = new TestAnswer();
            answer.setTestSubmissionId(submissionId);
            answer.setQuestionId(questionId);
            answer.setSelectedOptionId(selectedOptionId);
            
            if (selectedOption != null) {
                answer.setIsCorrect(selectedOption.isCorrect());
                answer.setPointsEarned(selectedOption.isCorrect() ? question.getPoints() : 0);
            }
            
            boolean success = submissionDAO.saveAnswer(answer);
            
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": " + success + "}");
            
        } catch (NumberFormatException e) {
            response.getWriter().write("{\"success\": false, \"message\": \"Tham số không hợp lệ\"}");
        }
    }
    
    private void submitExam(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String submissionIdStr = request.getParameter("submissionId");
        
        if (submissionIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
            return;
        }
        
        try {
            int submissionId = Integer.parseInt(submissionIdStr);
            TestSubmission submission = submissionDAO.getSubmissionById(submissionId);
            
            if (submission == null || !submission.isInProgress()) {
                request.getSession().setAttribute("error", "Bài kiểm tra không hợp lệ");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            // Tính điểm
            List<TestAnswer> answers = submissionDAO.getAnswersBySubmission(submissionId);
            double totalScore = 0;
            
            for (TestAnswer answer : answers) {
                totalScore += answer.getPointsEarned();
            }
            
            // Nộp bài
            boolean success = submissionDAO.submitTest(submissionId, totalScore);
            
            if (success) {
                request.getSession().setAttribute("success", "Nộp bài thành công!");
                response.sendRedirect(request.getContextPath() + "/student/exam/result?testId=" + submission.getTestId());
            } else {
                request.getSession().setAttribute("error", "Nộp bài thất bại. Vui lòng thử lại.");
                response.sendRedirect(request.getContextPath() + "/student/exam/take?testId=" + submission.getTestId());
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
        }
    }
    
    private void showResult(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String testIdStr = request.getParameter("testId");
        
        if (testIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
            return;
        }
        
        try {
            int testId = Integer.parseInt(testIdStr);
            Test test = testDAO.getTestById(testId);
            TestSubmission submission = submissionDAO.getSubmissionByTestAndStudent(testId, student.getStudentId());
            
            if (test == null || submission == null || !submission.isSubmitted()) {
                request.getSession().setAttribute("error", "Kết quả không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/exam/list");
                return;
            }
            
            List<TestAnswer> answers = submissionDAO.getAnswersBySubmission(submission.getTestSubmissionId());
            
            request.setAttribute("test", test);
            request.setAttribute("submission", submission);
            request.setAttribute("answers", answers);
            
            request.getRequestDispatcher("/student/exam-result.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/exam/list");
        }
    }
}