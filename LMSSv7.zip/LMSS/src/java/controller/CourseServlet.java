package controller;

import dao.CourseDAO;
import dao.LecturerDAO;
import dao.StudentDAO;
import dao.AssignmentDAO;
import dao.SemesterDAO;
import model.Course;
import model.User;
import model.Lecturer;
import model.Assignment;
import model.Semester;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.util.logging.Level;

public class CourseServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(CourseServlet.class.getName());
    private static final long serialVersionUID = 1L;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private StudentDAO studentDAO;
    private AssignmentDAO assignmentDAO;
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            studentDAO = new StudentDAO();
            assignmentDAO = new AssignmentDAO();
            semesterDAO = new SemesterDAO();
            logger.info("CourseServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize CourseServlet", e);
            throw new ServletException("Failed to initialize CourseServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "list"; // Mặc định là hiển thị danh sách
        }

        try {
            switch (action) {
                case "new":
                    showNewCourseForm(request, response);
                    break;
                case "view":
                    viewCourse(request, response);
                    break;
                case "edit":
                    editCourse(request, response);
                    break;
                case "delete":
                    deleteCourse(request, response);
                    break;
                case "list":
                default:
                    listCourses(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException("Lỗi cơ sở dữ liệu trong CourseServlet (doGet): " + ex.getMessage(), ex);
        } catch (Exception ex) {
            throw new ServletException(
                    "Đã xảy ra lỗi không mong muốn trong doGet của CourseServlet: " + ex.getMessage(), ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        String action = request.getParameter("action");

        if ("update".equals(action)) {
            updateCourse(request, response);
            return;
        }

        String name = request.getParameter("name");
        String code = request.getParameter("code");
        String room = request.getParameter("room");

        int lecturerId = 0;
        int semesterId = 0;
        int totalSessions = 0;

        try {
            lecturerId = Integer.parseInt(request.getParameter("lecturer_id"));
            semesterId = Integer.parseInt(request.getParameter("semester_id"));
            totalSessions = Integer.parseInt(request.getParameter("total_sessions"));
        } catch (NumberFormatException e) {
            session.setAttribute("message",
                    "Lỗi: ID giảng viên, ID học kỳ hoặc Số buổi học không hợp lệ. Vui lòng nhập số.");
            session.setAttribute("messageType", "error");
            // Cập nhật đường dẫn redirect tới /courses
            response.sendRedirect(request.getContextPath() + "/courses?action=new");
            return;
        }

        Course course = new Course(name, code, room, lecturerId, semesterId, totalSessions);

        try {
            courseDAO.addCourse(course);
            session.setAttribute("message", "Thêm khóa học thành công!");
            session.setAttribute("messageType", "success");

            // Cập nhật đường dẫn redirect tới /courses
            response.sendRedirect(request.getContextPath() + "/courses?action=list");

        } catch (SQLException e) {
            session.setAttribute("message", "Lỗi cơ sở dữ liệu khi thêm khóa học: " + e.getMessage());
            session.setAttribute("messageType", "error");
            // Cập nhật đường dẫn redirect tới /courses
            response.sendRedirect(request.getContextPath() + "/courses?action=new");
        } catch (Exception e) {
            session.setAttribute("message", "Đã xảy ra lỗi không mong muốn: " + e.getMessage());
            session.setAttribute("messageType", "error");
            // Cập nhật đường dẫn redirect tới /courses
            response.sendRedirect(request.getContextPath() + "/courses?action=new");
        }
    }

    private void listCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        // Lấy thông tin user từ session
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        List<Course> courses;
        if (user != null && "lecturer".equals(user.getRole())) {
            // Nếu là lecturer, chỉ lấy khóa học của lecturer đó
            try {
                Lecturer lecturer = lecturerDAO.getLecturerByUserId(user.getUserId());
                if (lecturer != null) {
                    courses = courseDAO.getCoursesByLecturer(lecturer.getLecturerId());
                } else {
                    courses = new ArrayList<>();
                }
            } catch (SQLException e) {
                logger.log(Level.WARNING, "Could not load lecturer info: " + e.getMessage(), e);
                courses = new ArrayList<>();
            }
        } else {
            // Nếu là admin hoặc role khác, lấy tất cả khóa học
            courses = courseDAO.getAllCourses();
        }

        request.setAttribute("courses", courses);

        // Lấy assignments cho tất cả courses
        try {
            Map<Integer, List<Assignment>> courseAssignments = new HashMap<>();
            for (Course course : courses) {
                List<Assignment> assignments = assignmentDAO.getAssignmentsByCourse(course.getCourseId());
                courseAssignments.put(course.getCourseId(), assignments);
            }
            request.setAttribute("courseAssignments", courseAssignments);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Could not load assignments: " + e.getMessage(), e);
            // Continue without assignments if there's an error
        }

        // Load danh sách lecturers và semesters cho form tạo khóa học (chỉ admin)
        if (user != null && "admin".equals(user.getRole())) {
            try {
                List<Lecturer> allLecturers = lecturerDAO.getAllLecturers();
                request.setAttribute("lecturers", allLecturers);

                List<Semester> activeSemesters = semesterDAO.getActiveSemesters();
                request.setAttribute("semesters", activeSemesters);
            } catch (Exception e) {
                logger.log(Level.WARNING, "Could not load lecturers/semesters for form: " + e.getMessage(), e);
            }
        }

        if (user != null) {
            String role = user.getRole().toLowerCase();
            switch (role) {
                case "student":
                    request.getRequestDispatcher("/student/courses.jsp").forward(request, response);
                    break;
                case "lecturer":
                    request.getRequestDispatcher("/lecturer/courses.jsp").forward(request, response);
                    break;
                case "admin":
                default:
                    request.getRequestDispatcher("/admin/courses.jsp").forward(request, response);
                    break;
            }
        } else {
            // Nếu chưa đăng nhập, redirect về login
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }

    private void showNewCourseForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("openAddCourseModal", true);
        // Đường dẫn chuyển tiếp đến JSP vẫn giữ nguyên
        request.getRequestDispatcher("/admin/courses.jsp").forward(request, response);
    }

    private void deleteCourse(HttpServletRequest request, HttpServletResponse response)
            throws IOException, SQLException {
        HttpSession session = request.getSession();

        try {
            String idParam = request.getParameter("id");
            System.out.println("=== DELETE COURSE START ===");
            System.out.println("Delete course - ID parameter: " + idParam);

            if (idParam == null || idParam.trim().isEmpty()) {
                throw new IllegalArgumentException("ID parameter is null or empty");
            }

            int courseId = Integer.parseInt(idParam.trim());
            System.out.println("Delete course - Parsed ID: " + courseId);

            // Kiểm tra khóa học có tồn tại không
            Course existingCourse = courseDAO.getCourseById(courseId);
            if (existingCourse == null) {
                throw new IllegalArgumentException("Course not found with ID: " + courseId);
            }

            System.out.println("Delete course - Found course: " + existingCourse.getName());

            // Thực hiện xóa
            courseDAO.deleteCourse(courseId);
            System.out.println("Delete course - Successfully deleted course ID: " + courseId);
            System.out.println("=== DELETE COURSE SUCCESS ===");

            session.setAttribute("message", "Xóa khóa học '" + existingCourse.getName() + "' thành công!");
            session.setAttribute("messageType", "success");

        } catch (NumberFormatException e) {
            System.out.println("Delete course - NumberFormatException: " + e.getMessage());
            session.setAttribute("message", "ID khóa học không hợp lệ: " + e.getMessage());
            session.setAttribute("messageType", "error");
        } catch (IllegalArgumentException e) {
            System.out.println("Delete course - IllegalArgumentException: " + e.getMessage());
            session.setAttribute("message", e.getMessage());
            session.setAttribute("messageType", "error");
        } catch (SQLException e) {
            System.out.println("Delete course - SQLException: " + e.getMessage());
            e.printStackTrace();
            session.setAttribute("message", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            session.setAttribute("messageType", "error");
        } catch (Exception e) {
            System.out.println("Delete course - General Exception: " + e.getMessage());
            e.printStackTrace();
            session.setAttribute("message", "Lỗi không xác định: " + e.getMessage());
            session.setAttribute("messageType", "error");
        }

        System.out.println("Delete course - Redirecting to courses list");
        response.sendRedirect(request.getContextPath() + "/courses");
    }

    private void viewCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        try {
            int courseId = Integer.parseInt(request.getParameter("id"));
            Course course = courseDAO.getCourseById(courseId);

            if (course != null) {
                request.setAttribute("course", course);
                request.getRequestDispatcher("/admin/view-course.jsp").forward(request, response);
            } else {
                HttpSession session = request.getSession();
                session.setAttribute("message", "Không tìm thấy khóa học!");
                session.setAttribute("messageType", "error");
                response.sendRedirect(request.getContextPath() + "/courses");
            }
        } catch (NumberFormatException e) {
            HttpSession session = request.getSession();
            session.setAttribute("message", "ID khóa học không hợp lệ!");
            session.setAttribute("messageType", "error");
            response.sendRedirect(request.getContextPath() + "/courses");
        }
    }

    private void editCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        try {
            int courseId = Integer.parseInt(request.getParameter("id"));
            Course course = courseDAO.getCourseById(courseId);

            if (course != null) {
                // Load lecturers và semesters cho form edit
                LecturerDAO lecturerDAO = new LecturerDAO();
                SemesterDAO semesterDAO = new SemesterDAO();

                List<Lecturer> lecturers = lecturerDAO.getAllLecturers();
                List<Semester> semesters = semesterDAO.getAllSemesters();

                request.setAttribute("course", course);
                request.setAttribute("lecturers", lecturers);
                request.setAttribute("semesters", semesters);
                request.getRequestDispatcher("/admin/edit-course.jsp").forward(request, response);
            } else {
                HttpSession session = request.getSession();
                session.setAttribute("message", "Không tìm thấy khóa học!");
                session.setAttribute("messageType", "error");
                response.sendRedirect(request.getContextPath() + "/courses");
            }
        } catch (NumberFormatException e) {
            HttpSession session = request.getSession();
            session.setAttribute("message", "ID khóa học không hợp lệ!");
            session.setAttribute("messageType", "error");
            response.sendRedirect(request.getContextPath() + "/courses");
        }
    }

    private void updateCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();

        try {
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            String name = request.getParameter("name");
            String code = request.getParameter("code");
            String description = request.getParameter("description");
            String room = request.getParameter("room");
            int lecturerId = Integer.parseInt(request.getParameter("lecturerId"));
            int semesterId = Integer.parseInt(request.getParameter("semester_id"));
            String schedule = request.getParameter("schedule");
            int credits = Integer.parseInt(request.getParameter("credits"));
            int maxStudents = Integer.parseInt(request.getParameter("maxStudents"));
            int totalSessions = Integer.parseInt(request.getParameter("totalSessions"));
            boolean isActive = request.getParameter("isActive") != null;

            Course course = new Course();
            course.setCourseId(courseId);
            course.setName(name);
            course.setCode(code);
            course.setDescription(description);
            course.setRoom(room);
            course.setLecturerId(lecturerId);
            course.setSemesterId(semesterId);
            course.setSchedule(schedule);
            course.setCredits(credits);
            course.setMaxStudents(maxStudents);
            course.setTotalSessions(totalSessions);
            course.setActive(isActive);

            courseDAO.updateCourse(course);

            session.setAttribute("message", "Cập nhật khóa học thành công!");
            session.setAttribute("messageType", "success");

        } catch (NumberFormatException e) {
            session.setAttribute("message", "Dữ liệu không hợp lệ!");
            session.setAttribute("messageType", "error");
        } catch (SQLException e) {
            session.setAttribute("message", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            session.setAttribute("messageType", "error");
        }

        response.sendRedirect(request.getContextPath() + "/courses");
    }
}