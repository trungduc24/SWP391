package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerGradeServlet handles all grade-related operations for lecturers.
 * This includes viewing, submitting, and updating grades for students.
 */

public class LecturerGradeServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerGradeServlet.class.getName());
    private GradeDAO gradeDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private TestDAO testDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        try {
            gradeDAO = new GradeDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            testDAO = new TestDAO();
            studentDAO = new StudentDAO();
            logger.info("LecturerGradeServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerGradeServlet", e);
            throw new ServletException("Failed to initialize LecturerGradeServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Handle different URL patterns
            if (servletPath.equals("/lecturer/grades") && pathInfo == null) {
                showAllGrades(request, response);
            } else if (servletPath.equals("/lecturer/grades") && pathInfo != null) {
                if (pathInfo.startsWith("/course/")) {
                    int courseId = Integer.parseInt(pathInfo.substring(8));
                    showCourseGrades(request, response, courseId);
                } else if (pathInfo.startsWith("/test/")) {
                    int testId = Integer.parseInt(pathInfo.substring(6));
                    showTestGrades(request, response, testId);
                } else if (pathInfo.startsWith("/student/")) {
                    int studentId = Integer.parseInt(pathInfo.substring(9));
                    showStudentGrades(request, response, studentId);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerGradeServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        
        try {
            if ("submit-grade".equals(action)) {
                submitGrade(request, response);
            } else if ("submit-feedback".equals(action)) {
                submitFeedback(request, response);
            } else if ("bulk-submit-grades".equals(action)) {
                bulkSubmitGrades(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerGradeServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showAllGrades(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get courses for this lecturer
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        // Get tests for this lecturer
        List<Test> tests = testDAO.getTestsByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("courses", courses);
        request.setAttribute("tests", tests);
        request.setAttribute("activeSection", "grades");
        
        request.getRequestDispatcher("/lecturer/grades.jsp").forward(request, response);
    }

    private void showCourseGrades(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get course details
        Course course = courseDAO.getCourseById(courseId);
        
        if (course == null) {
            request.getSession().setAttribute("error", "Course not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view grades for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get students enrolled in this course
        List<Student> students = studentDAO.getStudentsByCourseId(courseId);
        
        // Get tests for this course
        List<Test> tests = testDAO.getTestsByCourseId(courseId);
        
        // Get grades for this course
        List<Grade> grades = gradeDAO.getGradesByCourseId(courseId);
        
        request.setAttribute("course", course);
        request.setAttribute("students", students);
        request.setAttribute("tests", tests);
        request.setAttribute("grades", grades);
        request.setAttribute("activeSection", "grades");
        
        request.getRequestDispatcher("/lecturer/course-grades.jsp").forward(request, response);
    }

    private void showTestGrades(HttpServletRequest request, HttpServletResponse response, int testId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get test details
        Test test = testDAO.getTestById(testId);
        
        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get course details
        Course course = courseDAO.getCourseById(test.getCourseId());
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view grades for this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get students enrolled in this course
        List<Student> students = studentDAO.getStudentsByCourseId(test.getCourseId());
        
        // Get grades for this test
        List<Grade> grades = gradeDAO.getGradesByTestId(testId);
        
        request.setAttribute("test", test);
        request.setAttribute("course", course);
        request.setAttribute("students", students);
        request.setAttribute("grades", grades);
        request.setAttribute("activeSection", "grades");
        
        request.getRequestDispatcher("/lecturer/test-grades.jsp").forward(request, response);
    }

    private void showStudentGrades(HttpServletRequest request, HttpServletResponse response, int studentId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get student details
        Student student = studentDAO.getStudentById(studentId);
        
        if (student == null) {
            request.getSession().setAttribute("error", "Student not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get courses taught by this lecturer
        List<Course> lecturerCourses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        // Get courses this student is enrolled in
        List<Course> studentCourses = courseDAO.getCoursesByStudentId(studentId);
        
        // Filter to only courses taught by this lecturer
        studentCourses.removeIf(course -> course.getLecturerId() != lecturer.getLecturerId());
        
        if (studentCourses.isEmpty()) {
            request.getSession().setAttribute("error", "This student is not enrolled in any of your courses.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get tests for these courses
        List<Test> tests = testDAO.getTestsByStudentId(studentId, lecturer.getLecturerId());
        
        // Get grades for this student in lecturer's courses
        List<Grade> grades = gradeDAO.getGradesByStudentId(studentId);
        
        request.setAttribute("student", student);
        request.setAttribute("courses", studentCourses);
        request.setAttribute("tests", tests);
        request.setAttribute("grades", grades);
        request.setAttribute("activeSection", "grades");
        
        request.getRequestDispatcher("/lecturer/student-grades.jsp").forward(request, response);
    }

    private void submitGrade(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get form data
        int studentId = Integer.parseInt(request.getParameter("studentId"));
        int testId = Integer.parseInt(request.getParameter("testId"));
        double score = Double.parseDouble(request.getParameter("score"));
        String feedback = request.getParameter("feedback");
        
        // Get test details
        Test test = testDAO.getTestById(testId);
        
        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get course details
        Course course = courseDAO.getCourseById(test.getCourseId());
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to submit grades for this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Create or update grade
        Grade grade = new Grade();
        grade.setStudentId(studentId);
        grade.setTestId(testId);
        grade.setScore(score);
        grade.setFeedback(feedback);
        grade.setGradeDate((Timestamp) new Date());
        
        boolean success = gradeDAO.updateGrade(grade);
        
        if (success) {
            request.getSession().setAttribute("success", "Grade submitted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to submit grade.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/grades/test/" + testId);
    }

    private void submitFeedback(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get form data
        int gradeId = Integer.parseInt(request.getParameter("gradeId"));
        String feedback = request.getParameter("feedback");
        
        // Get grade details
        Grade grade = gradeDAO.getGradeById(gradeId);
        
        if (grade == null) {
            request.getSession().setAttribute("error", "Grade not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get test details
        Test test = testDAO.getTestById(grade.getTestId());
        
        // Get course details
        Course course = courseDAO.getCourseById(test.getCourseId());
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to submit feedback for this grade.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Update feedback
        grade.setFeedback(feedback);
        
        boolean success = gradeDAO.updateGrade(grade);
        
        if (success) {
            request.getSession().setAttribute("success", "Feedback submitted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to submit feedback.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/grades/test/" + grade.getTestId());
    }

    private void bulkSubmitGrades(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        int testId = Integer.parseInt(request.getParameter("testId"));
        
        // Get test details
        Test test = testDAO.getTestById(testId);
        
        if (test == null) {
            request.getSession().setAttribute("error", "Test not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Get course details
        Course course = courseDAO.getCourseById(test.getCourseId());
        
        // Verify that this lecturer teaches this course
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to submit grades for this test.");
            response.sendRedirect(request.getContextPath() + "/lecturer/grades");
            return;
        }
        
        // Process all student grades
        String[] studentIds = request.getParameterValues("studentId");
        String[] scores = request.getParameterValues("score");
        String[] feedbacks = request.getParameterValues("feedback");
        
        boolean allSuccess = true;
        
        if (studentIds != null && scores != null) {
            for (int i = 0; i < studentIds.length; i++) {
                int studentId = Integer.parseInt(studentIds[i]);
                
                // Skip empty scores
                if (scores[i] == null || scores[i].trim().isEmpty()) {
                    continue;
                }
                
                double score = Double.parseDouble(scores[i]);
                String feedback = (feedbacks != null && i < feedbacks.length) ? feedbacks[i] : "";
                
                // Create or update grade
                Grade grade = new Grade();
                grade.setStudentId(studentId);
                grade.setTestId(testId);
                grade.setScore(score);
                grade.setFeedback(feedback);
                grade.setGradeDate((Timestamp) new Date());
                
                boolean success = gradeDAO.updateGrade(grade);
                if (!success) {
                    allSuccess = false;
                }
            }
        }
        
        if (allSuccess) {
            request.getSession().setAttribute("success", "Grades submitted successfully.");
        } else {
            request.getSession().setAttribute("error", "Some grades could not be saved.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/grades/test/" + testId);
    }
} 