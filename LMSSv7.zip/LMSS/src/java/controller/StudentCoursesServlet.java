package controller;

import dao.CourseDAO;
import dao.StudentDAO;
import dao.SemesterDAO;
import model.CourseDisplayModel;
import model.Student;
import model.User;
import model.Semester;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

@WebServlet("/student/courses")
public class StudentCoursesServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(StudentCoursesServlet.class.getName());
    private CourseDAO courseDAO;
    private StudentDAO studentDAO;
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            studentDAO = new StudentDAO();
            semesterDAO = new SemesterDAO();
            logger.info("StudentCoursesServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize StudentCoursesServlet", e);
            throw new ServletException("Failed to initialize StudentCoursesServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra session và quyền truy cập
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        if (!"student".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ sinh viên mới có quyền truy cập!");
            return;
        }

        try {
            // Lấy thông tin sinh viên
            Student student = studentDAO.getStudentByUserId(currentUser.getUserId());
            if (student == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin sinh viên!");
                return;
            }

            // Lấy danh sách khóa học đã đăng ký
            List<CourseDisplayModel> enrolledCourses = courseDAO.getEnrolledCoursesWithDetails(student.getStudentId());
            
            // Lấy danh sách học kỳ để hiển thị filter
            List<Semester> semesters = semesterDAO.getAllSemesters();
            
            // Đặt attributes cho JSP
            request.setAttribute("enrolledCourses", enrolledCourses);
            request.setAttribute("semesters", semesters);
            request.setAttribute("student", student);
            request.setAttribute("currentUser", currentUser);

            // Log hoạt động
            logger.info("Student " + currentUser.getUsername() + " accessed courses page with " + 
                       enrolledCourses.size() + " courses");

            // Forward tới JSP
            request.getRequestDispatcher("/student/courses.jsp").forward(request, response);

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in StudentCoursesServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error in StudentCoursesServlet", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Xử lý các POST request như filter, search, etc.
        String action = request.getParameter("action");
        
        if ("filter".equals(action)) {
            handleFilterRequest(request, response);
        } else if ("search".equals(action)) {
            handleSearchRequest(request, response);
        } else {
            // Mặc định chuyển về GET
            doGet(request, response);
        }
    }
    
    private void handleFilterRequest(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Lấy tham số filter
        String semesterFilter = request.getParameter("semester");
        String statusFilter = request.getParameter("status");
        
        // Xử lý logic filter (có thể mở rộng sau)
        // Hiện tại chỉ chuyển về GET để load lại trang
        doGet(request, response);
    }
    
    private void handleSearchRequest(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String searchTerm = request.getParameter("searchTerm");
        
        // Xử lý logic search (có thể mở rộng sau)
        // Hiện tại chỉ chuyển về GET để load lại trang
        doGet(request, response);
    }
}