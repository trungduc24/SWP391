package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/exam/submit")
public class ExamSubmitServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(ExamSubmitServlet.class.getName());
    
    private TestSubmissionDAO submissionDAO;
    private StudentDAO studentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            submissionDAO = new TestSubmissionDAO();
            studentDAO = new StudentDAO();
            logger.info("ExamSubmitServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize ExamSubmitServlet", e);
            throw new ServletException("Failed to initialize ExamSubmitServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String submissionIdStr = request.getParameter("submissionId");
        if (submissionIdStr == null) {
            session.setAttribute("error", "Không tìm thấy bài làm");
            response.sendRedirect(request.getContextPath() + "/student/courses");
            return;
        }
        
        try {
            int submissionId = Integer.parseInt(submissionIdStr);
            TestSubmission submission = submissionDAO.getSubmissionById(submissionId);
            
            if (submission == null || submission.isSubmitted()) {
                session.setAttribute("error", "Bài làm không hợp lệ");
                response.sendRedirect(request.getContextPath() + "/student/courses");
                return;
            }
            
            // Tính điểm
            List<TestAnswer> answers = submissionDAO.getAnswersBySubmission(submissionId);
            double totalScore = 0;
            
            for (TestAnswer answer : answers) {
                totalScore += answer.getPointsEarned();
            }
            
            // Nộp bài
            boolean success = submissionDAO.submitTest(submissionId, totalScore);
            
            if (success) {
                session.setAttribute("success", "Nộp bài thành công! Điểm của bạn: " + totalScore);
                response.sendRedirect(request.getContextPath() + "/student/exam-result?testId=" + submission.getTestId());
            } else {
                session.setAttribute("error", "Có lỗi khi nộp bài");
                response.sendRedirect(request.getContextPath() + "/student/exam-take?id=" + submission.getTestId());
            }
            
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid submission ID: " + submissionIdStr, e);
            session.setAttribute("error", "ID bài làm không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/courses");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in ExamSubmitServlet", e);
            session.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/courses");
        }
    }
} 