package controller;

import dao.CourseDAO;
import dao.StudentDAO;
import dao.LecturerDAO;
import dao.UsersDAO;
import dao.SemesterDAO;
import dao.GradeDAO;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DBConnection;

public class AdminReportServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AdminReportServlet.class.getName());
    private CourseDAO courseDAO;
    private StudentDAO studentDAO;
    private LecturerDAO lecturerDAO;
    private UsersDAO usersDAO;
    private SemesterDAO semesterDAO;
    private GradeDAO gradeDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            studentDAO = new StudentDAO();
            lecturerDAO = new LecturerDAO();
            semesterDAO = new SemesterDAO();
            gradeDAO = new GradeDAO();
            logger.info("AdminReportServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize AdminReportServlet", e);
            throw new ServletException("Failed to initialize AdminReportServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Kiểm tra quyền admin
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        if (action == null) {
            action = "dashboard";
        }
        
        try {
            Connection conn = DBConnection.getConnection();
            usersDAO = new UsersDAO(conn);
            
            switch (action) {
                case "dashboard":
                    showDashboard(request, response);
                    break;
                case "users":
                    generateUserReport(request, response);
                    break;
                case "courses":
                    generateCourseReport(request, response);
                    break;
                case "grades":
                    generateGradeReport(request, response);
                    break;
                case "export":
                    exportData(request, response);
                    break;
                case "stats":
                    showStatistics(request, response);
                    break;
                default:
                    showDashboard(request, response);
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminReportServlet", e);
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
    
    private void showDashboard(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {
        
        // Thống kê tổng quan
        Map<String, Integer> stats = new HashMap<>();
        
        try {
            // Đếm số lượng sinh viên, giảng viên và khóa học
            int studentCount = studentDAO.countStudents();
            int lecturerCount = lecturerDAO.countLecturers();
            int courseCount = courseDAO.countCourses();
            int semesterCount = semesterDAO.getAllSemesters().size();
            int activeSemesters = semesterDAO.getActiveSemesters().size();
            
            stats.put("studentCount", studentCount);
            stats.put("lecturerCount", lecturerCount);
            stats.put("courseCount", courseCount);
            stats.put("semesterCount", semesterCount);
            stats.put("activeSemesterCount", activeSemesters);
            
            request.setAttribute("stats", stats);
            request.getRequestDispatcher("/admin/reports.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error generating dashboard statistics", e);
            throw new ServletException("Error generating dashboard statistics", e);
        }
    }
    
    private void generateUserReport(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        // Lấy thông tin về người dùng (students, lecturers, admins)
        try {
            Connection conn = DBConnection.getConnection();
            UsersDAO usersDAO = new UsersDAO(conn);
            
            List<User> allUsers = usersDAO.getAllUsers();
            List<User> students = usersDAO.getUsersByRole("student");
            List<User> lecturers = usersDAO.getUsersByRole("lecturer");
            List<User> admins = usersDAO.getUsersByRole("admin");
            
            // Tạo thống kê
            Map<String, Object> userStats = new HashMap<>();
            userStats.put("totalUsers", allUsers.size());
            userStats.put("studentCount", students.size());
            userStats.put("lecturerCount", lecturers.size());
            userStats.put("adminCount", admins.size());
            userStats.put("verifiedCount", allUsers.stream().filter(User::isEmailVerified).count());
            userStats.put("unverifiedCount", allUsers.stream().filter(u -> !u.isEmailVerified()).count());
            
            request.setAttribute("userStats", userStats);
            request.setAttribute("users", allUsers);
            request.setAttribute("reportType", "users");
            
            request.getRequestDispatcher("/admin/reports.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error generating user report", e);
            throw new ServletException("Error generating user report", e);
        }
    }
    
    private void generateCourseReport(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        try {
            Map<String, Object> courseStats = new HashMap<>();
            courseStats.put("totalCourses", courseDAO.countCourses());
            courseStats.put("activeCourses", courseDAO.countActiveCourses());
            courseStats.put("inactiveCourses", courseDAO.countInactiveCourses());
            
            request.setAttribute("courseStats", courseStats);
            request.setAttribute("courses", courseDAO.getAllCourses());
            request.setAttribute("reportType", "courses");
            
            request.getRequestDispatcher("/admin/reports.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error generating course report", e);
            throw new ServletException("Error generating course report", e);
        }
    }
    
    private void generateGradeReport(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        try {
            // Get grade distribution
            Map<String, Integer> gradeDistribution = gradeDAO.getGradeDistribution();
            request.setAttribute("gradeDistribution", gradeDistribution);
            request.setAttribute("reportType", "grades");
            
            request.getRequestDispatcher("/admin/reports.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error generating grade report", e);
            throw new ServletException("Error generating grade report", e);
        }
    }
    
    private void showStatistics(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        // Trang thống kê chung với biểu đồ
        try {
            Map<String, Object> statistics = new HashMap<>();
            
            // User statistics
            statistics.put("totalUsers", usersDAO.getAllUsers().size());
            statistics.put("studentCount", usersDAO.getUsersByRole("student").size());
            statistics.put("lecturerCount", usersDAO.getUsersByRole("lecturer").size());
            
            // Course statistics
            statistics.put("totalCourses", courseDAO.countCourses());
            statistics.put("activeCourses", courseDAO.countActiveCourses());
            
            // Grade statistics
            statistics.put("gradeDistribution", gradeDAO.getGradeDistribution());
            
            request.setAttribute("statistics", statistics);
            request.getRequestDispatcher("/admin/statistics.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error generating statistics", e);
            throw new ServletException("Error generating statistics", e);
        }
    }
    
    private void exportData(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String format = request.getParameter("format");
        String type = request.getParameter("type");
        
        if (format == null) format = "csv";
        if (type == null) type = "users";
        
        try {
            // Set content type based on export format
            if ("csv".equals(format)) {
                response.setContentType("text/csv");
                response.setHeader("Content-Disposition", "attachment; filename=" + type + ".csv");
                
                // Write CSV data
                if ("users".equals(type)) {
                    exportUsersCsv(response);
                } else if ("courses".equals(type)) {
                    exportCoursesCsv(response);
                } else if ("grades".equals(type)) {
                    exportGradesCsv(response);
                }
                
            } else if ("excel".equals(format)) {
                response.setContentType("application/vnd.ms-excel");
                response.setHeader("Content-Disposition", "attachment; filename=" + type + ".xls");
                
                // Implement Excel export (would require a library like Apache POI)
                response.getWriter().println("Excel export not implemented yet");
            }
            
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error exporting data", e);
            throw new ServletException("Error exporting data", e);
        }
    }
    
    private void exportUsersCsv(HttpServletResponse response) throws IOException, SQLException {
        Connection conn = DBConnection.getConnection();
        UsersDAO usersDAO = new UsersDAO(conn);
        List<User> users = usersDAO.getAllUsers();
        
        StringBuilder csv = new StringBuilder();
        csv.append("ID,Username,Role,Email,Email Verified\n");
        
        for (User user : users) {
            csv.append(user.getUserId()).append(",");
            csv.append(user.getUsername()).append(",");
            csv.append(user.getRole()).append(",");
            csv.append(user.getEmail()).append(",");
            csv.append(user.isEmailVerified()).append("\n");
        }
        
        response.getWriter().write(csv.toString());
    }
    
    private void exportCoursesCsv(HttpServletResponse response) throws IOException, SQLException {
        List<model.Course> courses = courseDAO.getAllCourses();
        
        StringBuilder csv = new StringBuilder();
        csv.append("ID,Name,Code,Room,Lecturer ID,Semester ID,Status\n");
        
        for (model.Course course : courses) {
            csv.append(course.getCourseId()).append(",");
            csv.append(course.getName()).append(",");
            csv.append(course.getCode()).append(",");
            csv.append(course.getRoom()).append(",");
            csv.append(course.getLecturerId()).append(",");
            csv.append(course.getSemesterId()).append(",");
            csv.append(course.isActive() ? "active" : "inactive").append("\n");
        }
        
        response.getWriter().write(csv.toString());
    }
    
    private void exportGradesCsv(HttpServletResponse response) throws IOException, SQLException {
        // Implement grade export
        response.getWriter().write("Student ID,Course ID,Grade,Timestamp\n");
        // Add grade data here
    }
} 