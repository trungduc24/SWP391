package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.util.logging.Level;

public class LecturerServletNew extends HttpServlet {
    private static final Logger logger = Logger.getLogger(LecturerServlet.class.getName());
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            semesterDAO = new SemesterDAO();
            logger.info("LecturerServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerServlet", e);
            throw new ServletException("Failed to initialize LecturerServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Kiểm tra quyền lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"lecturer".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Get URL information
        String servletPath = request.getServletPath();
        String action = request.getParameter("action");

        try {
            // Handle different URL patterns
            if (servletPath.equals("/lecturer")) {
                // Direct /lecturer access - show dashboard
                showDashboard(request, response);
                return;
            } else if (servletPath.equals("/lec/dashboard")) {
                showDashboard(request, response);
                return;
            } else if (servletPath.equals("/lec/courses")) {
                showMyCourses(request, response);
                return;
            } else if (action != null) {
                // Handle action parameter for backward compatibility
                switch (action) {
                    case "dashboard":
                        showDashboard(request, response);
                        return;
                    case "courses":
                        showMyCourses(request, response);
                        return;
                    default:
                        showDashboard(request, response);
                        return;
                }
            } else {
                // Default to dashboard
                showDashboard(request, response);
                return;
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showDashboard(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        try {
            // Get lecturer information
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            if (currentUser == null) {
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            request.setAttribute("lecturer", lecturer);

            // Get courses - with error handling
            List<Course> myCourses = new ArrayList<>();
            try {
                myCourses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
            } catch (Exception e) {
                logger.warning("Error getting courses: " + e.getMessage());
                myCourses = new ArrayList<>();
            }
            request.setAttribute("myCourses", myCourses);
            request.setAttribute("recentCourses", myCourses.size() > 5 ? myCourses.subList(0, 5) : myCourses);

            // Get semesters - with error handling
            List<Semester> semesters = new ArrayList<>();
            try {
                semesters = semesterDAO.getAllSemesters();
            } catch (Exception e) {
                logger.warning("Error getting semesters: " + e.getMessage());
            }
            request.setAttribute("semesters", semesters);

            // Statistics - simplified
            int totalCourses = myCourses.size();
            int activeCourses = (int) myCourses.stream().filter(Course::isActive).count();
            int totalStudents = 0; // Simplified - will implement later
            int totalTests = 0; // Simplified - will implement later
            int totalAssignments = 0; // Simplified - will implement later

            request.setAttribute("totalCourses", totalCourses);
            request.setAttribute("activeCourses", activeCourses);
            request.setAttribute("totalStudents", totalStudents);
            request.setAttribute("totalTests", totalTests);
            request.setAttribute("totalAssignments", totalAssignments);

            // Recent announcements - simplified
            List<Announcement> recentAnnouncements = new ArrayList<>();
            request.setAttribute("recentAnnouncements", recentAnnouncements);

            // Upcoming tests - simplified
            List<Test> upcomingTests = new ArrayList<>();
            request.setAttribute("upcomingTests", upcomingTests);

            // Forward to dashboard JSP
            String jspPath = "/lecturer/dashboard.jsp";
            request.getRequestDispatcher(jspPath).forward(request, response);

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error loading dashboard", e);
            throw e;
        }
    }

    private void showMyCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        try {
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());

            List<Course> myCourses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
            List<Semester> semesters = semesterDAO.getAllSemesters();

            request.setAttribute("lecturer", lecturer);
            request.setAttribute("myCourses", myCourses);
            request.setAttribute("semesters", semesters);

            request.getRequestDispatcher("/lecturer/courses.jsp").forward(request, response);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error loading courses", e);
            throw e;
        }
    }
}
