package controller;

import dao.UsersDAO;
import dao.CourseDAO;
import dao.SemesterDAO;
import model.User;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Logger;
import java.util.logging.Level;

public class AdminDashboardServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AdminDashboardServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Load statistics
            loadDashboardStats(req);
            
            // Forward to dashboard JSP
            req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminDashboardServlet", e);
            req.setAttribute("error", "Lỗi khi tải dữ liệu dashboard!");
            req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
        }
    }

    private void loadDashboardStats(HttpServletRequest req) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                logger.severe("Cannot get database connection");
                return;
            }

            // Total users
            int totalUsers = getTotalUsers(conn);
            req.setAttribute("totalUsers", totalUsers);

            // Total courses
            int totalCourses = getTotalCourses(conn);
            req.setAttribute("totalCourses", totalCourses);

            // Total semesters
            int totalSemesters = getTotalSemesters(conn);
            req.setAttribute("totalSemesters", totalSemesters);

            // Active users
            int activeUsers = getActiveUsers(conn);
            req.setAttribute("activeUsers", activeUsers);

            // Users by role
            int totalStudents = getUsersByRole(conn, "student");
            int totalLecturers = getUsersByRole(conn, "lecturer");
            int totalAdmins = getUsersByRole(conn, "admin");
            
            req.setAttribute("totalStudents", totalStudents);
            req.setAttribute("totalLecturers", totalLecturers);
            req.setAttribute("totalAdmins", totalAdmins);

            // Recent activities (last 10 system logs)
            loadRecentActivities(conn, req);
        }
    }

    private int getTotalUsers(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private int getTotalCourses(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM courses";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private int getTotalSemesters(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM semesters";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private int getActiveUsers(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE is_active = 1";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private int getUsersByRole(Connection conn, String role) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE role = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, role);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    private void loadRecentActivities(Connection conn, HttpServletRequest req) throws SQLException {
        String sql = "SELECT TOP 10 sl.action, sl.table_name, sl.new_values, sl.created_at, u.username " +
                     "FROM system_logs sl " +
                     "LEFT JOIN users u ON sl.user_id = u.user_id " +
                     "ORDER BY sl.created_at DESC";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            StringBuilder activities = new StringBuilder();
            while (rs.next()) {
                String action = rs.getString("action");
                String tableName = rs.getString("table_name");
                String description = rs.getString("new_values");
                String username = rs.getString("username");
                String createdAt = rs.getString("created_at");
                
                activities.append(String.format(
                    "<div class='activity-item'>" +
                    "<strong>%s</strong> %s trên bảng %s<br>" +
                    "<small class='text-muted'>%s - %s</small>" +
                    "</div>",
                    username != null ? username : "Unknown",
                    getActionDescription(action),
                    tableName,
                    description != null ? description : "",
                    createdAt
                ));
            }
            
            req.setAttribute("recentActivities", activities.toString());
        }
    }

    private String getActionDescription(String action) {
        switch (action) {
            case "CREATE_USER": return "tạo người dùng mới";
            case "UPDATE_USER": return "cập nhật người dùng";
            case "DELETE_USER": return "xóa người dùng";
            case "CREATE_COURSE": return "tạo khóa học mới";
            case "UPDATE_COURSE": return "cập nhật khóa học";
            case "DELETE_COURSE": return "xóa khóa học";
            case "CREATE_SEMESTER": return "tạo học kỳ mới";
            case "UPDATE_SEMESTER": return "cập nhật học kỳ";
            case "DELETE_SEMESTER": return "xóa học kỳ";
            case "LOGIN": return "đăng nhập";
            case "LOGOUT": return "đăng xuất";
            default: return "thực hiện hành động";
        }
    }
}
