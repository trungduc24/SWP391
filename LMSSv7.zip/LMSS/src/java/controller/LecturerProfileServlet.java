package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import org.mindrot.jbcrypt.BCrypt;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerProfileServlet handles lecturer profile management operations.
 * This includes viewing and updating profile information.
 */
@MultipartConfig
public class LecturerProfileServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerProfileServlet.class.getName());
    private LecturerDAO lecturerDAO;
    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        try {
            lecturerDAO = new LecturerDAO();
            userDAO = new UsersDAO();
            logger.info("LecturerProfileServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerProfileServlet", e);
            throw new ServletException("Failed to initialize LecturerProfileServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            request.setAttribute("user", currentUser);
            request.setAttribute("activeSection", "profile");
            
            request.getRequestDispatcher("/lecturer/profile.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerProfileServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        
        try {
            if ("update-profile".equals(action)) {
                updateProfile(request, response);
            } else if ("change-password".equals(action)) {
                changePassword(request, response);
            } else if ("upload-avatar".equals(action)) {
                uploadAvatar(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerProfileServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void updateProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Get lecturer information
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
        if (lecturer == null) {
            logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
            session.setAttribute("error", "Lecturer information not found.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        // Get form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String qualification = request.getParameter("qualification");

        // Update user information
        currentUser.setFullName(firstName + " " + lastName);
        currentUser.setEmail(email);
        
        boolean userUpdateSuccess = userDAO.updateUser(currentUser);
        
        // Update lecturer information
        lecturer.setPhone(phone);
        lecturer.setSpecialization(qualification);

        boolean lecturerUpdateSuccess = lecturerDAO.updateLecturer(lecturer);
        
        if (userUpdateSuccess && lecturerUpdateSuccess) {
            session.setAttribute("success", "Profile updated successfully.");
            // Update session user
            session.setAttribute("user", currentUser);
        } else {
            session.setAttribute("error", "Failed to update profile.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/profile");
    }

    private void changePassword(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Get form data
        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");
        
        // Validate passwords
        if (!newPassword.equals(confirmPassword)) {
            session.setAttribute("error", "New passwords do not match.");
            response.sendRedirect(request.getContextPath() + "/lecturer/profile");
            return;
        }
        
        // Check current password
        User dbUser = userDAO.getUserById(currentUser.getUserId());
        if (dbUser == null || !BCrypt.checkpw(currentPassword, dbUser.getPassword())) {
            session.setAttribute("error", "Current password is incorrect.");
            response.sendRedirect(request.getContextPath() + "/lecturer/profile");
            return;
        }
        
        // Update password
        boolean success = userDAO.updatePassword(currentUser.getUserId(), newPassword);
        
        if (success) {
            session.setAttribute("success", "Password changed successfully.");
        } else {
            session.setAttribute("error", "Failed to change password.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/profile");
    }

    private void uploadAvatar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Get lecturer information
        Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
        if (lecturer == null) {
            logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
            session.setAttribute("error", "Lecturer information not found.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        // Get uploaded file
        Part filePart = request.getPart("avatar");
        
        if (filePart == null || filePart.getSize() == 0) {
            session.setAttribute("error", "No file uploaded.");
            response.sendRedirect(request.getContextPath() + "/lecturer/profile");
            return;
        }
        
        // Validate file type
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String fileExtension = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
        
        if (!fileExtension.equals(".jpg") && !fileExtension.equals(".jpeg") && !fileExtension.equals(".png")) {
            session.setAttribute("error", "Only JPG, JPEG, and PNG files are allowed.");
            response.sendRedirect(request.getContextPath() + "/lecturer/profile");
            return;
        }
        
        // Generate unique file name
        String newFileName = UUID.randomUUID().toString() + fileExtension;
        
        // Create upload directory if it doesn't exist
        String uploadPath = getServletContext().getRealPath("/uploads/avatars");
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        
        // Save file
        try (InputStream fileContent = filePart.getInputStream()) {
            Files.copy(fileContent, Paths.get(uploadPath + File.separator + newFileName), StandardCopyOption.REPLACE_EXISTING);
        }
        
        // Update avatar path in database
        String avatarPath = "uploads/avatars/" + newFileName;
        lecturer.setAvatarUrl(avatarPath);
        
        boolean success = lecturerDAO.updateLecturerAvatar(lecturer);
        
        if (success) {
            session.setAttribute("success", "Avatar uploaded successfully.");
        } else {
            session.setAttribute("error", "Failed to upload avatar.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/profile");
    }
} 