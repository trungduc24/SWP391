package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/exam/save-answer")
public class ExamSaveAnswerServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(ExamSaveAnswerServlet.class.getName());
    
    private TestSubmissionDAO submissionDAO;
    private TestQuestionDAO questionDAO;
    private StudentDAO studentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            submissionDAO = new TestSubmissionDAO();
            questionDAO = new TestQuestionDAO();
            studentDAO = new StudentDAO();
            logger.info("ExamSaveAnswerServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize ExamSaveAnswerServlet", e);
            throw new ServletException("Failed to initialize ExamSaveAnswerServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (user == null || !"student".equals(user.getRole())) {
            out.write("{\"success\": false, \"message\": \"Unauthorized\"}");
            return;
        }
        
        String submissionIdStr = request.getParameter("submissionId");
        String questionIdStr = request.getParameter("questionId");
        String selectedOptionIdStr = request.getParameter("selectedOptionId");
        String answerText = request.getParameter("answerText");
        
        if (submissionIdStr == null || questionIdStr == null) {
            out.write("{\"success\": false, \"message\": \"Missing parameters\"}");
            return;
        }
        
        try {
            int submissionId = Integer.parseInt(submissionIdStr);
            int questionId = Integer.parseInt(questionIdStr);
            
            // Tạo TestAnswer object
            TestAnswer answer = new TestAnswer();
            answer.setTestSubmissionId(submissionId);
            answer.setQuestionId(questionId);
            
            if (selectedOptionIdStr != null && !selectedOptionIdStr.isEmpty()) {
                // Multiple choice answer
                int selectedOptionId = Integer.parseInt(selectedOptionIdStr);
                answer.setSelectedOptionId(selectedOptionId);
                answer.setAnswerText(null);
                
                // Kiểm tra xem câu trả lời có đúng không
                TestQuestionOption option = questionDAO.getOptionById(selectedOptionId);
                if (option != null) {
                    answer.setIsCorrect(option.isCorrect());
                    
                    // Lấy điểm của câu hỏi
                    TestQuestion question = questionDAO.getQuestionById(questionId);
                    if (question != null && option.isCorrect()) {
                        answer.setPointsEarned(question.getPoints());
                    } else {
                        answer.setPointsEarned(0.0);
                    }
                } else {
                    answer.setIsCorrect(false);
                    answer.setPointsEarned(0.0);
                }
            } else {
                // Text answer
                answer.setSelectedOptionId(null);
                answer.setAnswerText(answerText);
                answer.setIsCorrect(null); // Sẽ được chấm sau
                answer.setPointsEarned(0.0); // Sẽ được cập nhật khi chấm
            }
            
            boolean success = submissionDAO.saveAnswer(answer);
            
            if (success) {
                out.write("{\"success\": true, \"message\": \"Answer saved\"}");
            } else {
                out.write("{\"success\": false, \"message\": \"Failed to save answer\"}");
            }
            
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid parameters", e);
            out.write("{\"success\": false, \"message\": \"Invalid parameters\"}");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error", e);
            out.write("{\"success\": false, \"message\": \"Database error\"}");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error saving answer", e);
            out.write("{\"success\": false, \"message\": \"Server error\"}");
        }
    }
}