package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerMaterialServlet handles all material-related operations for lecturers.
 * This includes uploading, viewing, and deleting course materials.
 */
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1 MB
    maxFileSize = 1024 * 1024 * 10,       // 10 MB
    maxRequestSize = 1024 * 1024 * 50     // 50 MB
)
public class LecturerMaterialServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerMaterialServlet.class.getName());
    private MaterialDAO materialDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private static final String UPLOAD_DIRECTORY = "uploads/materials";

    @Override
    public void init() throws ServletException {
        try {
            materialDAO = new MaterialDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            
            // Create upload directory if it doesn't exist
            String uploadPath = getServletContext().getRealPath(UPLOAD_DIRECTORY);
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            
            logger.info("LecturerMaterialServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerMaterialServlet", e);
            throw new ServletException("Failed to initialize LecturerMaterialServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.log(Level.WARNING, "Lecturer not found for user ID: {0}", currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Handle different URL patterns
            if (servletPath.equals("/lecturer/materials/upload")) {
                showUploadForm(request, response);
            } else if (servletPath.equals("/lecturer/materials") && pathInfo == null) {
                showAllMaterials(request, response);
            } else if (servletPath.equals("/lecturer/materials") && pathInfo != null) {
                if (pathInfo.startsWith("/view/")) {
                    int materialId = Integer.parseInt(pathInfo.substring(6));
                    viewMaterial(request, response, materialId);
                } else if (pathInfo.startsWith("/delete/")) {
                    int materialId = Integer.parseInt(pathInfo.substring(8));
                    deleteMaterial(request, response, materialId);
                } else if (pathInfo.startsWith("/download/")) {
                    int materialId = Integer.parseInt(pathInfo.substring(10));
                    downloadMaterial(request, response, materialId);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid material ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerMaterialServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        
        try {
            if ("upload-material".equals(action)) {
                uploadMaterial(request, response);
            } else if ("delete-material".equals(action)) {
                int materialId = Integer.parseInt(request.getParameter("materialId"));
                deleteMaterial(request, response, materialId);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid material ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerMaterialServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showAllMaterials(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get all materials uploaded by this lecturer
        List<Material> materials = materialDAO.getMaterialsByLecturerId(lecturer.getLecturerId());
        
        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("materials", materials);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "materials");
        
        request.getRequestDispatcher("/lecturer/materials.jsp").forward(request, response);
    }

    private void showUploadForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get courses for dropdown
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
        
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "materials");
        
        request.getRequestDispatcher("/lecturer/upload-material.jsp").forward(request, response);
    }

    private void viewMaterial(HttpServletRequest request, HttpServletResponse response, int materialId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get material details
        Material material = materialDAO.getMaterialById(materialId);
        
        if (material == null) {
            request.getSession().setAttribute("error", "Material not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        // Verify that this lecturer uploaded the material
        Course course = courseDAO.getCourseById(material.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to view this material.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        request.setAttribute("material", material);
        request.setAttribute("course", course);
        request.setAttribute("activeSection", "materials");
        
        request.getRequestDispatcher("/lecturer/view-material.jsp").forward(request, response);
    }

    private void uploadMaterial(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get form data
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        
        // Verify course belongs to lecturer
        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to upload materials for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        // Handle file upload
        Part filePart = request.getPart("file");
        String fileName = getSubmittedFileName(filePart);
        String fileType = filePart.getContentType();
        long fileSize = filePart.getSize();
        
        if (fileName == null || fileName.isEmpty()) {
            request.getSession().setAttribute("error", "No file selected.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials/upload");
            return;
        }
        
        // Generate unique file name to prevent conflicts
        String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
        String uploadPath = getServletContext().getRealPath(UPLOAD_DIRECTORY);
        String filePath = uploadPath + File.separator + uniqueFileName;
        
        // Save file to server
        try (InputStream input = filePart.getInputStream()) {
            Files.copy(input, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
        }
        
        // Create material object
        Material material = new Material();
        material.setTitle(title);
        material.setDescription(description);
        material.setCourseId(courseId);
        material.setFilePath(UPLOAD_DIRECTORY + "/" + uniqueFileName);
        material.setFileType(fileType);
        material.setFileSize(fileSize);
        material.setUploadedBy(lecturer.getLecturerId());
        
        // Save material to database
        int materialId = materialDAO.addMaterial(material);
        
        if (materialId > 0) {
            request.getSession().setAttribute("success", "Material uploaded successfully.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials/view/" + materialId);
        } else {
            // Delete uploaded file if database insertion fails
            Files.deleteIfExists(Paths.get(filePath));
            request.getSession().setAttribute("error", "Failed to upload material.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials/upload");
        }
    }

    private void deleteMaterial(HttpServletRequest request, HttpServletResponse response, int materialId)
            throws ServletException, IOException, SQLException {
        
        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        
        // Get material details
        Material material = materialDAO.getMaterialById(materialId);
        
        if (material == null) {
            request.getSession().setAttribute("error", "Material not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        // Verify that this lecturer uploaded the material
        Course course = courseDAO.getCourseById(material.getCourseId());
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to delete this material.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        // Delete file from server
        String filePath = getServletContext().getRealPath(material.getFilePath());
        Files.deleteIfExists(Paths.get(filePath));
        
        // Delete material from database
        boolean success = materialDAO.deleteMaterial(materialId);
        
        if (success) {
            request.getSession().setAttribute("success", "Material deleted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to delete material.");
        }
        
        response.sendRedirect(request.getContextPath() + "/lecturer/materials");
    }

    private void downloadMaterial(HttpServletRequest request, HttpServletResponse response, int materialId)
            throws ServletException, IOException, SQLException {
        
        // Get material details
        Material material = materialDAO.getMaterialById(materialId);
        
        if (material == null) {
            request.getSession().setAttribute("error", "Material not found.");
            response.sendRedirect(request.getContextPath() + "/lecturer/materials");
            return;
        }
        
        // Set response headers
        response.setContentType(material.getFileType());
        response.setHeader("Content-Disposition", "attachment; filename=\"" + material.getTitle()+ "\"");
        response.setContentLengthLong(material.getFileSize());
        
        // Stream file to client
        String filePath = getServletContext().getRealPath(material.getFilePath());
        Files.copy(Paths.get(filePath), response.getOutputStream());
    }

    private String getSubmittedFileName(Part part) {
        for (String cd : part.getHeader("content-disposition").split(";")) {
            if (cd.trim().startsWith("filename")) {
                String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
                return fileName.contains("\\") ? fileName.substring(fileName.lastIndexOf('\\') + 1) : fileName;
            }
        }
        return null;
    }
} 