package model;

import java.sql.Timestamp;
import java.util.Date;

public class Test {
    private int testId;
    private String title;
    private String description;
    private int courseId;
    private Date deadline;
    private double totalPoints;
    private int createdBy;
    private Date createdAt;
    private String testType;
    private double maxScore;
    private Timestamp startTime;
    private Timestamp endTime;
    private int duration;
    private boolean isPublished;
    
    // Thêm các fields mới cho hiển thị thông tin liên quan
    private String courseName;
    private String courseCode;
    private String lecturerName;
    
    // Constructor mặc định
    public Test() {
    }
    
    // Constructor đầy đủ
    public Test(int testId, String title, String description, int courseId, Date deadline, 
                double totalPoints, int createdBy, Date createdAt, String testType) {
        this.testId = testId;
        this.title = title;
        this.description = description;
        this.courseId = courseId;
        this.deadline = deadline;
        this.totalPoints = totalPoints;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.testType = testType;
    }

    // Constructor với tất cả fields
    public Test(int testId, String title, String description, int courseId, 
                double totalPoints, int createdBy, Date createdAt, String testType, 
                double maxScore, Timestamp startTime, Timestamp endTime, 
                int duration, boolean isPublished) {
        this.testId = testId;
        this.title = title;
        this.description = description;
        this.courseId = courseId;
        this.totalPoints = totalPoints;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.testType = testType;
        this.maxScore = maxScore;
        this.startTime = startTime;
        this.endTime = endTime;
        this.duration = duration;
        this.isPublished = isPublished;
    }

    // Getters and Setters
    public int getTestId() {
        return testId;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public double getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(double totalPoints) {
        this.totalPoints = totalPoints;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public double getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(double maxScore) {
        this.maxScore = maxScore;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public boolean isPublished() {
        return isPublished;
    }

    public void setPublished(boolean published) {
        isPublished = published;
    }

    // Thêm getters và setters cho các fields mới
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public void setLecturerName(String lecturerName) {
        this.lecturerName = lecturerName;
    }

    // Compatibility methods for legacy code
    @Deprecated
    public double getMax_score() {
        return maxScore;
    }

    @Deprecated
    public void setMax_score(double maxScore) {
        this.maxScore = maxScore;
    }

    @Deprecated
    public Timestamp getStart_time() {
        return startTime;
    }

    @Deprecated
    public void setStart_time(Timestamp startTime) {
        this.startTime = startTime;
    }

    @Deprecated
    public Timestamp getEnd_time() {
        return endTime;
    }

    @Deprecated
    public void setEnd_time(Timestamp endTime) {
        this.endTime = endTime;
    }

    @Deprecated
    public int getDuration_minutes() {
        return duration;
    }

    @Deprecated
    public void setDuration_minutes(int duration) {
        this.duration = duration;
    }

    @Deprecated
    public boolean isIs_published() {
        return isPublished;
    }

    @Deprecated
    public void setIs_published(boolean isPublished) {
        this.isPublished = isPublished;
    }

    @Override
    public String toString() {
        return "Test{" +
                "testId=" + testId +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", courseId=" + courseId +
                ", deadline=" + deadline +
                ", totalPoints=" + totalPoints +
                ", createdBy=" + createdBy +
                ", createdAt=" + createdAt +
                ", testType='" + testType + '\'' +
                ", maxScore=" + maxScore +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", duration=" + duration +
                ", isPublished=" + isPublished +
                ", courseName='" + courseName + '\'' +
                ", courseCode='" + courseCode + '\'' +
                ", lecturerName='" + lecturerName + '\'' +
                '}';
    }
}