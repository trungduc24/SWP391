package model;

import java.sql.Timestamp;

public class ForumPost {
    private int postId;
    private int forumId;
    private int userId;
    private String content;
    private Timestamp createdAt;
    private String userFullName; // For display purposes
    private String userAvatar; // For display purposes

    public ForumPost() {
    }

    public ForumPost(int postId, int forumId, int userId, String content, Timestamp createdAt) {
        this.postId = postId;
        this.forumId = forumId;
        this.userId = userId;
        this.content = content;
        this.createdAt = createdAt;
    }

    public ForumPost(int postId, int forumId, int userId, String content, Timestamp createdAt, 
                     String userFullName, String userAvatar) {
        this.postId = postId;
        this.forumId = forumId;
        this.userId = userId;
        this.content = content;
        this.createdAt = createdAt;
        this.userFullName = userFullName;
        this.userAvatar = userAvatar;
    }

    // Getters and Setters
    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public int getForumId() {
        return forumId;
    }

    public void setForumId(int forumId) {
        this.forumId = forumId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getUserFullName() {
        return userFullName;
    }

    public void setUserFullName(String userFullName) {
        this.userFullName = userFullName;
    }

    public String getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(String userAvatar) {
        this.userAvatar = userAvatar;
    }
} 