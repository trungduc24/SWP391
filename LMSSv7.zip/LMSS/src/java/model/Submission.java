package model;

import java.sql.Timestamp;

public class Submission {
    private int submissionId;
    private int assignmentId;
    private int studentId;
    private String submissionText;
    private String fileUrl;
    private Timestamp submittedAt;
    private Double score;
    private String feedback;
    private String status;
    private Integer gradedBy;
    private Timestamp gradedAt;
    
    // Thông tin bổ sung để hiển thị
    private String studentName;
    private String assignmentTitle;
    private String courseName;
    
    // Constructor mặc định
    public Submission() {
    }
    
    // Constructor đầy đủ
    public Submission(int submissionId, int assignmentId, int studentId, String submissionText,
                     String fileUrl, Timestamp submittedAt, Double score, String feedback,
                     String status, Integer gradedBy, Timestamp gradedAt) {
        this.submissionId = submissionId;
        this.assignmentId = assignmentId;
        this.studentId = studentId;
        this.submissionText = submissionText;
        this.fileUrl = fileUrl;
        this.submittedAt = submittedAt;
        this.score = score;
        this.feedback = feedback;
        this.status = status;
        this.gradedBy = gradedBy;
        this.gradedAt = gradedAt;
    }
    
    // Constructor cho việc tạo submission mới
    public Submission(int assignmentId, int studentId, String submissionText, String fileUrl) {
        this.assignmentId = assignmentId;
        this.studentId = studentId;
        this.submissionText = submissionText;
        this.fileUrl = fileUrl;
        this.status = "submitted";
    }
    
    // Getters and Setters
    public int getSubmissionId() { return submissionId; }
    public void setSubmissionId(int submissionId) { this.submissionId = submissionId; }
    
    public int getAssignmentId() { return assignmentId; }
    public void setAssignmentId(int assignmentId) { this.assignmentId = assignmentId; }
    
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    
    public String getSubmissionText() { return submissionText; }
    public void setSubmissionText(String submissionText) { this.submissionText = submissionText; }
    
    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }
    
    public Timestamp getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Timestamp submittedAt) { this.submittedAt = submittedAt; }
    
    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }
    
    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getGradedBy() { return gradedBy; }
    public void setGradedBy(Integer gradedBy) { this.gradedBy = gradedBy; }
    
    public Timestamp getGradedAt() { return gradedAt; }
    public void setGradedAt(Timestamp gradedAt) { this.gradedAt = gradedAt; }
    
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    
    public String getAssignmentTitle() { return assignmentTitle; }
    public void setAssignmentTitle(String assignmentTitle) { this.assignmentTitle = assignmentTitle; }
    
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    
    // Tiện ích
    public boolean isGraded() {
        return score != null;
    }
    
    public boolean isLate() {
        return "late".equals(status);
    }
}