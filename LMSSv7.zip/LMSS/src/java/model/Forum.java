package model;

import java.sql.Timestamp;

public class Forum {
    private int forumId;
    private int courseId;
    private String title;
    private int createdBy;
    private Timestamp createdAt;

    public Forum() {

    }

    public void setForumId(int forumId) {
        this.forumId = forumId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public int getForumId() {
        return forumId;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public Forum(int forumId, int courseId, String title, int createdBy, Timestamp createdAt) {
        this.forumId = forumId;
        this.courseId = courseId;
        this.title = title;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    // Getters & Setters...
}