package model;

public class Lecturer {
    private int lecturerId;
    private int userId;
    private String fullName;
    private String lecturerCode;
    private String email;
    private String avatarUrl;
    private String department;
    private String phone;
    private String specialization;
    private String degree;

    public Lecturer() {
    }

    public Lecturer(int lecturerId, int userId, String fullName, String lecturerCode, String email, String avatarUrl) {
        this.lecturerId = lecturerId;
        this.userId = userId;
        this.fullName = fullName;
        this.lecturerCode = lecturerCode;
        this.email = email;
        this.avatarUrl = avatarUrl;
    }

    public Lecturer(int lecturerId, int userId, String fullName, String lecturerCode, String email, String avatarUrl,
            String department, String phone, String specialization, String degree) {
        this.lecturerId = lecturerId;
        this.userId = userId;
        this.fullName = fullName;
        this.lecturerCode = lecturerCode;
        this.email = email;
        this.avatarUrl = avatarUrl;
        this.department = department;
        this.phone = phone;
        this.specialization = specialization;
        this.degree = degree;
    }

    // Getter và Setter
    public int getLecturerId() {
        return lecturerId;
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getLecturerCode() {
        return lecturerCode;
    }

    public void setLecturerCode(String lecturerCode) {
        this.lecturerCode = lecturerCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
}
