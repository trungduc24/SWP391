package model;

import java.sql.Timestamp;
import java.util.Date;

public class Grade {
    private int gradeId;
    private int studentId;
    private int testId;
    private double score;
    private String feedback;
    private Timestamp gradeDate;
    private int gradedBy;
    private String grade_type;
    private int course_id;
    private Date graded_at;
    private double max_score;
    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    public Date getGraded_at() {
        return graded_at;
    }

    public void setGraded_at(Date graded_at) {
        this.graded_at = graded_at;
    }
    // Non-persistent fields
    private String studentName;
    private String testTitle;
    
    // Constructors
    public Grade() {
    }
    
    public Grade(int gradeId, int studentId, int testId, double score, 
                String feedback, Timestamp gradeDate, int gradedBy) {
        this.gradeId = gradeId;
        this.studentId = studentId;
        this.testId = testId;
        this.score = score;
        this.feedback = feedback;
        this.gradeDate = gradeDate;
        this.gradedBy = gradedBy;
    }

    public Grade(int gradeId, int studentId, int testId, double score, String feedback, Timestamp gradeDate, int gradedBy, String grade_type, int course_id, Date graded_at, double max_score, String studentName, String testTitle) {
        this.gradeId = gradeId;
        this.studentId = studentId;
        this.testId = testId;
        this.score = score;
        this.feedback = feedback;
        this.gradeDate = gradeDate;
        this.gradedBy = gradedBy;
        this.grade_type = grade_type;
        this.course_id = course_id;
        this.graded_at = graded_at;
        this.max_score = max_score;
        this.studentName = studentName;
        this.testTitle = testTitle;
    }

   

    public String getGrade_type() {
        return grade_type;
    }

    public void setGrade_type(String grade_type) {
        this.grade_type = grade_type;
    }
    
    // Getters and Setters
    public int getGradeId() {
        return gradeId;
    }

    public double getMax_score() {
        return max_score;
    }

    public void setMax_score(double max_score) {
        this.max_score = max_score;
    }
    
    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }
    
    public int getStudentId() {
        return studentId;
    }
    
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public int getTestId() {
        return testId;
    }
    
    public void setTestId(int testId) {
        this.testId = testId;
    }
    
    public double getScore() {
        return score;
    }
    
    public void setScore(double score) {
        this.score = score;
    }
    
    public String getFeedback() {
        return feedback;
    }
    
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
    
    public Timestamp getGradeDate() {
        return gradeDate;
    }
    
    public void setGradeDate(Timestamp gradeDate) {
        this.gradeDate = gradeDate;
    }
    
    public int getGradedBy() {
        return gradedBy;
    }
    
    public void setGradedBy(int gradedBy) {
        this.gradedBy = gradedBy;
    }
    
    public String getStudentName() {
        return studentName;
    }
    
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    
    public String getTestTitle() {
        return testTitle;
    }
    
    public void setTestTitle(String testTitle) {
        this.testTitle = testTitle;
    }
    
    @Override
    public String toString() {
        return "Grade{" +
                "gradeId=" + gradeId +
                ", studentId=" + studentId +
                ", testId=" + testId +
                ", score=" + score +
                ", feedback='" + feedback + '\'' +
                ", gradeDate=" + gradeDate +
                ", gradedBy=" + gradedBy +
                ", studentName='" + studentName + '\'' +
                ", testTitle='" + testTitle + '\'' +
                '}';
    }
}
