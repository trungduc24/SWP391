package model;

import java.sql.Timestamp;

public class Announcement {
    private int announcementId;
    private String title;
    private String content;
    private int courseId;
    private Timestamp createdAt;
    private int createdBy;
    private boolean important;
    
    // Constructors
    public Announcement() {
    }
    
    public Announcement(int announcementId, String title, String content, int courseId, 
                        Timestamp createdAt, int createdBy, boolean important) {
        this.announcementId = announcementId;
        this.title = title;
        this.content = content;
        this.courseId = courseId;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.important = important;
    }
    
    // Getters and Setters
    public int getAnnouncementId() {
        return announcementId;
    }
    
    public void setAnnouncementId(int announcementId) {
        this.announcementId = announcementId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public int getCourseId() {
        return courseId;
    }
    
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public int getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }
    
    public boolean isImportant() {
        return important;
    }
    
    public void setImportant(boolean important) {
        this.important = important;
    }
    
    @Override
    public String toString() {
        return "Announcement{" +
                "announcementId=" + announcementId +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", courseId=" + courseId +
                ", createdAt=" + createdAt +
                ", createdBy=" + createdBy +
                ", important=" + important +
                '}';
    }
} 