package model;

import java.sql.Timestamp;

public class Notification {
    private int notificationId;
    private int userId;
    private String title;
    private String message;
    private String notificationType; // info, warning, success, error
    private boolean isRead;
    private String actionUrl;
    private Timestamp createdAt;
    private Timestamp readAt;
    
    // Constructor mặc định
    public Notification() {}
    
    // Constructor đầy đủ
    public Notification(int notificationId, int userId, String title, String message, 
                       String notificationType, boolean isRead, String actionUrl, 
                       Timestamp createdAt, Timestamp readAt) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.notificationType = notificationType;
        this.isRead = isRead;
        this.actionUrl = actionUrl;
        this.createdAt = createdAt;
        this.readAt = readAt;
    }
    
    // Constructor đơn giản để tạo thông báo mới
    public Notification(int userId, String title, String message, String notificationType, String actionUrl) {
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.notificationType = notificationType;
        this.actionUrl = actionUrl;
        this.isRead = false;
        this.createdAt = new Timestamp(System.currentTimeMillis());
    }
    
    // Getters and Setters
    public int getNotificationId() {
        return notificationId;
    }
    
    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getNotificationType() {
        return notificationType;
    }
    
    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }
    
    public boolean isRead() {
        return isRead;
    }
    
    public void setRead(boolean read) {
        isRead = read;
    }
    
    public String getActionUrl() {
        return actionUrl;
    }
    
    public void setActionUrl(String actionUrl) {
        this.actionUrl = actionUrl;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getReadAt() {
        return readAt;
    }
    
    public void setReadAt(Timestamp readAt) {
        this.readAt = readAt;
    }
    
    // Compatibility methods for legacy code
    @Deprecated
    public boolean getIs_read() {
        return isRead;
    }
    
    @Deprecated
    public void setIs_read(boolean isRead) {
        this.isRead = isRead;
    }
    
    @Deprecated
    public String getAction_url() {
        return actionUrl;
    }
    
    @Deprecated
    public void setAction_url(String actionUrl) {
        this.actionUrl = actionUrl;
    }
    
    @Deprecated
    public Timestamp getCreated_at() {
        return createdAt;
    }
    
    @Deprecated
    public void setCreated_at(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    @Deprecated
    public Timestamp getRead_at() {
        return readAt;
    }
    
    @Deprecated
    public void setRead_at(Timestamp readAt) {
        this.readAt = readAt;
    }
    
    @Override
    public String toString() {
        return "Notification{" +
                "notificationId=" + notificationId +
                ", userId=" + userId +
                ", title='" + title + '\'' +
                ", message='" + message + '\'' +
                ", notificationType='" + notificationType + '\'' +
                ", isRead=" + isRead +
                ", actionUrl='" + actionUrl + '\'' +
                ", createdAt=" + createdAt +
                ", readAt=" + readAt +
                '}';
    }
}