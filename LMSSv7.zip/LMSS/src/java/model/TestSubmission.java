package model;

import java.sql.Timestamp;
import java.util.List;

public class TestSubmission {
    private int testSubmissionId;
    private int testId;
    private int studentId;
    private Timestamp startedAt;
    private Timestamp submittedAt;
    private Double score;
    private String status;
    private Integer timeSpentMinutes;
    
    // Thông tin bổ sung
    private String testTitle;
    private String studentName;
    private int durationMinutes;
    private double maxScore;
    
    // List các câu trả lời
    private List<TestAnswer> answers;
    
    // Constructor mặc định
    public TestSubmission() {
    }
    
    // Constructor đầy đủ
    public TestSubmission(int testSubmissionId, int testId, int studentId, 
                         Timestamp startedAt, Timestamp submittedAt, Double score,
                         String status, Integer timeSpentMinutes) {
        this.testSubmissionId = testSubmissionId;
        this.testId = testId;
        this.studentId = studentId;
        this.startedAt = startedAt;
        this.submittedAt = submittedAt;
        this.score = score;
        this.status = status;
        this.timeSpentMinutes = timeSpentMinutes;
    }
    
    // Getters and Setters
    public int getTestSubmissionId() { return testSubmissionId; }
    public void setTestSubmissionId(int testSubmissionId) { this.testSubmissionId = testSubmissionId; }
    
    public int getTestId() { return testId; }
    public void setTestId(int testId) { this.testId = testId; }
    
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    
    public Timestamp getStartedAt() { return startedAt; }
    public void setStartedAt(Timestamp startedAt) { this.startedAt = startedAt; }
    
    public Timestamp getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Timestamp submittedAt) { this.submittedAt = submittedAt; }
    
    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getTimeSpentMinutes() { return timeSpentMinutes; }
    public void setTimeSpentMinutes(Integer timeSpentMinutes) { this.timeSpentMinutes = timeSpentMinutes; }
    
    public String getTestTitle() { return testTitle; }
    public void setTestTitle(String testTitle) { this.testTitle = testTitle; }
    
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    
    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }
    
    public double getMaxScore() { return maxScore; }
    public void setMaxScore(double maxScore) { this.maxScore = maxScore; }
    
    public List<TestAnswer> getAnswers() { return answers; }
    public void setAnswers(List<TestAnswer> answers) { this.answers = answers; }
    
    // Utility methods
    public boolean isInProgress() {
        return "in_progress".equals(status);
    }
    
    public boolean isSubmitted() {
        return "submitted".equals(status);
    }
    
    public boolean isGraded() {
        return "graded".equals(status);
    }
    
    public long getTimeElapsedMinutes() {
        if (startedAt == null) return 0;
        
        Timestamp endTime = submittedAt != null ? submittedAt : new Timestamp(System.currentTimeMillis());
        return (endTime.getTime() - startedAt.getTime()) / (1000 * 60);
    }
}