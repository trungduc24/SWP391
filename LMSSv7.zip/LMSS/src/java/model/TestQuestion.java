package model;

import java.util.List;

public class TestQuestion {
    private int questionId;
    private int testId;
    private String questionText;
    private String questionType;
    private double points;
    private int questionOrder;
    
    // List các options cho câu hỏi trắc nghiệm
    private List<TestQuestionOption> options;
    
    // Constructor mặc định
    public TestQuestion() {
    }
    
    // Constructor đầy đủ
    public TestQuestion(int questionId, int testId, String questionText, String questionType, 
                       double points, int questionOrder) {
        this.questionId = questionId;
        this.testId = testId;
        this.questionText = questionText;
        this.questionType = questionType;
        this.points = points;
        this.questionOrder = questionOrder;
    }
    
    // Getters and Setters
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    
    public int getTestId() { return testId; }
    public void setTestId(int testId) { this.testId = testId; }
    
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    
    public String getQuestionType() { return questionType; }
    public void setQuestionType(String questionType) { this.questionType = questionType; }
    
    public double getPoints() { return points; }
    public void setPoints(double points) { this.points = points; }
    
    public int getQuestionOrder() { return questionOrder; }
    public void setQuestionOrder(int questionOrder) { this.questionOrder = questionOrder; }
    
    public List<TestQuestionOption> getOptions() { return options; }
    public void setOptions(List<TestQuestionOption> options) { this.options = options; }
    
    // Utility method để kiểm tra có phải câu hỏi trắc nghiệm
    public boolean isMultipleChoice() {
        return "multiple_choice".equals(questionType);
    }
    
    public boolean isTrueFalse() {
        return "true_false".equals(questionType);
    }
}