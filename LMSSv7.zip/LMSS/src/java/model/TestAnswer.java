package model;

public class TestAnswer {
    private int answerId;
    private int testSubmissionId;
    private int questionId;
    private Integer selectedOptionId;
    private String answerText;
    private Boolean isCorrect;
    private double pointsEarned;
    
    // Thông tin bổ sung
    private String questionText;
    private String selectedOptionText;
    private double maxPoints;
    
    // Constructor mặc định
    public TestAnswer() {
    }
    
    // Constructor đầy đủ
    public TestAnswer(int answerId, int testSubmissionId, int questionId, 
                     Integer selectedOptionId, String answerText, Boolean isCorrect,
                     double pointsEarned) {
        this.answerId = answerId;
        this.testSubmissionId = testSubmissionId;
        this.questionId = questionId;
        this.selectedOptionId = selectedOptionId;
        this.answerText = answerText;
        this.isCorrect = isCorrect;
        this.pointsEarned = pointsEarned;
    }
    
    // Getters and Setters
    public int getAnswerId() { return answerId; }
    public void setAnswerId(int answerId) { this.answerId = answerId; }
    
    public int getTestSubmissionId() { return testSubmissionId; }
    public void setTestSubmissionId(int testSubmissionId) { this.testSubmissionId = testSubmissionId; }
    
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    
    public Integer getSelectedOptionId() { return selectedOptionId; }
    public void setSelectedOptionId(Integer selectedOptionId) { this.selectedOptionId = selectedOptionId; }
    
    public String getAnswerText() { return answerText; }
    public void setAnswerText(String answerText) { this.answerText = answerText; }
    
    public Boolean getIsCorrect() { return isCorrect; }
    public void setIsCorrect(Boolean isCorrect) { this.isCorrect = isCorrect; }
    
    public double getPointsEarned() { return pointsEarned; }
    public void setPointsEarned(double pointsEarned) { this.pointsEarned = pointsEarned; }
    
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    
    public String getSelectedOptionText() { return selectedOptionText; }
    public void setSelectedOptionText(String selectedOptionText) { this.selectedOptionText = selectedOptionText; }
    
    public double getMaxPoints() { return maxPoints; }
    public void setMaxPoints(double maxPoints) { this.maxPoints = maxPoints; }
}