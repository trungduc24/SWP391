package controller;

import dao.AssignmentDAO;
import dao.SubmissionDAO;
import dao.StudentDAO;
import dao.EnrollmentDAO;
import model.Assignment;
import model.Submission;
import model.Student;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet({"/student/assignments", "/student/assignment/*"})
public class StudentAssignmentServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(StudentAssignmentServlet.class.getName());
    
    private AssignmentDAO assignmentDAO;
    private SubmissionDAO submissionDAO;
    private StudentDAO studentDAO;
    private EnrollmentDAO enrollmentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            assignmentDAO = new AssignmentDAO();
            submissionDAO = new SubmissionDAO();
            studentDAO = new StudentDAO();
            enrollmentDAO = new EnrollmentDAO();
            logger.info("StudentAssignmentServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize StudentAssignmentServlet", e);
            throw new ServletException("Failed to initialize StudentAssignmentServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        String servletPath = request.getServletPath();
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            request.setAttribute("student", student);
            
            // Xử lý các URL khác nhau
            if ("/student/assignments".equals(servletPath)) {
                // Hiển thị danh sách tất cả assignments
                showAssignmentList(request, response, student);
            } else if (pathInfo != null) {
                switch (pathInfo) {
                    case "/submit":
                        showSubmissionForm(request, response, student);
                        break;
                    case "/view":
                        viewSubmission(request, response, student);
                        break;
                    default:
                        response.sendRedirect(request.getContextPath() + "/student/assignments");
                        break;
                }
            } else {
                response.sendRedirect(request.getContextPath() + "/student/assignments");
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in StudentAssignmentServlet", e);
            throw new ServletException("Database error", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in StudentAssignmentServlet", e);
            throw new ServletException("Error processing request", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            
            switch (pathInfo) {
                case "/submit":
                    handleSubmission(request, response, student);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/student/assignments");
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in StudentAssignmentServlet", e);
            throw new ServletException("Database error", e);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in StudentAssignmentServlet", e);
            throw new ServletException("Error processing request", e);
        }
    }
    
    private void showAssignmentList(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException, Exception {
        
        // Lấy tất cả assignments từ các khóa học đã đăng ký
        List<Assignment> assignments = assignmentDAO.getAssignmentsByStudentId(student.getStudentId());
        List<Submission> studentSubmissions = submissionDAO.getSubmissionsByStudent(student.getStudentId());
        
        // Phân loại assignments
        List<Assignment> completedAssignments = new ArrayList<>();
        List<Assignment> upcomingAssignments = new ArrayList<>(); 
        List<Assignment> overdueAssignments = new ArrayList<>();
        List<Assignment> submittedAssignments = new ArrayList<>();
        
        Map<Integer, Submission> submissions = new HashMap<>();
        for (Submission submission : studentSubmissions) {
            submissions.put(submission.getAssignmentId(), submission);
        }
        
        Date now = new Date();
        
        for (Assignment assignment : assignments) {
            Submission submission = submissions.get(assignment.getAssignmentId());
            boolean isOverdue = assignment.getDueDate() != null && now.after(assignment.getDueDate());
            
            if (submission != null) {
                if (submission.getScore() != null) {
                    // Đã chấm điểm
                    completedAssignments.add(assignment);
                } else {
                    // Đã nộp nhưng chưa chấm
                    submittedAssignments.add(assignment);
                }
            } else if (isOverdue) {
                // Chưa nộp và đã quá hạn
                overdueAssignments.add(assignment);
            } else {
                // Chưa nộp và chưa quá hạn
                upcomingAssignments.add(assignment);
            }
        }
        
        // Sắp xếp theo due date
        Comparator<Assignment> dueDateComparator = (a1, a2) -> {
            if (a1.getDueDate() == null && a2.getDueDate() == null) return 0;
            if (a1.getDueDate() == null) return 1;
            if (a2.getDueDate() == null) return -1;
            return a1.getDueDate().compareTo(a2.getDueDate());
        };
        
        upcomingAssignments.sort(dueDateComparator);
        overdueAssignments.sort(dueDateComparator);
        submittedAssignments.sort(dueDateComparator);
        completedAssignments.sort(dueDateComparator);
        
        // Tính toán thống kê
        int totalAssignments = assignments.size();
        int completedCount = completedAssignments.size();
        double completionRate = totalAssignments > 0 ? (completedCount * 100.0 / totalAssignments) : 0;
        
        // Set attributes cho JSP
        request.setAttribute("assignments", assignments);
        request.setAttribute("submissions", submissions);
        request.setAttribute("completedAssignments", completedAssignments);
        request.setAttribute("upcomingAssignments", upcomingAssignments);
        request.setAttribute("overdueAssignments", overdueAssignments);
        request.setAttribute("submittedAssignments", submittedAssignments);
        request.setAttribute("completionRate", completionRate);
        
        logger.info("Loading assignments for student " + student.getStudentId() + 
                   ": Total=" + totalAssignments + 
                   ", Completed=" + completedCount + 
                   ", Upcoming=" + upcomingAssignments.size() + 
                   ", Overdue=" + overdueAssignments.size() + 
                   ", Submitted=" + submittedAssignments.size());
        
        request.getRequestDispatcher("/student/assignments.jsp").forward(request, response);
    }
    
    private void showSubmissionForm(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String assignmentIdStr = request.getParameter("assignmentId");
        
        if (assignmentIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            int assignmentId = Integer.parseInt(assignmentIdStr);
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            
            if (assignment == null) {
                request.setAttribute("error", "Assignment not found");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), assignment.getCourseId())) {
                request.setAttribute("error", "You are not enrolled in this course");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Lấy submission hiện tại nếu có
            Submission existingSubmission = submissionDAO.getSubmissionByStudentAndAssignment(
                student.getStudentId(), assignmentId);
            
            request.setAttribute("assignment", assignment);
            request.setAttribute("submission", existingSubmission);
            request.getRequestDispatcher("/student/assignment-submit.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error showing submission form", e);
            throw new ServletException("Error showing submission form", e);
        }
    }
    
    private void handleSubmission(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String assignmentIdStr = request.getParameter("assignmentId");
        String submissionText = request.getParameter("submissionText");
        String fileUrl = request.getParameter("fileUrl");
        
        if (assignmentIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            int assignmentId = Integer.parseInt(assignmentIdStr);
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            
            if (assignment == null) {
                request.setAttribute("error", "Assignment not found");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), assignment.getCourseId())) {
                request.setAttribute("error", "You are not enrolled in this course");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Tạo submission
            Submission submission = new Submission(assignmentId, student.getStudentId(), submissionText, fileUrl);
            
            boolean success = submissionDAO.submitAssignment(submission);
            
            if (success) {
                request.getSession().setAttribute("success", "Assignment submitted successfully!");
            } else {
                request.getSession().setAttribute("error", "Failed to submit assignment. Please try again.");
            }
            
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error handling submission", e);
            request.getSession().setAttribute("error", "Error submitting assignment: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        }
    }
    
    private void viewSubmission(HttpServletRequest request, HttpServletResponse response, Student student) 
            throws ServletException, IOException, SQLException {
        String assignmentIdStr = request.getParameter("assignmentId");
        
        if (assignmentIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            int assignmentId = Integer.parseInt(assignmentIdStr);
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            Submission submission = submissionDAO.getSubmissionByStudentAndAssignment(
                student.getStudentId(), assignmentId);
            
            if (assignment == null || submission == null) {
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            request.setAttribute("assignment", assignment);
            request.setAttribute("submission", submission);
            request.getRequestDispatcher("/student/assignment-view.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error viewing submission", e);
            throw new ServletException("Error viewing submission", e);
        }
    }
}