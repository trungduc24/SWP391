package controller;

import dao.StudentDAO;
import model.Student;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/student/settings")
public class StudentSettingsServlet extends HttpServlet {

    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Load student info
        Student student = studentDAO.getStudentWithDetailsByUserId(user.getUserId());
        request.setAttribute("student", student);

        request.getRequestDispatcher("/student/settings.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        if ("updateInfo".equals(action)) {
            updateStudentInfo(request, response, user.getUserId());
        } else if ("updatePassword".equals(action)) {
            updateStudentPassword(request, response, user.getUserId());
        } else {
            doGet(request, response);
        }
    }

    private void updateStudentInfo(HttpServletRequest request, HttpServletResponse response, int userId)
            throws ServletException, IOException {
        try {
            String fullName = request.getParameter("fullName");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String dateOfBirth = request.getParameter("dateOfBirth");
            String className = request.getParameter("className");
            String enrollmentYear = request.getParameter("enrollmentYear");

            System.out.println("Updating info for user: " + userId);
            System.out.println("Full Name: " + fullName);
            System.out.println("Phone: " + phone);
            System.out.println("Address: " + address);
            System.out.println("Date of Birth: " + dateOfBirth);
            System.out.println("Class Name: " + className);
            System.out.println("Enrollment Year: " + enrollmentYear);

            // Validation
            if (fullName == null || fullName.trim().isEmpty()) {
                request.setAttribute("errorMessage", "Họ và tên không được để trống.");
                doGet(request, response);
                return;
            }

            // Validate phone number (int)
            if (phone != null && !phone.trim().isEmpty()) {
                try {
                    int phoneInt = Integer.parseInt(phone.trim());
                    if (phoneInt <= 0) {
                        request.setAttribute("errorMessage", "Số điện thoại phải là số dương.");
                        doGet(request, response);
                        return;
                    }
                    String phoneStr = String.valueOf(phoneInt);
                    if (phoneStr.length() < 10 || phoneStr.length() > 11) {
                        request.setAttribute("errorMessage", "Số điện thoại phải có 10-11 chữ số.");
                        doGet(request, response);
                        return;
                    }
                } catch (NumberFormatException e) {
                    request.setAttribute("errorMessage", "Số điện thoại phải là số nguyên.");
                    doGet(request, response);
                    return;
                }
            }

            // Validate enrollment year
            if (enrollmentYear != null && !enrollmentYear.trim().isEmpty()) {
                try {
                    int year = Integer.parseInt(enrollmentYear.trim());
                    int currentYear = java.time.Year.now().getValue();
                    if (year < 1950 || year > currentYear + 1) {
                        request.setAttribute("errorMessage", "Năm nhập học không hợp lệ.");
                        doGet(request, response);
                        return;
                    }
                } catch (NumberFormatException e) {
                    request.setAttribute("errorMessage", "Năm nhập học phải là số nguyên.");
                    doGet(request, response);
                    return;
                }
            }

            boolean success = studentDAO.updateStudentInfo(userId, fullName.trim(), phone, address, dateOfBirth, className, enrollmentYear);

            if (success) {
                request.setAttribute("successMessage", "Cập nhật thông tin thành công.");
            } else {
                request.setAttribute("errorMessage", "Cập nhật thông tin thất bại.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi cập nhật thông tin: " + e.getMessage());
        }

        doGet(request, response);
    }

    private void updateStudentPassword(HttpServletRequest request, HttpServletResponse response, int userId)
            throws ServletException, IOException {
        try {
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");

            // Validation
            if (currentPassword == null || currentPassword.trim().isEmpty()) {
                request.setAttribute("passwordError", "Mật khẩu hiện tại không được để trống.");
                doGet(request, response);
                return;
            }

            if (newPassword == null || newPassword.trim().isEmpty()) {
                request.setAttribute("passwordError", "Mật khẩu mới không được để trống.");
                doGet(request, response);
                return;
            }

            if (newPassword.length() < 6) {
                request.setAttribute("passwordError", "Mật khẩu mới phải có ít nhất 6 ký tự.");
                doGet(request, response);
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                request.setAttribute("passwordError", "Xác nhận mật khẩu không khớp.");
                doGet(request, response);
                return;
            }

            boolean success = studentDAO.updateStudentPassword(userId, currentPassword, newPassword);

            if (success) {
                request.setAttribute("passwordSuccess", "Đổi mật khẩu thành công.");
            } else {
                request.setAttribute("passwordError", "Mật khẩu hiện tại không đúng.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("passwordError", "Lỗi khi đổi mật khẩu: " + e.getMessage());
        }

        doGet(request, response);
    }
}
