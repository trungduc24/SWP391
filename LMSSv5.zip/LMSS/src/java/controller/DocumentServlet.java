package controller;

import dao.CourseDAO;
import dao.MaterialDAO;
import dao.EnrollmentDAO;
import model.User;
import model.Student;
import model.Course;
import model.CourseDisplayModel;
import model.Material;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/student/documents")
public class DocumentServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Student student = (Student) session.getAttribute("student");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        try {
            // Lấy danh sách khóa học đã đăng ký
            EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
            List<Course> enrolledCourses = enrollmentDAO.getEnrolledCoursesByStudentId(student.getStudentId());
            
            // Convert Course sang CourseDisplayModel
            List<CourseDisplayModel> courseDisplayModels = new ArrayList<>();
            for (Course course : enrolledCourses) {
                CourseDisplayModel displayModel = new CourseDisplayModel();
                displayModel.setCourseId(course.getCourseId());
                displayModel.setName(course.getName());
                displayModel.setCode(course.getCode());
                displayModel.setDescription(course.getDescription());
                displayModel.setRoom(course.getRoom());
                displayModel.setLecturerId(course.getLecturerId());
                displayModel.setSemesterId(course.getSemesterId());
                displayModel.setTotalSessions(course.getTotalSessions());
                displayModel.setCredits(course.getCredits());
                displayModel.setMaxStudents(course.getMaxStudents());
                displayModel.setSchedule(course.getSchedule());
                // Set tên giảng viên mặc định nếu cần
                displayModel.setLecturerName("Giảng viên"); // Có thể query từ DB để lấy tên thật
                courseDisplayModels.add(displayModel);
            }
            
            // Lấy tài liệu cho từng khóa học
            MaterialDAO materialDAO = new MaterialDAO();
            Map<Integer, List<Material>> courseMaterials = new HashMap<>();
            
            for (CourseDisplayModel course : courseDisplayModels) {
                List<Material> materials = materialDAO.getMaterialsByCourseId(course.getCourseId());
                courseMaterials.put(course.getCourseId(), materials);
            }
            
            // Tạo SimpleDateFormat
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            
            // Set attributes cho JSP
            request.setAttribute("enrolledCourses", courseDisplayModels);
            request.setAttribute("courseMaterials", courseMaterials);
            request.setAttribute("sdf", sdf);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Có lỗi xảy ra khi tải dữ liệu tài liệu.");
        }
        
        request.getRequestDispatcher("/student/documents.jsp").forward(request, response);
    }
}