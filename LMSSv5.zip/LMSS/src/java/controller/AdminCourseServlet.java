package controller;

import dao.CourseDAO;
import dao.SemesterDAO;
import dao.LecturerDAO;
import model.Course;
import model.Semester;
import model.Lecturer;
import model.User;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdminCourseServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AdminCourseServlet.class.getName());
    private CourseDAO courseDAO;
    private SemesterDAO semesterDAO;
    private LecturerDAO lecturerDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            semesterDAO = new SemesterDAO();
            lecturerDAO = new LecturerDAO();
            logger.info("AdminCourseServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize AdminCourseServlet", e);
            throw new ServletException("Failed to initialize AdminCourseServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Kiểm tra quyền admin
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        
        try {
            switch (action) {
                case "list":
                    listCourses(request, response);
                    break;
                case "view":
                    viewCourse(request, response);
                    break;
                case "search":
                    searchCourses(request, response);
                    break;
                default:
                    listCourses(request, response);
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminCourseServlet", e);
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Kiểm tra quyền admin
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        
        try {
            switch (action) {
                case "delete":
                    deleteCourse(request, response);
                    break;
                default:
                    listCourses(request, response);
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AdminCourseServlet POST", e);
            throw new ServletException("Database error: " + e.getMessage(), e);
        }
    }
    
    private void listCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        // Lấy danh sách tất cả khóa học
        List<Course> courses = courseDAO.getAllCourses();
        request.setAttribute("courses", courses);
        
        // Lấy danh sách học kỳ để hiển thị tên học kỳ
        List<Semester> semesters = semesterDAO.getAllSemesters();
        request.setAttribute("semesters", semesters);
        
        // Forward đến JSP
        request.getRequestDispatcher("/admin/courses.jsp").forward(request, response);
    }
    
    private void viewCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        String courseIdStr = request.getParameter("id");
        if (courseIdStr == null || courseIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/courses?error=invalid_id");
            return;
        }
        
        try {
            int courseId = Integer.parseInt(courseIdStr);
            Course course = courseDAO.getCourseById(courseId);
            
            if (course == null) {
                response.sendRedirect(request.getContextPath() + "/admin/courses?error=course_not_found");
                return;
            }
            
            // Lấy thông tin học kỳ và giảng viên
            Semester semester = semesterDAO.getSemesterById(course.getSemesterId());
            Lecturer lecturer = lecturerDAO.getLecturerById(course.getLecturerId());
            
            request.setAttribute("course", course);
            request.setAttribute("semester", semester);
            request.setAttribute("lecturer", lecturer);
            
            request.getRequestDispatcher("/admin/view-course.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/courses?error=invalid_id");
        }
    }
    
    private void searchCourses(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        String keyword = request.getParameter("keyword");
        if (keyword == null) {
            keyword = "";
        }
        
        List<Course> courses;
        if (keyword.trim().isEmpty()) {
            courses = courseDAO.getAllCourses();
        } else {
            courses = courseDAO.getAllCourses(); // Thay thế hàm searchCourses tạm thời
        }
        
        request.setAttribute("courses", courses);
        request.setAttribute("keyword", keyword);
        
        // Lấy danh sách học kỳ để hiển thị tên học kỳ
        List<Semester> semesters = semesterDAO.getAllSemesters();
        request.setAttribute("semesters", semesters);
        
        request.getRequestDispatcher("/admin/courses.jsp").forward(request, response);
    }
    
    private void deleteCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        String courseIdStr = request.getParameter("id");
        if (courseIdStr == null || courseIdStr.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/courses?error=invalid_id");
            return;
        }
        
        try {
            int courseId = Integer.parseInt(courseIdStr);
            
            // Kiểm tra xem khóa học có tồn tại không
            Course course = courseDAO.getCourseById(courseId);
            if (course == null) {
                response.sendRedirect(request.getContextPath() + "/admin/courses?error=course_not_found");
                return;
            }
            
            // Xóa khóa học
            courseDAO.deleteCourse(courseId);
            
            // Log action
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            String description = "Admin " + currentUser.getUsername() + " deleted course: " + course.getName() + " (ID: " + courseId + ")";
            logAction(request, "DELETE_COURSE", "courses", courseId, description);
            
            response.sendRedirect(request.getContextPath() + "/admin/courses?success=course_deleted");
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/courses?error=invalid_id");
        }
    }
    
    private void logAction(HttpServletRequest request, String action, String tableName, Integer recordId, String description) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO system_logs (user_id, action, table_name, record_id, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)";
            
            try (var stmt = conn.prepareStatement(sql)) {
                HttpSession session = request.getSession();
                User currentUser = (User) session.getAttribute("user");
                
                stmt.setInt(1, currentUser.getUserId());
                stmt.setString(2, action);
                stmt.setString(3, tableName);
                stmt.setObject(4, recordId);
                stmt.setString(5, description);
                stmt.setString(6, getClientIP(request));
                
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to log action: " + e.getMessage(), e);
        }
    }
    
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null) {
            return xForwardedFor.split(",")[0];
        }
        return request.getRemoteAddr();
    }
} 