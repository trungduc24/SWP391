package controller;

import dao.TestDAO;
import dao.StudentDAO;
import model.Test;
import model.TestSubmission;
import model.Student;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/student/test-results")
public class TestResultServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null || !"student".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        try {
            StudentDAO studentDAO = new StudentDAO();
            TestDAO testDAO = new TestDAO();
            
            // Lấy thông tin student
            Student student = studentDAO.getStudentByUserId(currentUser.getUserId());
            if (student == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin sinh viên!");
                return;
            }
            
            // Lấy danh sách bài kiểm tra đã làm
            List<Test> completedTests = testDAO.getCompletedTestsByStudent(student.getStudentId());
            
            // Lấy điểm số cho từng bài kiểm tra
            Map<Integer, TestSubmission> testSubmissions = testDAO.getTestSubmissionsByStudent(student.getStudentId());
            
            // Tính toán thống kê
            int totalTests = completedTests.size();
            int passedTests = 0;
            double totalScore = 0;
            double averageScore = 0;
            
            for (Test test : completedTests) {
                TestSubmission submission = testSubmissions.get(test.getTestId());
                if (submission != null && submission.getScore() != null) {
                    totalScore += submission.getScore();
                    if (submission.getScore() >= test.getMaxScore() * 0.5) { // Điểm đạt >= 50%
                        passedTests++;
                    }
                }
            }
            
            if (totalTests > 0) {
                averageScore = totalScore / totalTests;
            }
            
            // Set attributes
            request.setAttribute("student", student);
            request.setAttribute("currentUser", currentUser);
            request.setAttribute("completedTests", completedTests);
            request.setAttribute("testSubmissions", testSubmissions);
            request.setAttribute("totalTests", totalTests);
            request.setAttribute("passedTests", passedTests);
            request.setAttribute("averageScore", averageScore);
            request.setAttribute("totalScore", totalScore);
            
            // Forward to JSP
            request.getRequestDispatcher("/student/test-results.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
        }
    }
}