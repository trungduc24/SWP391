package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.GradeDAO;
import dao.MaterialDAO;
import dao.StudentDAO;
import dao.TestDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.List;
import model.Course;
import model.Material;
import model.Student;
import model.Test;
import model.User;
import model.*;
public class StudentServlet extends HttpServlet {

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private GradeDAO gradeDAO = new GradeDAO();
    private MaterialDAO materialDAO = new MaterialDAO();
    private TestDAO testDAO = new TestDAO();
    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !user.getRole().equalsIgnoreCase("user")) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Student student = studentDAO.getStudentByUserId(user.getUserId());
        request.setAttribute("student", student);

        String path = request.getPathInfo();
        if (path == null) {
            path = "/dashboard";
        }

        switch (path) {
            case "/dashboard":
               // showDashboard(request, response, student);
                break;
            case "/courses":
                showCourses(request, response, student);
                break;
            case "/materials":
                //showMaterials(request, response, student);
                break;
            case "/assignments":
                showAssignments(request, response, student);
                break;
            case "/grades":
                showGrades(request, response, student);
                break;
            case "/forum":
                showForum(request, response, student);
                break;
            case "/calendar":
                showCalendar(request, response, student);
                break;
            case "/settings":
                showSettings(request, response, student);
                break;
            case "/profile":
                showProfile(request, response, student);
                break;
            default:
                if (path.startsWith("/courses/")) {
                    try {
                        showCourseDetails(request, response, student, path);
                    } catch (SQLException e) {
                        e.printStackTrace();
                        response.sendRedirect(request.getContextPath() + "/student/courses");
                    }
                } else {
                    response.sendRedirect(request.getContextPath() + "/student/dashboard");
                }
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !user.getRole().equalsIgnoreCase("user")) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Student student = studentDAO.getStudentByUserId(user.getUserId());

        String path = request.getPathInfo();
        if (path == null) {
            response.sendRedirect(request.getContextPath() + "/student/dashboard");
            return;
        }

        switch (path) {
            case "/update-profile":
//                updateProfile(request, response, student);
                break;
            case "/update-settings":
                updateSettings(request, response, student);
                break;
            case "/submit-assignment":
                submitAssignment(request, response, student);
                break;
            case "/enroll-course":
                enrollCourse(request, response, student);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/student/dashboard");
                break;
        }
    }

//    private void showDashboard(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
//        List<Course> enrolledCourses = enrollmentDAO.getEnrolledCoursesByStudentId(student.getStudentId());
//        List<Test> upcomingTests = testDAO.getUpcomingTestsByStudentId(student.getStudentId());
//        List<Material> recentMaterials = materialDAO.getRecentMaterialsByStudentId(student.getStudentId());
//
//        request.setAttribute("enrolledCourses", enrolledCourses);
//        request.setAttribute("upcomingTests", upcomingTests);
//        request.setAttribute("recentMaterials", recentMaterials);
//
//        request.getRequestDispatcher("/student/dashboard.jsp").forward(request, response);
//    }

    private void showCourses(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        List<Course> enrolledCourses = enrollmentDAO.getEnrolledCoursesByStudentId(student.getStudentId());
        List<Course> availableCourses = courseDAO.getAvailableCoursesForStudent(student.getStudentId());

        request.setAttribute("enrolledCourses", enrolledCourses);
        request.setAttribute("availableCourses", availableCourses);

        request.getRequestDispatcher("/student/courses.jsp").forward(request, response);
    }

    private void showCourseDetails(HttpServletRequest request, HttpServletResponse response, Student student, String path) throws ServletException, IOException, SQLException {
        try {
            int courseId = Integer.parseInt(path.substring(path.lastIndexOf("/") + 1));
            Course course = courseDAO.getCourseById(courseId);

            if (course == null || !enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), courseId)) {
                response.sendRedirect(request.getContextPath() + "/student/courses");
                return;
            }

            List<Material> materials = materialDAO.getMaterialsByCourseId(courseId);
            List<Test> tests = testDAO.getTestsByCourseId(courseId);

            request.setAttribute("course", course);
            request.setAttribute("materials", materials);
            request.setAttribute("tests", tests);

            request.getRequestDispatcher("/student/course-detail.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/student/courses");
        }
    }

//    private void showMaterials(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
//        List<Material> materials = materialDAO.getAllMaterialsForStudent(student.getStudentId());
//        request.setAttribute("materials", materials);
//        request.getRequestDispatcher("/student/materials.jsp").forward(request, response);
//    }

    private void showAssignments(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        request.getRequestDispatcher("/student/assignments.jsp").forward(request, response);
    }

    private void showGrades(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        List<Grade> grades = gradeDAO.getGradesByStudentId(student.getStudentId());
        request.setAttribute("grades", grades);
        request.getRequestDispatcher("/student/grades.jsp").forward(request, response);
    }

    private void showForum(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        request.getRequestDispatcher("/student/forum.jsp").forward(request, response);
    }

    private void showCalendar(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        request.getRequestDispatcher("/student/calendar.jsp").forward(request, response);
    }

    private void showSettings(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        request.getRequestDispatcher("/student/settings.jsp").forward(request, response);
    }

    private void showProfile(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        request.getRequestDispatcher("/student/profile.jsp").forward(request, response);
    }

//    private void updateProfile(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
//        String fullName = request.getParameter("fullName");
//        String email = request.getParameter("email");
//        String phone = request.getParameter("phone");
//        String address = request.getParameter("address");
//
//        student.getUser().setFullName(fullName);
//        student.getUser().setEmail(email);
//        student.setPhone(Integer.parseInt(phone));
//        student.setAddress(address);
//
//        boolean success = studentDAO.updateStudent(student);
//
//        if (success) {
//            request.setAttribute("message", "Profile updated successfully");
//        } else {
//            request.setAttribute("error", "Failed to update profile");
//        }
//
//        showProfile(request, response, student);
//    }

    private void updateSettings(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        String password = request.getParameter("password");
        String newPassword = request.getParameter("newPassword");

        boolean success = studentDAO.updateStudentPassword(student.getStudentId(), password, newPassword);

        if (success) {
            request.setAttribute("message", "Settings updated successfully");
        } else {
            request.setAttribute("error", "Failed to update settings");
        }

        showSettings(request, response, student);
    }

    private void submitAssignment(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        // TODO: Handle file upload + submission saving
        response.sendRedirect(request.getContextPath() + "/student/assignments");
    }

    private void enrollCourse(HttpServletRequest request, HttpServletResponse response, Student student) throws ServletException, IOException {
        String courseIdStr = request.getParameter("courseId");

        try {
            int courseId = Integer.parseInt(courseIdStr);
            boolean success = studentDAO.enrollStudent(student.getUserId(), courseId); // dùng userId, DAO xử lý student_id

            if (success) {
                request.setAttribute("message", "Successfully enrolled in course");
            } else {
                request.setAttribute("error", "Failed to enroll in course");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid course ID");
        }

        showCourses(request, response, student);
    }
}
