package controller;

import dao.StudentDAO;
import dao.CourseDAO;
import dao.AssignmentDAO;
import dao.AnnouncementDAO;
import dao.GradeDAO;
import model.Student;
import model.User;
import model.Course;
import model.Assignment;
import model.Announcement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/student/dashboard")
public class StudentDashboardServlet extends HttpServlet {
    
    private StudentDAO studentDAO;
    private CourseDAO courseDAO;
    private AssignmentDAO assignmentDAO;
    private AnnouncementDAO announcementDAO;
    private GradeDAO gradeDAO;

    @Override
    public void init() throws ServletException {
        studentDAO = new StudentDAO();
        courseDAO = new CourseDAO();
        assignmentDAO = new AssignmentDAO();
        announcementDAO = new AnnouncementDAO();
        gradeDAO = new GradeDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Lấy thông tin sinh viên
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            if (student == null) {
                request.setAttribute("error", "Không tìm thấy thông tin sinh viên!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }

            // Lấy các thống kê dashboard
            Map<String, Object> dashboardStats = studentDAO.getDashboardStats(student.getStudentId());
            
            // Lấy danh sách khóa học đang học
            List<Course> enrolledCourses = courseDAO.getEnrolledCoursesByStudent(student.getStudentId());
            
            // Lấy bài tập sắp tới
            List<Assignment> upcomingAssignments = assignmentDAO.getUpcomingAssignmentsByStudent(student.getStudentId());
            
           
            // Tính GPA
            double gpa = gradeDAO.calculateGPA(student.getStudentId());

            // Set attributes cho JSP
            request.setAttribute("student", student);
            request.setAttribute("dashboardStats", dashboardStats);
            request.setAttribute("enrolledCourses", enrolledCourses);
            request.setAttribute("upcomingAssignments", upcomingAssignments);
            
            request.setAttribute("gpa", gpa);

            request.getRequestDispatcher("/student/dashboard.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Có lỗi xảy ra khi tải dashboard: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}