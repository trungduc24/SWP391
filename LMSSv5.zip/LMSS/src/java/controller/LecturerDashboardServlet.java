package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * LecturerDashboardServlet handles the dashboard view for lecturers.
 * This servlet displays overview information including courses, students,
 * upcoming tests, and recent announcements.
 */
public class LecturerDashboardServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerDashboardServlet.class.getName());
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private TestDAO testDAO;
    private SemesterDAO semesterDAO;
    private AnnouncementDAO announcementDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            testDAO = new TestDAO();
            semesterDAO = new SemesterDAO();
            announcementDAO = new AnnouncementDAO();
            studentDAO = new StudentDAO();
            logger.info("LecturerDashboardServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerDashboardServlet", e);
            throw new ServletException("Failed to initialize LecturerDashboardServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if user is logged in as a lecturer
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !currentUser.getRole().equals("lecturer")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Get lecturer information
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
            
            request.setAttribute("lecturer", lecturer);
            
            // Get courses
            List<Course> myCourses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());
            request.setAttribute("myCourses", myCourses);
            request.setAttribute("recentCourses", myCourses.size() > 5 ? myCourses.subList(0, 5) : myCourses);
            
            // Get semesters
            List<Semester> semesters = semesterDAO.getAllSemesters();
            request.setAttribute("semesters", semesters);
            
            // Get current semester
            Semester currentSemester = semesterDAO.getCurrentSemester();
            request.setAttribute("currentSemester", currentSemester);
            
            // Statistics
            int totalCourses = myCourses.size();
            int activeCourses = (int) myCourses.stream().filter(Course::isActive).count();
            int totalStudents = studentDAO.getStudentCountByLecturerId(lecturer.getLecturerId());
            int totalTests = testDAO.countTestsByLecturerId(lecturer.getLecturerId());
            
            request.setAttribute("totalCourses", totalCourses);
            request.setAttribute("activeCourses", activeCourses);
            request.setAttribute("totalStudents", totalStudents);
            request.setAttribute("totalTests", totalTests);
            
            // Recent announcements
            List<Announcement> recentAnnouncements = announcementDAO.getAnnouncementsByLecturerId(lecturer.getLecturerId());
            // Get only the 5 most recent announcements
            recentAnnouncements = recentAnnouncements.stream()
                .limit(5)
                .collect(java.util.stream.Collectors.toList());
            request.setAttribute("recentAnnouncements", recentAnnouncements);
            
            // Upcoming tests
            List<Test> upcomingTests = testDAO.getUpcomingTestsByLecturerId(lecturer.getLecturerId(), 5);
            request.setAttribute("upcomingTests", upcomingTests);
            
            // Set active navigation item
            request.setAttribute("activeSection", "dashboard");
            
            // Forward to dashboard JSP
            request.getRequestDispatcher("/lecturer/dashboard.jsp").forward(request, response);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerDashboardServlet", e);
            throw new ServletException("Database error", e);
        }
    }
}
