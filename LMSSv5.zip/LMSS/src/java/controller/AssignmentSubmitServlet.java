package controller;

import dao.AssignmentDAO;
import dao.SubmissionDAO;
import dao.StudentDAO;
import dao.EnrollmentDAO;
import model.Assignment;
import model.Submission;
import model.Student;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/assignment-submit")
public class AssignmentSubmitServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(AssignmentSubmitServlet.class.getName());
    
    private AssignmentDAO assignmentDAO;
    private SubmissionDAO submissionDAO;
    private StudentDAO studentDAO;
    private EnrollmentDAO enrollmentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            assignmentDAO = new AssignmentDAO();
            submissionDAO = new SubmissionDAO();
            studentDAO = new StudentDAO();
            enrollmentDAO = new EnrollmentDAO();
            logger.info("AssignmentSubmitServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize AssignmentSubmitServlet", e);
            throw new ServletException("Failed to initialize AssignmentSubmitServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String assignmentIdStr = request.getParameter("assignmentId");
        if (assignmentIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            int assignmentId = Integer.parseInt(assignmentIdStr);
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            
            if (assignment == null) {
                session.setAttribute("error", "Bài tập không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), assignment.getCourseId())) {
                session.setAttribute("error", "Bạn không có quyền truy cập bài tập này");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Lấy submission hiện tại nếu có
            Submission existingSubmission = submissionDAO.getSubmissionByStudentAndAssignment(
                student.getStudentId(), assignmentId);
            
            request.setAttribute("assignment", assignment);
            request.setAttribute("submission", existingSubmission);
            request.setAttribute("student", student);
            request.getRequestDispatcher("/student/assignment-submit.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "ID bài tập không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AssignmentSubmitServlet", e);
            session.setAttribute("error", "Lỗi cơ sở dữ liệu");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in AssignmentSubmitServlet", e);
            session.setAttribute("error", "Đã xảy ra lỗi");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String assignmentIdStr = request.getParameter("assignmentId");
        String submissionText = request.getParameter("submissionText");
        String fileUrl = request.getParameter("fileUrl");
        
        if (assignmentIdStr == null) {
            session.setAttribute("error", "ID bài tập không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
            return;
        }
        
        try {
            int assignmentId = Integer.parseInt(assignmentIdStr);
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            
            if (assignment == null) {
                session.setAttribute("error", "Bài tập không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), assignment.getCourseId())) {
                session.setAttribute("error", "Bạn không có quyền truy cập bài tập này");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
                return;
            }
            
            // Validate dữ liệu
            if ((submissionText == null || submissionText.trim().isEmpty()) && 
                (fileUrl == null || fileUrl.trim().isEmpty())) {
                session.setAttribute("error", "Vui lòng nhập nội dung bài làm hoặc đính kèm link file");
                response.sendRedirect(request.getContextPath() + "/student/assignment-submit?assignmentId=" + assignmentId);
                return;
            }
            
            // Tạo submission
            Submission submission = new Submission();
            submission.setAssignmentId(assignmentId);
            submission.setStudentId(student.getStudentId());
            submission.setSubmissionText(submissionText);
            submission.setFileUrl(fileUrl);
            submission.setStatus("submitted");
            
            boolean success = submissionDAO.submitAssignment(submission);
            
            if (success) {
                session.setAttribute("success", "Nộp bài tập thành công!");
                response.sendRedirect(request.getContextPath() + "/student/assignments");
            } else {
                session.setAttribute("error", "Nộp bài tập thất bại. Vui lòng thử lại.");
                response.sendRedirect(request.getContextPath() + "/student/assignment-submit?assignmentId=" + assignmentId);
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "ID bài tập không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in AssignmentSubmitServlet", e);
            session.setAttribute("error", "Lỗi cơ sở dữ liệu");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in AssignmentSubmitServlet", e);
            session.setAttribute("error", "Đã xảy ra lỗi khi nộp bài tập");
            response.sendRedirect(request.getContextPath() + "/student/assignments");
        }
    }
}