package controller;

import dao.NotificationDAO;
import model.Notification;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/student/notifications")
public class NotificationServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null || !"student".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        try {
            NotificationDAO notificationDAO = new NotificationDAO();
            
            // Lấy danh sách thông báo
            List<Notification> notifications = notificationDAO.getNotificationsByUserId(currentUser.getUserId());
            
            // Lấy số lượng thông báo chưa đọc
            int unreadCount = notificationDAO.getUnreadNotificationCount(currentUser.getUserId());
            
            request.setAttribute("notifications", notifications);
            request.setAttribute("unreadCount", unreadCount);
            request.setAttribute("currentUser", currentUser);
            
            request.getRequestDispatcher("/student/notifications.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null || !"student".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        NotificationDAO notificationDAO = new NotificationDAO();
        
        try {
            if ("mark-read".equals(action)) {
                int notificationId = Integer.parseInt(request.getParameter("notificationId"));
                notificationDAO.markNotificationAsRead(notificationId);
                response.getWriter().write("success");
            } else if ("mark-all-read".equals(action)) {
                notificationDAO.markAllNotificationsAsRead(currentUser.getUserId());
                response.getWriter().write("success");
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
        }
    }
}