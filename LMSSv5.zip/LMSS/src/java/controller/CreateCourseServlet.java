package controller;

import dao.CourseDAO;
import dao.LecturerDAO;
import dao.SemesterDAO;
import model.Course;
import model.User;
import model.Lecturer;
import model.Semester;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class CreateCourseServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(CreateCourseServlet.class.getName());
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            semesterDAO = new SemesterDAO();
            logger.info("CreateCourseServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize CreateCourseServlet", e);
            throw new ServletException("Failed to initialize CreateCourseServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền (lecturer hoặc admin)
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null ||
                (!"lecturer".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole()))) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ giảng viên và admin mới có quyền tạo khóa học!");
            return;
        }

        try {
            // Lấy danh sách giảng viên để hiển thị trong form
            List<Lecturer> lecturers = lecturerDAO.getAllLecturers();
            req.setAttribute("lecturers", lecturers);

            // Lấy danh sách học kỳ đang hoạt động
            List<Semester> semesters = semesterDAO.getActiveSemesters();
            req.setAttribute("semesters", semesters);

            // Forward đến trang tạo khóa học dựa theo role
            if ("admin".equals(currentUser.getRole())) {
                req.getRequestDispatcher("/admin/create-course.jsp").forward(req, resp);
            } else {
                req.getRequestDispatcher("/lecturer/create-course.jsp").forward(req, resp);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while loading create course form", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi cơ sở dữ liệu!");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền (lecturer hoặc admin)
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null ||
                (!"lecturer".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole()))) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ giảng viên và admin mới có quyền tạo khóa học!");
            return;
        }

        String name = req.getParameter("name");
        String code = req.getParameter("code");
        String description = req.getParameter("description");
        String room = req.getParameter("room");
        String lecturerIdStr = req.getParameter("lecturerId");
        String semesterIdStr = req.getParameter("semesterId");
        String totalSessionsStr = req.getParameter("totalSessions");
        String creditsStr = req.getParameter("credits");
        String maxStudentsStr = req.getParameter("maxStudents");

        // Validate input
        if (name == null || name.trim().isEmpty() ||
                code == null || code.trim().isEmpty() ||
                lecturerIdStr == null || lecturerIdStr.trim().isEmpty() ||
                semesterIdStr == null || semesterIdStr.trim().isEmpty()) {

            req.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            doGet(req, resp);
            return;
        }

        try {
            int lecturerId = Integer.parseInt(lecturerIdStr);
            int semesterId = Integer.parseInt(semesterIdStr);
            int totalSessions = totalSessionsStr != null && !totalSessionsStr.trim().isEmpty()
                    ? Integer.parseInt(totalSessionsStr)
                    : 15;
            int credits = creditsStr != null && !creditsStr.trim().isEmpty() ? Integer.parseInt(creditsStr) : 3;
            int maxStudents = maxStudentsStr != null && !maxStudentsStr.trim().isEmpty()
                    ? Integer.parseInt(maxStudentsStr)
                    : 50;

            // Kiểm tra mã khóa học đã tồn tại chưa
            if (courseDAO.getCourseByCode(code) != null) {
                req.setAttribute("error", "Mã khóa học đã tồn tại!");
                doGet(req, resp);
                return;
            }

            // Tạo khóa học mới
            Course course = new Course(name, code, description, room, lecturerId, semesterId,
                    totalSessions, credits, maxStudents);

            boolean success = createCourse(course);

            if (success) {
                // Log hoạt động tạo khóa học
                logCourseCreation(currentUser.getUserId(), name, code,
                        getClientIP(req), req.getHeader("User-Agent"));

                logger.info("Course created successfully by user: " + currentUser.getUsername() +
                        " - Course: " + name + " (" + code + ")");

                // Redirect để tránh duplicate submission
                if ("lecturer".equals(currentUser.getRole())) {
                    resp.sendRedirect(req.getContextPath() + "/lecturer/courses.jsp?created=success");
                } else {
                    resp.sendRedirect(req.getContextPath() + "/courses?created=success");
                }
                return;
            } else {
                req.setAttribute("error", "Không thể tạo khóa học!");
            }

        } catch (NumberFormatException e) {
            req.setAttribute("error", "Dữ liệu số không hợp lệ!");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while creating course", e);
            req.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error while creating course", e);
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
        }

        // Forward về trang tạo khóa học với thông báo lỗi
        doGet(req, resp);
    }

    /**
     * Tạo khóa học mới
     */
    private boolean createCourse(Course course) throws SQLException {
        try {
            courseDAO.addCourse(course);
            return true;
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to create course", e);
            return false;
        }
    }

    /**
     * Ghi log tạo khóa học
     */
    private void logCourseCreation(int userId, String courseName, String courseCode, String ip, String userAgent) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO system_logs (user_id, action, table_name, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                stmt.setString(2, "CREATE_COURSE");
                stmt.setString(3, "courses");
                stmt.setString(4, "Created course: " + courseName + " (" + courseCode + ")");
                stmt.setString(5, ip);
                stmt.setString(6, userAgent);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to log course creation", e);
        }
    }

    /**
     * Lấy IP của client
     */
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }

        String xRealIP = request.getHeader("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }

        return request.getRemoteAddr();
    }
}
