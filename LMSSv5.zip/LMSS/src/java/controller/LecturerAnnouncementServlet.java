package controller;

import dao.*;
import model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
public class LecturerAnnouncementServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LecturerAnnouncementServlet.class.getName());
    private AnnouncementDAO announcementDAO;
    private CourseDAO courseDAO;
    private LecturerDAO lecturerDAO;

    @Override
    public void init() throws ServletException {
        try {
            announcementDAO = new AnnouncementDAO();
            courseDAO = new CourseDAO();
            lecturerDAO = new LecturerDAO();
            logger.info("LecturerAnnouncementServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize LecturerAnnouncementServlet", e);
            throw new ServletException("Failed to initialize LecturerAnnouncementServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"lecturer".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String servletPath = request.getServletPath();
        String pathInfo = request.getPathInfo();

        try {
            Lecturer lecturer = lecturerDAO.getLecturerByUserId(currentUser.getUserId());
            if (lecturer == null) {
                logger.warning("Lecturer not found for user ID: " + currentUser.getUserId());
                session.setAttribute("error", "Lecturer information not found.");
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }

            request.setAttribute("lecturer", lecturer);

            if ("/lecturer/announcements/create".equals(servletPath)) {
                showCreateAnnouncementForm(request, response);
            } else if ("/lecturer/announcements".equals(servletPath) && pathInfo == null) {
                showAllAnnouncements(request, response);
            } else if ("/lecturer/announcements".equals(servletPath) && pathInfo != null) {
                if (pathInfo.startsWith("/view/")) {
                    int announcementId = Integer.parseInt(pathInfo.substring(6));
                    viewAnnouncement(request, response, announcementId, currentUser);
                } else if (pathInfo.startsWith("/delete/")) {
                    int announcementId = Integer.parseInt(pathInfo.substring(8));
                    deleteAnnouncement(request, response, announcementId, currentUser);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid announcement ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerAnnouncementServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"lecturer".equals(currentUser.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        try {
            if ("create-announcement".equals(action)) {
                createAnnouncement(request, response, currentUser);
            } else if ("delete-announcement".equals(action)) {
                int announcementId = Integer.parseInt(request.getParameter("announcementId"));
                deleteAnnouncement(request, response, announcementId, currentUser);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid announcement ID format", e);
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in LecturerAnnouncementServlet", e);
            throw new ServletException("Database error", e);
        }
    }

    private void showAllAnnouncements(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        List<Announcement> announcements = announcementDAO.getAnnouncementsByLecturerId(lecturer.getLecturerId());
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());

        request.setAttribute("announcements", announcements);
        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "announcements");

        request.getRequestDispatcher("/lecturer/announcements.jsp").forward(request, response);
    }

    private void showCreateAnnouncementForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        List<Course> courses = courseDAO.getCoursesByLecturerId(lecturer.getLecturerId());

        request.setAttribute("courses", courses);
        request.setAttribute("activeSection", "announcements");

        request.getRequestDispatcher("/lecturer/create-announcement.jsp").forward(request, response);
    }

    private void viewAnnouncement(HttpServletRequest request, HttpServletResponse response, int announcementId, User currentUser)
            throws ServletException, IOException, SQLException {

        Announcement announcement = announcementDAO.getAnnouncementById(announcementId);

        if (announcement == null || announcement.getCreatedBy() != currentUser.getUserId()) {
            request.getSession().setAttribute("error", "You don't have permission to view this announcement.");
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
            return;
        }

        Course course = courseDAO.getCourseById(announcement.getCourseId());

        request.setAttribute("announcement", announcement);
        request.setAttribute("course", course);
        request.setAttribute("activeSection", "announcements");

        request.getRequestDispatcher("/lecturer/view-announcement.jsp").forward(request, response);
    }

    private void createAnnouncement(HttpServletRequest request, HttpServletResponse response, User currentUser)
            throws ServletException, IOException, SQLException {

        Lecturer lecturer = (Lecturer) request.getAttribute("lecturer");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        boolean isImportant = "on".equals(request.getParameter("isImportant"));

        Course course = courseDAO.getCourseById(courseId);
        if (course.getLecturerId() != lecturer.getLecturerId()) {
            request.getSession().setAttribute("error", "You don't have permission to create announcements for this course.");
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
            return;
        }

        Announcement announcement = new Announcement();
        announcement.setTitle(title);
        announcement.setContent(content);
        announcement.setCourseId(courseId);
        announcement.setCreatedBy(currentUser.getUserId());
        announcement.setCreatedAt(new Timestamp(new Date().getTime()));
        announcement.setImportant(isImportant);

        int announcementId = announcementDAO.addAnnouncement(announcement);

        if (announcementId > 0) {
            request.getSession().setAttribute("success", "Announcement created successfully.");
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements/view/" + announcementId);
        } else {
            request.getSession().setAttribute("error", "Failed to create announcement.");
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements/create");
        }
    }

    private void deleteAnnouncement(HttpServletRequest request, HttpServletResponse response, int announcementId, User currentUser)
            throws ServletException, IOException, SQLException {

        Announcement announcement = announcementDAO.getAnnouncementById(announcementId);

        if (announcement == null || announcement.getCreatedBy() != currentUser.getUserId()) {
            request.getSession().setAttribute("error", "You don't have permission to delete this announcement.");
            response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
            return;
        }

        boolean success = announcementDAO.deleteAnnouncement(announcementId);

        if (success) {
            request.getSession().setAttribute("success", "Announcement deleted successfully.");
        } else {
            request.getSession().setAttribute("error", "Failed to delete announcement.");
        }

        response.sendRedirect(request.getContextPath() + "/lecturer/announcements");
    }
}
