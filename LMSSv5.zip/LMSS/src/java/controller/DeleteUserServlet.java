package controller;

import dao.UsersDAO;
import model.User;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.logging.Logger;
import java.util.logging.Level;

public class DeleteUserServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(DeleteUserServlet.class.getName());
    private UsersDAO userDAO;

    @Override
    public void init() throws ServletException {
        logger.info("DeleteUserServlet initialized successfully");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("DeleteUserServlet.doPost() called");

        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        logger.info("Current user: " + (currentUser != null ? currentUser.getUsername() : "null"));

        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            logger.warning("Access denied - user is not admin");
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền xóa người dùng!");
            return;
        }

        String userIdStr = req.getParameter("userId");
        logger.info("User ID to delete: " + userIdStr);

        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            logger.warning("Invalid user ID parameter");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID người dùng không hợp lệ!");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);
            logger.info("Parsed user ID: " + userId);

            // Tạo connection và DAO mới cho request này
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot get database connection");
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi kết nối cơ sở dữ liệu!");
                return;
            }
            userDAO = new UsersDAO(conn);
            logger.info("Created new database connection and DAO");

            // Không cho phép xóa chính mình
            if (userId == currentUser.getUserId()) {
                logger.warning("User trying to delete themselves");
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Không thể xóa tài khoản của chính mình!");
                return;
            }

            // Kiểm tra user tồn tại
            logger.info("Checking if user exists...");
            User userToDelete = userDAO.getUserById(userId);
            logger.info("User to delete: " + (userToDelete != null ? userToDelete.getUsername() : "null"));

            if (userToDelete == null) {
                logger.warning("User not found");
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy người dùng!");
                return;
            }

            // Kiểm tra ràng buộc dữ liệu trước khi xóa
            logger.info("Checking data constraints...");
            if (hasDataConstraints(userId)) {
                logger.warning("User has data constraints, cannot delete");
                resp.sendError(HttpServletResponse.SC_CONFLICT,
                        "Không thể xóa người dùng này vì có dữ liệu liên quan. Vui lòng xóa dữ liệu liên quan trước!");
                return;
            }
            logger.info("No data constraints found, proceeding with delete...");

            // Thực hiện xóa user
            boolean success = deleteUser(userId);

            if (success) {
                // Log hoạt động xóa user
                logUserDeletion(currentUser.getUserId(), userId, userToDelete.getUsername(),
                        getClientIP(req), req.getHeader("User-Agent"));

                logger.info("User deleted successfully by admin: " + currentUser.getUsername() +
                        " - Deleted user: " + userToDelete.getUsername() + " (ID: " + userId + ")");

                // Trả về JSON response cho AJAX
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write("{\"success\": true, \"message\": \"Xóa người dùng thành công!\"}");
            } else {
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write("{\"success\": false, \"message\": \"Không thể xóa người dùng!\"}");
            }

        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID người dùng không hợp lệ!");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error while deleting user", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().write("{\"success\": false, \"message\": \"Lỗi cơ sở dữ liệu: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "System error while deleting user", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().write("{\"success\": false, \"message\": \"Lỗi hệ thống: " + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Chuyển hướng GET requests thành POST để bảo mật
        resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "Phương thức GET không được hỗ trợ cho việc xóa!");
    }

    /**
     * Kiểm tra ràng buộc dữ liệu trước khi xóa
     */
    private boolean hasDataConstraints(int userId) throws SQLException {
        logger.info("hasDataConstraints() called for user ID: " + userId);
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                logger.severe("Cannot get database connection in hasDataConstraints");
                throw new SQLException("Cannot get database connection");
            }
            logger.info("Got database connection in hasDataConstraints");

            // Kiểm tra các bảng có liên quan đến user
            String[] checkQueries = {
                    "SELECT COUNT(*) FROM enrollments e INNER JOIN students s ON e.student_id = s.student_id WHERE s.user_id = ?",
                    "SELECT COUNT(*) FROM courses WHERE lecturer_id IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM assignments WHERE created_by IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM tests WHERE created_by IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM grades WHERE graded_by IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM announcements WHERE created_by IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM forums WHERE created_by IN (SELECT lecturer_id FROM lecturers WHERE user_id = ?)",
                    "SELECT COUNT(*) FROM forum_posts WHERE user_id = ?"
            };

            for (String query : checkQueries) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, userId);
                    try (var rs = stmt.executeQuery()) {
                        if (rs.next() && rs.getInt(1) > 0) {
                            return true; // Có dữ liệu liên quan
                        }
                    }
                }
            }

            return false; // Không có dữ liệu liên quan
        }
    }

    /**
     * Xóa user và tất cả dữ liệu liên quan
     */
    private boolean deleteUser(int userId) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try {
                // Xóa theo thứ tự để tránh vi phạm foreign key

                // 1. Xóa dữ liệu trong system_logs
                executeDelete(conn, "DELETE FROM system_logs WHERE user_id = ?", userId);

                // 2. Xóa dữ liệu trong password_resets
                executeDelete(conn, "DELETE FROM password_resets WHERE user_id = ?", userId);

                // 3. Xóa từ bảng role-specific (students, lecturers, admins)
                executeDelete(conn, "DELETE FROM students WHERE user_id = ?", userId);
                executeDelete(conn, "DELETE FROM lecturers WHERE user_id = ?", userId);
                executeDelete(conn, "DELETE FROM admins WHERE user_id = ?", userId);

                // 4. Cuối cùng xóa từ bảng users (CASCADE sẽ xử lý các bảng khác)
                int deletedRows = executeDelete(conn, "DELETE FROM users WHERE user_id = ?", userId);

                if (deletedRows > 0) {
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    /**
     * Thực hiện câu lệnh DELETE
     */
    private int executeDelete(Connection conn, String sql, int userId) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            return stmt.executeUpdate();
        }
    }

    /**
     * Ghi log xóa user
     */
    private void logUserDeletion(int adminId, int deletedUserId, String deletedUsername, String ip, String userAgent) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO system_logs (user_id, action, table_name, record_id, old_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, adminId);
                stmt.setString(2, "DELETE_USER");
                stmt.setString(3, "users");
                stmt.setInt(4, deletedUserId);
                stmt.setString(5, "Deleted user: " + deletedUsername + " (ID: " + deletedUserId + ")");
                stmt.setString(6, ip);
                stmt.setString(7, userAgent);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Failed to log user deletion", e);
        }
    }

    /**
     * Lấy IP của client
     */
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }

        String xRealIP = request.getHeader("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }

        return request.getRemoteAddr();
    }
}
