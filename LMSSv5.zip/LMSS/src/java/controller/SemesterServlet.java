package controller;

import dao.SemesterDAO;
import model.Semester;
import model.User;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class SemesterServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(SemesterServlet.class.getName());
    private SemesterDAO semesterDAO;

    @Override
    public void init() throws ServletException {
        logger.info("SemesterServlet initialized successfully");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền quản lý học kỳ!");
            return;
        }

        String action = req.getParameter("action");
        if (action == null)
            action = "list";

        try {
            // Tạo connection và DAO mới cho request này
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot get database connection");
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi kết nối cơ sở dữ liệu!");
                return;
            }
            semesterDAO = new SemesterDAO();

            switch (action) {
                case "list":
                    listSemesters(req, resp);
                    break;
                case "edit":
                    showEditForm(req, resp);
                    break;
                default:
                    listSemesters(req, resp);
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in SemesterServlet", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi cơ sở dữ liệu!");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra quyền admin
        HttpSession session = req.getSession();
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ admin mới có quyền quản lý học kỳ!");
            return;
        }

        String action = req.getParameter("action");
        if (action == null)
            action = "create";

        try {
            // Tạo connection và DAO mới cho request này
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot get database connection");
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi kết nối cơ sở dữ liệu!");
                return;
            }
            semesterDAO = new SemesterDAO();

            switch (action) {
                case "create":
                    createSemester(req, resp);
                    break;
                case "update":
                    updateSemester(req, resp);
                    break;
                case "delete":
                    deleteSemester(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Hành động không hợp lệ!");
                    break;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in SemesterServlet", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi cơ sở dữ liệu!");
        }
    }

    private void listSemesters(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        List<Semester> semesters = semesterDAO.getAllSemesters();
        req.setAttribute("semesters", semesters);
        req.getRequestDispatcher("/admin/semesters-new.jsp").forward(req, resp);
    }

    private void showEditForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        String semesterIdStr = req.getParameter("id");
        if (semesterIdStr == null || semesterIdStr.trim().isEmpty()) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID học kỳ không hợp lệ!");
            return;
        }

        try {
            int semesterId = Integer.parseInt(semesterIdStr);
            Semester semester = semesterDAO.getSemesterById(semesterId);
            if (semester == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy học kỳ!");
                return;
            }

            req.setAttribute("semesterToEdit", semester);
            req.getRequestDispatcher("/admin/edit-semester.jsp").forward(req, resp);
        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID học kỳ không hợp lệ!");
        }
    }

    private void createSemester(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        String name = req.getParameter("name");
        String code = req.getParameter("code");
        String startDateStr = req.getParameter("startDate");
        String endDateStr = req.getParameter("endDate");
        String isActiveStr = req.getParameter("isActive");

        // Validate input
        if (name == null || name.trim().isEmpty() ||
                code == null || code.trim().isEmpty() ||
                startDateStr == null || startDateStr.trim().isEmpty() ||
                endDateStr == null || endDateStr.trim().isEmpty()) {

            req.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            listSemesters(req, resp);
            return;
        }

        try {
            LocalDate startDate = LocalDate.parse(startDateStr);
            LocalDate endDate = LocalDate.parse(endDateStr);
            boolean isActive = "on".equals(isActiveStr) || "true".equals(isActiveStr);

            // Validate dates
            if (endDate.isBefore(startDate)) {
                req.setAttribute("error", "Ngày kết thúc phải sau ngày bắt đầu!");
                listSemesters(req, resp);
                return;
            }

            // Check if code already exists
            if (semesterDAO.getSemesterByCode(code) != null) {
                req.setAttribute("error", "Mã học kỳ đã tồn tại!");
                listSemesters(req, resp);
                return;
            }

            Semester semester = new Semester(name, code, java.sql.Date.valueOf(startDate),
                    java.sql.Date.valueOf(endDate), isActive);
            boolean success = semesterDAO.addSemester(semester);

            if (success) {
                // Log action
                logAction(req, "CREATE_SEMESTER", "semesters", null,
                        "Created semester: " + name + " (" + code + ")");

                req.setAttribute("success", "Tạo học kỳ thành công!");
            } else {
                req.setAttribute("error", "Không thể tạo học kỳ!");
            }

        } catch (Exception e) {
            logger.log(Level.WARNING, "Error creating semester", e);
            req.setAttribute("error", "Lỗi khi tạo học kỳ: " + e.getMessage());
        }

        listSemesters(req, resp);
    }

    private void updateSemester(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        String semesterIdStr = req.getParameter("semesterId");
        String name = req.getParameter("name");
        String code = req.getParameter("code");
        String startDateStr = req.getParameter("startDate");
        String endDateStr = req.getParameter("endDate");
        String isActiveStr = req.getParameter("isActive");

        // Validate input
        if (semesterIdStr == null || semesterIdStr.trim().isEmpty() ||
                name == null || name.trim().isEmpty() ||
                code == null || code.trim().isEmpty() ||
                startDateStr == null || startDateStr.trim().isEmpty() ||
                endDateStr == null || endDateStr.trim().isEmpty()) {

            req.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            listSemesters(req, resp);
            return;
        }

        try {
            int semesterId = Integer.parseInt(semesterIdStr);
            LocalDate startDate = LocalDate.parse(startDateStr);
            LocalDate endDate = LocalDate.parse(endDateStr);
            boolean isActive = "on".equals(isActiveStr) || "true".equals(isActiveStr);

            // Validate dates
            if (endDate.isBefore(startDate)) {
                req.setAttribute("error", "Ngày kết thúc phải sau ngày bắt đầu!");
                listSemesters(req, resp);
                return;
            }

            // Get existing semester
            Semester existingSemester = semesterDAO.getSemesterById(semesterId);
            if (existingSemester == null) {
                req.setAttribute("error", "Không tìm thấy học kỳ!");
                listSemesters(req, resp);
                return;
            }

            // Check if code already exists (except current semester)
            Semester semesterWithCode = semesterDAO.getSemesterByCode(code);
            if (semesterWithCode != null && semesterWithCode.getSemesterId() != semesterId) {
                req.setAttribute("error", "Mã học kỳ đã tồn tại!");
                listSemesters(req, resp);
                return;
            }

            Semester semester = new Semester(semesterId, name, code, java.sql.Date.valueOf(startDate),
                    java.sql.Date.valueOf(endDate), isActive, null);
            boolean success = semesterDAO.updateSemester(semester);

            if (success) {
                // Log action
                logAction(req, "UPDATE_SEMESTER", "semesters", semesterId,
                        "Updated semester: " + name + " (" + code + ")");

                req.setAttribute("success", "Cập nhật học kỳ thành công!");
            } else {
                req.setAttribute("error", "Không thể cập nhật học kỳ!");
            }

        } catch (Exception e) {
            logger.log(Level.WARNING, "Error updating semester", e);
            req.setAttribute("error", "Lỗi khi cập nhật học kỳ: " + e.getMessage());
        }

        listSemesters(req, resp);
    }

    private void deleteSemester(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        String semesterIdStr = req.getParameter("semesterId");
        if (semesterIdStr == null || semesterIdStr.trim().isEmpty()) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID học kỳ không hợp lệ!");
            return;
        }

        try {
            int semesterId = Integer.parseInt(semesterIdStr);

            // Get semester info for logging
            Semester semester = semesterDAO.getSemesterById(semesterId);
            if (semester == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy học kỳ!");
                return;
            }

            boolean success = semesterDAO.deleteSemester(semesterId);

            if (success) {
                // Log action
                logAction(req, "DELETE_SEMESTER", "semesters", semesterId,
                        "Deleted semester: " + semester.getName() + " (" + semester.getCode() + ")");

                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write("{\"success\": true, \"message\": \"Xóa học kỳ thành công!\"}");
            } else {
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write("{\"success\": false, \"message\": \"Không thể xóa học kỳ!\"}");
            }

        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID học kỳ không hợp lệ!");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deleting semester", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().write("{\"success\": false, \"message\": \"Lỗi hệ thống: " + e.getMessage() + "\"}");
        }
    }

    private void logAction(HttpServletRequest req, String action, String tableName, Integer recordId,
            String description) {
        try (Connection conn = DBConnection.getConnection()) {
            HttpSession session = req.getSession();
            User currentUser = (User) session.getAttribute("user");

            String sql = "INSERT INTO system_logs (user_id, action, table_name, record_id, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, currentUser.getUserId());
                stmt.setString(2, action);
                stmt.setString(3, tableName);
                if (recordId != null) {
                    stmt.setInt(4, recordId);
                } else {
                    stmt.setNull(4, java.sql.Types.INTEGER);
                }
                stmt.setString(5, description);
                stmt.setString(6, getClientIP(req));
                stmt.setString(7, req.getHeader("User-Agent"));
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Could not log action: " + action, e);
        }
    }

    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
