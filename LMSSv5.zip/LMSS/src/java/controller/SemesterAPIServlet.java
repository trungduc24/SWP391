package controller;

import dao.SemesterDAO;
import model.Semester;
import utils.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SemesterAPIServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(SemesterAPIServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        
        try {
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot get database connection");
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                resp.getWriter().write("{\"error\": \"Database connection failed\"}");
                return;
            }
            
            SemesterDAO semesterDAO = new SemesterDAO();
            List<Semester> semesters = semesterDAO.getActiveSemesters();
            
            Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd")
                .create();
            
            String json = gson.toJson(semesters);
            resp.getWriter().write(json);
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in SemesterAPIServlet", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\": \"Database error: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Unexpected error in SemesterAPIServlet", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\": \"Unexpected error: " + e.getMessage() + "\"}");
        }
    }
}
