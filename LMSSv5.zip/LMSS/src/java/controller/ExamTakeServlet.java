package controller;

import dao.*;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/student/exam-take")
public class ExamTakeServlet extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(ExamTakeServlet.class.getName());
    
    private TestDAO testDAO;
    private TestQuestionDAO questionDAO;
    private TestSubmissionDAO submissionDAO;
    private StudentDAO studentDAO;
    private EnrollmentDAO enrollmentDAO;
    
    @Override
    public void init() throws ServletException {
        try {
            testDAO = new TestDAO();
            questionDAO = new TestQuestionDAO();
            submissionDAO = new TestSubmissionDAO();
            studentDAO = new StudentDAO();
            enrollmentDAO = new EnrollmentDAO();
            logger.info("ExamTakeServlet initialized successfully");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to initialize ExamTakeServlet", e);
            throw new ServletException("Failed to initialize ExamTakeServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String testIdStr = request.getParameter("id");
        if (testIdStr == null) {
            session.setAttribute("error", "Không tìm thấy bài kiểm tra");
            response.sendRedirect(request.getContextPath() + "/student/courses");
            return;
        }
        
        try {
            Student student = studentDAO.getStudentByUserId(user.getUserId());
            int testId = Integer.parseInt(testIdStr);
            
            // Lấy thông tin bài test
            Test test = testDAO.getTestById(testId);
            if (test == null) {
                session.setAttribute("error", "Bài kiểm tra không tồn tại");
                response.sendRedirect(request.getContextPath() + "/student/courses");
                return;
            }
            
            // Kiểm tra quyền truy cập
            if (!enrollmentDAO.isStudentEnrolledInCourse(student.getStudentId(), test.getCourseId())) {
                session.setAttribute("error", "Bạn không có quyền truy cập bài kiểm tra này");
                response.sendRedirect(request.getContextPath() + "/student/courses");
                return;
            }
            
            // Kiểm tra thời gian làm bài
            Date now = new Date();
            if (test.getStartTime() != null && now.before(test.getStartTime())) {
                session.setAttribute("error", "Bài kiểm tra chưa bắt đầu");
                response.sendRedirect(request.getContextPath() + "/student/course-detail?id=" + test.getCourseId());
                return;
            }
            
            if (test.getEndTime() != null && now.after(test.getEndTime())) {
                session.setAttribute("error", "Bài kiểm tra đã kết thúc");
                response.sendRedirect(request.getContextPath() + "/student/course-detail?id=" + test.getCourseId());
                return;
            }
            
            // Kiểm tra đã có submission chưa
            TestSubmission submission = submissionDAO.getSubmissionByTestAndStudent(testId, student.getStudentId());
            
            if (submission != null && submission.isSubmitted()) {
                // Đã nộp bài rồi, chuyển đến trang kết quả
                response.sendRedirect(request.getContextPath() + "/student/exam-result?testId=" + testId);
                return;
            }
            
            // Nếu chưa có submission, tạo mới
            if (submission == null) {
                int submissionId = submissionDAO.startTestSubmission(testId, student.getStudentId());
                submission = submissionDAO.getSubmissionById(submissionId);
            }
            
            // Lấy câu hỏi và câu trả lời đã có
            List<TestQuestion> questions = questionDAO.getQuestionsByTestId(testId);
            List<TestAnswer> answers = submissionDAO.getAnswersBySubmission(submission.getTestSubmissionId());
            
            // Set attributes
            request.setAttribute("test", test);
            request.setAttribute("submission", submission);
            request.setAttribute("questions", questions);
            request.setAttribute("answers", answers);
            request.setAttribute("student", student);
            request.setAttribute("currentUser", user);
            
            // Forward to exam-take.jsp
            request.getRequestDispatcher("/student/exam-take.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Invalid test ID: " + testIdStr, e);
            session.setAttribute("error", "ID bài kiểm tra không hợp lệ");
            response.sendRedirect(request.getContextPath() + "/student/courses");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database error in ExamTakeServlet", e);
            session.setAttribute("error", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/courses");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in ExamTakeServlet", e);
            session.setAttribute("error", "Đã xảy ra lỗi: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/student/courses");
        }
    }
}