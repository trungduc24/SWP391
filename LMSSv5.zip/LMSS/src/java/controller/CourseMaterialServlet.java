package controller;

import dao.CourseMaterialDAO;
import model.CourseMaterial;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.annotation.WebServlet; // Đảm bảo có import này

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


public class CourseMaterialServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private CourseMaterialDAO materialDAO;

    @Override
    public void init() {
        materialDAO = new CourseMaterialDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        int courseId = 0; // Để biết tài liệu thuộc khóa học nào

        try {
            // Lấy courseId từ request (bắt buộc khi quản lý tài liệu)
            if (request.getParameter("courseId") != null && !request.getParameter("courseId").isEmpty()) {
                courseId = Integer.parseInt(request.getParameter("courseId"));
            } else {
                // Nếu không có courseId, không thể hiển thị tài liệu
                throw new IllegalArgumentException("Course ID là bắt buộc để xem tài liệu.");
            }

            switch (action != null ? action : "list") { // Xử lý trường hợp action là null
                case "new":
                    showNewMaterialForm(request, response, courseId);
                    break;
                case "edit":
                    showEditMaterialForm(request, response, courseId);
                    break;
                case "delete":
                    deleteCourseMaterial(request, response, courseId);
                    break;
                case "list":
                default:
                    listCourseMaterials(request, response, courseId);
                    break;
            }
        } catch (NumberFormatException e) {
            HttpSession session = request.getSession();
            session.setAttribute("message", "Lỗi: ID khóa học hoặc ID tài liệu không hợp lệ.");
            session.setAttribute("messageType", "error");
            response.sendRedirect("courses?action=list"); // Chuyển về danh sách khóa học nếu ID không hợp lệ
        } catch (IllegalArgumentException e) {
            HttpSession session = request.getSession();
            session.setAttribute("message", "Lỗi: " + e.getMessage());
            session.setAttribute("messageType", "error");
            response.sendRedirect("courses?action=list");
        } catch (SQLException ex) {
            throw new ServletException("Lỗi cơ sở dữ liệu trong CourseMaterialServlet (doGet): " + ex.getMessage(), ex);
        } catch (Exception ex) {
            throw new ServletException("Đã xảy ra lỗi không mong muốn trong doGet của CourseMaterialServlet: " + ex.getMessage(), ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action"); // Thường là "insert" hoặc "update"
        HttpSession session = request.getSession();

        // Lấy courseId từ form
        int courseId = 0;
        try {
            courseId = Integer.parseInt(request.getParameter("courseId"));
        } catch (NumberFormatException e) {
            session.setAttribute("message", "Lỗi: ID khóa học không hợp lệ.");
            session.setAttribute("messageType", "error");
            response.sendRedirect("courses?action=list");
            return;
        }

        String materialIdStr = request.getParameter("materialId");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String fileUrl = request.getParameter("fileUrl"); // Trong thực tế sẽ là xử lý upload file

        try {
            if (materialIdStr == null || materialIdStr.isEmpty()) {
                // Thêm mới tài liệu: Constructor CourseMaterial(int courseId, String title, String description, String fileUrl)
                CourseMaterial newMaterial = new CourseMaterial(courseId, title, description, fileUrl);
                materialDAO.addCourseMaterial(newMaterial);
                session.setAttribute("message", "Thêm tài liệu khóa học thành công!");
                session.setAttribute("messageType", "success");
            } else {
                // Cập nhật tài liệu: Constructor CourseMaterial(int materialId, int courseId, String title, String description, String fileUrl, LocalDateTime uploadedAt)
                // Cần lấy uploadedAt hiện có từ DB hoặc từ form (nếu có trường hidden)
                int materialId = Integer.parseInt(materialIdStr);
                
                // Lấy thông tin tài liệu hiện có để giữ lại uploadedAt
                CourseMaterial existingMaterial = materialDAO.getCourseMaterialById(materialId);
                if (existingMaterial == null || existingMaterial.getCourseId() != courseId) {
                    throw new IllegalArgumentException("Không tìm thấy tài liệu hoặc tài liệu không thuộc khóa học này để cập nhật.");
                }
                
                CourseMaterial updatedMaterial = new CourseMaterial(materialId, courseId, title, description, fileUrl, existingMaterial.getUploadedAt());
                materialDAO.updateCourseMaterial(updatedMaterial);
                session.setAttribute("message", "Cập nhật tài liệu khóa học thành công!");
                session.setAttribute("messageType", "success");
            }
            response.sendRedirect("course-materials?action=list&courseId=" + courseId);

        } catch (NumberFormatException e) {
            session.setAttribute("message", "Lỗi: ID tài liệu không hợp lệ.");
            session.setAttribute("messageType", "error");
            response.sendRedirect("course-materials?action=list&courseId=" + courseId);
        } catch (IllegalArgumentException e) {
            session.setAttribute("message", "Lỗi: " + e.getMessage());
            session.setAttribute("messageType", "error");
            if (materialIdStr == null || materialIdStr.isEmpty()) {
                response.sendRedirect("course-materials?action=new&courseId=" + courseId);
            } else {
                response.sendRedirect("course-materials?action=edit&materialId=" + materialIdStr + "&courseId=" + courseId);
            }
        } catch (SQLException e) {
            session.setAttribute("message", "Lỗi cơ sở dữ liệu: " + e.getMessage());
            session.setAttribute("messageType", "error");
            if (materialIdStr == null || materialIdStr.isEmpty()) {
                response.sendRedirect("course-materials?action=new&courseId=" + courseId);
            } else {
                response.sendRedirect("course-materials?action=edit&materialId=" + materialIdStr + "&courseId=" + courseId);
            }
        } catch (Exception e) {
            session.setAttribute("message", "Đã xảy ra lỗi không mong muốn: " + e.getMessage());
            session.setAttribute("messageType", "error");
            if (materialIdStr == null || materialIdStr.isEmpty()) {
                response.sendRedirect("course-materials?action=new&courseId=" + courseId);
            } else {
                response.sendRedirect("course-materials?action=edit&materialId=" + materialIdStr + "&courseId=" + courseId);
            }
        }
    }

    private void listCourseMaterials(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        List<CourseMaterial> materials = materialDAO.getMaterialsByCourseId(courseId);
        request.setAttribute("materials", materials);
        request.setAttribute("courseId", courseId); // Giữ lại courseId để biết đang xem tài liệu của khóa học nào
        // Forward đến trang JSP hiển thị danh sách tài liệu
        request.getRequestDispatcher("course_materials.jsp").forward(request, response);
    }

    private void showNewMaterialForm(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException {
        request.setAttribute("courseId", courseId); // Cần truyền courseId để form biết nó thuộc khóa học nào
        request.getRequestDispatcher("add_course_material.jsp").forward(request, response);
    }

    private void showEditMaterialForm(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws ServletException, IOException, SQLException {
        try {
            int materialId = Integer.parseInt(request.getParameter("materialId"));
            CourseMaterial material = materialDAO.getCourseMaterialById(materialId);
            if (material != null && material.getCourseId() == courseId) { // Đảm bảo tài liệu thuộc đúng khóa học
                request.setAttribute("material", material);
                request.setAttribute("courseId", courseId);
                request.getRequestDispatcher("edit_course_material.jsp").forward(request, response);
            } else {
                HttpSession session = request.getSession();
                session.setAttribute("message", "Không tìm thấy tài liệu hoặc tài liệu không thuộc khóa học này.");
                session.setAttribute("messageType", "error");
                response.sendRedirect("course-materials?action=list&courseId=" + courseId);
            }
        } catch (NumberFormatException e) {
            HttpSession session = request.getSession();
            session.setAttribute("message", "Lỗi: ID tài liệu không hợp lệ để chỉnh sửa.");
            session.setAttribute("messageType", "error");
            response.sendRedirect("course-materials?action=list&courseId=" + courseId);
        }
    }

    private void deleteCourseMaterial(HttpServletRequest request, HttpServletResponse response, int courseId)
            throws IOException, SQLException {
        HttpSession session = request.getSession();
        try {
            int materialId = Integer.parseInt(request.getParameter("materialId"));
            // Lấy thông tin tài liệu để kiểm tra courseId trước khi xóa (tùy chọn, để an toàn hơn)
            CourseMaterial materialToDelete = materialDAO.getCourseMaterialById(materialId);
            if (materialToDelete != null && materialToDelete.getCourseId() == courseId) {
                materialDAO.deleteCourseMaterial(materialId);
                session.setAttribute("message", "Xóa tài liệu khóa học thành công!");
                session.setAttribute("messageType", "success");
            } else {
                session.setAttribute("message", "Không tìm thấy tài liệu hoặc bạn không có quyền xóa tài liệu này.");
                session.setAttribute("messageType", "error");
            }
        } catch (NumberFormatException e) {
            session.setAttribute("message", "Lỗi: ID tài liệu không hợp lệ để xóa.");
            session.setAttribute("messageType", "error");
        } catch (SQLException e) {
            session.setAttribute("message", "Lỗi cơ sở dữ liệu khi xóa tài liệu: " + e.getMessage());
            session.setAttribute("messageType", "error");
        }
        response.sendRedirect("course-materials?action=list&courseId=" + courseId);
    }
}