package dao;

import model.Announcement;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class AnnouncementDAO {
    private static final Logger logger = Logger.getLogger(AnnouncementDAO.class.getName());
    
    public AnnouncementDAO() {}
    
    public int addAnnouncement(Announcement announcement) throws SQLException {
        String sql = "INSERT INTO Announcements (title, content, course_id, created_by, is_important) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, announcement.getTitle());
            pstmt.setString(2, announcement.getContent());
            pstmt.setInt(3, announcement.getCourseId());
            pstmt.setInt(4, announcement.getCreatedBy());
            pstmt.setBoolean(5, announcement.isImportant());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating announcement failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating announcement failed, no ID obtained.");
                }
            }
        }
    }
    
    public boolean updateAnnouncement(Announcement announcement) throws SQLException {
        String sql = "UPDATE Announcements SET title = ?, content = ?, course_id = ?, " +
                     "is_important = ? WHERE announcement_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, announcement.getTitle());
            pstmt.setString(2, announcement.getContent());
            pstmt.setInt(3, announcement.getCourseId());
            pstmt.setBoolean(4, announcement.isImportant());
            pstmt.setInt(5, announcement.getAnnouncementId());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    public boolean deleteAnnouncement(int announcementId) throws SQLException {
        String sql = "DELETE FROM Announcements WHERE announcement_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, announcementId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    public Announcement getAnnouncementById(int announcementId) throws SQLException {
        String sql = "SELECT * FROM Announcements WHERE announcement_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, announcementId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapAnnouncement(rs);
                }
            }
        }
        
        return null;
    }
    
    public List<Announcement> getAnnouncementsByCourseId(int courseId) throws SQLException {
        String sql = "SELECT * FROM Announcements WHERE course_id = ? ORDER BY created_at DESC";
        List<Announcement> announcements = new ArrayList<>();
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    announcements.add(mapAnnouncement(rs));
                }
            }
        }
        
        return announcements;
    }
    
    public List<Announcement> getAnnouncementsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT a.* FROM Announcements a " +
                     "JOIN Courses c ON a.course_id = c.course_id " +
                     "WHERE c.lecturer_id = ? " +
                     "ORDER BY a.created_at DESC";
        List<Announcement> announcements = new ArrayList<>();
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, lecturerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    announcements.add(mapAnnouncement(rs));
                }
            }
        }
        
        return announcements;
    }
    
    public int countAnnouncementsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Announcements a " +
                     "JOIN Courses c ON a.course_id = c.course_id " +
                     "WHERE c.lecturer_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, lecturerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
    
    private Announcement mapAnnouncement(ResultSet rs) throws SQLException {
        Announcement announcement = new Announcement();
        announcement.setAnnouncementId(rs.getInt("announcement_id"));
        announcement.setTitle(rs.getString("title"));
        announcement.setContent(rs.getString("content"));
        announcement.setCourseId(rs.getInt("course_id"));
        announcement.setCreatedAt(rs.getTimestamp("created_at"));
        announcement.setCreatedBy(rs.getInt("created_by"));
        announcement.setImportant(rs.getBoolean("is_important"));
        
        return announcement;
    }
} 