package dao;

import model.TestSubmission;
import model.TestAnswer;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestSubmissionDAO {
    
    private static final Logger logger = Logger.getLogger(TestSubmissionDAO.class.getName());
    
    // Tạo submission mới (bắt đầu làm bài)
    public int startTestSubmission(int testId, int studentId) throws SQLException {
        String sql = "INSERT INTO test_submissions (test_id, student_id, status) VALUES (?, ?, 'in_progress')";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setInt(1, testId);
            ps.setInt(2, studentId);
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating test submission failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating test submission failed, no ID obtained.");
                }
            }
        }
    }
    
    // Lấy submission theo test và student
    public TestSubmission getSubmissionByTestAndStudent(int testId, int studentId) throws SQLException {
        String sql = """
            SELECT ts.*, t.title as test_title, t.duration_minutes, t.max_score,
                   s.full_name as student_name
            FROM test_submissions ts
            JOIN tests t ON ts.test_id = t.test_id
            JOIN students s ON ts.student_id = s.student_id
            WHERE ts.test_id = ? AND ts.student_id = ?
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, testId);
            ps.setInt(2, studentId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TestSubmission submission = mapTestSubmission(rs);
                    submission.setTestTitle(rs.getString("test_title"));
                    submission.setDurationMinutes(rs.getInt("duration_minutes"));
                    submission.setMaxScore(rs.getDouble("max_score"));
                    submission.setStudentName(rs.getString("student_name"));
                    return submission;
                }
            }
        }
        
        return null;
    }
    
    // Lấy submission theo ID
    public TestSubmission getSubmissionById(int submissionId) throws SQLException {
        String sql = """
            SELECT ts.*, t.title as test_title, t.duration_minutes, t.max_score,
                   s.full_name as student_name
            FROM test_submissions ts
            JOIN tests t ON ts.test_id = t.test_id
            JOIN students s ON ts.student_id = s.student_id
            WHERE ts.test_submission_id = ?
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, submissionId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TestSubmission submission = mapTestSubmission(rs);
                    submission.setTestTitle(rs.getString("test_title"));
                    submission.setDurationMinutes(rs.getInt("duration_minutes"));
                    submission.setMaxScore(rs.getDouble("max_score"));
                    submission.setStudentName(rs.getString("student_name"));
                    return submission;
                }
            }
        }
        
        return null;
    }
    
    // Lấy tất cả submissions của một sinh viên
    public List<TestSubmission> getSubmissionsByStudent(int studentId) throws SQLException {
        List<TestSubmission> submissions = new ArrayList<>();
        String sql = """
            SELECT ts.*, t.title as test_title, t.duration_minutes, t.max_score,
                   s.full_name as student_name
            FROM test_submissions ts
            JOIN tests t ON ts.test_id = t.test_id
            JOIN students s ON ts.student_id = s.student_id
            WHERE ts.student_id = ?
            ORDER BY ts.started_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, studentId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestSubmission submission = mapTestSubmission(rs);
                    submission.setTestTitle(rs.getString("test_title"));
                    submission.setDurationMinutes(rs.getInt("duration_minutes"));
                    submission.setMaxScore(rs.getDouble("max_score"));
                    submission.setStudentName(rs.getString("student_name"));
                    submissions.add(submission);
                }
            }
        }
        
        return submissions;
    }
    
    // Lấy tất cả submissions của một bài test
    public List<TestSubmission> getSubmissionsByTest(int testId) throws SQLException {
        List<TestSubmission> submissions = new ArrayList<>();
        String sql = """
            SELECT ts.*, t.title as test_title, t.duration_minutes, t.max_score,
                   s.full_name as student_name
            FROM test_submissions ts
            JOIN tests t ON ts.test_id = t.test_id
            JOIN students s ON ts.student_id = s.student_id
            WHERE ts.test_id = ?
            ORDER BY ts.started_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, testId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestSubmission submission = mapTestSubmission(rs);
                    submission.setTestTitle(rs.getString("test_title"));
                    submission.setDurationMinutes(rs.getInt("duration_minutes"));
                    submission.setMaxScore(rs.getDouble("max_score"));
                    submission.setStudentName(rs.getString("student_name"));
                    submissions.add(submission);
                }
            }
        }
        
        return submissions;
    }
    
    // Nộp bài test
    public boolean submitTest(int submissionId, double score) throws SQLException {
        String sql = """
            UPDATE test_submissions 
            SET submitted_at = GETDATE(), 
                score = ?, 
                status = 'submitted',
                time_spent_minutes = DATEDIFF(minute, started_at, GETDATE())
            WHERE test_submission_id = ?
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setDouble(1, score);
            ps.setInt(2, submissionId);
            
            return ps.executeUpdate() > 0;
        }
    }
    
    // Lưu câu trả lời
    public boolean saveAnswer(TestAnswer answer) throws SQLException {
        String checkSql = "SELECT answer_id FROM test_answers WHERE test_submission_id = ? AND question_id = ?";
        String insertSql = "INSERT INTO test_answers (test_submission_id, question_id, selected_option_id, answer_text, is_correct, points_earned) VALUES (?, ?, ?, ?, ?, ?)";
        String updateSql = "UPDATE test_answers SET selected_option_id = ?, answer_text = ?, is_correct = ?, points_earned = ? WHERE test_submission_id = ? AND question_id = ?";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Kiểm tra xem đã trả lời câu hỏi này chưa
            boolean hasAnswered = false;
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setInt(1, answer.getTestSubmissionId());
                checkPs.setInt(2, answer.getQuestionId());
                try (ResultSet rs = checkPs.executeQuery()) {
                    hasAnswered = rs.next();
                }
            }
            
            if (hasAnswered) {
                // Cập nhật câu trả lời
                try (PreparedStatement updatePs = conn.prepareStatement(updateSql)) {
                    updatePs.setObject(1, answer.getSelectedOptionId());
                    updatePs.setString(2, answer.getAnswerText());
                    updatePs.setObject(3, answer.getIsCorrect());
                    updatePs.setDouble(4, answer.getPointsEarned());
                    updatePs.setInt(5, answer.getTestSubmissionId());
                    updatePs.setInt(6, answer.getQuestionId());
                    return updatePs.executeUpdate() > 0;
                }
            } else {
                // Tạo câu trả lời mới
                try (PreparedStatement insertPs = conn.prepareStatement(insertSql)) {
                    insertPs.setInt(1, answer.getTestSubmissionId());
                    insertPs.setInt(2, answer.getQuestionId());
                    insertPs.setObject(3, answer.getSelectedOptionId());
                    insertPs.setString(4, answer.getAnswerText());
                    insertPs.setObject(5, answer.getIsCorrect());
                    insertPs.setDouble(6, answer.getPointsEarned());
                    return insertPs.executeUpdate() > 0;
                }
            }
        }
    }
    
    // Lấy tất cả câu trả lời của một submission
    public List<TestAnswer> getAnswersBySubmission(int submissionId) throws SQLException {
        List<TestAnswer> answers = new ArrayList<>();
        String sql = """
            SELECT ta.*, tq.question_text, tq.points as max_points,
                   tqo.option_text as selected_option_text
            FROM test_answers ta
            JOIN test_questions tq ON ta.question_id = tq.question_id
            LEFT JOIN test_question_options tqo ON ta.selected_option_id = tqo.option_id
            WHERE ta.test_submission_id = ?
            ORDER BY tq.question_order
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, submissionId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestAnswer answer = mapTestAnswer(rs);
                    answer.setQuestionText(rs.getString("question_text"));
                    answer.setMaxPoints(rs.getDouble("max_points"));
                    answer.setSelectedOptionText(rs.getString("selected_option_text"));
                    answers.add(answer);
                }
            }
        }
        
        return answers;
    }
    
    // Lấy câu trả lời với thông tin chi tiết (bao gồm question text và option text)
    public List<TestAnswer> getDetailedAnswersBySubmission(int submissionId) throws SQLException {
        List<TestAnswer> answers = new ArrayList<>();
        String sql = """
            SELECT ta.*, 
                   tq.question_text, tq.points as max_points,
                   tqo.option_text as selected_option_text
            FROM test_answers ta
            JOIN test_questions tq ON ta.question_id = tq.question_id
            LEFT JOIN test_question_options tqo ON ta.selected_option_id = tqo.option_id
            WHERE ta.test_submission_id = ?
            ORDER BY tq.question_order
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, submissionId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestAnswer answer = mapTestAnswer(rs);
                    answer.setQuestionText(rs.getString("question_text"));
                    answer.setMaxPoints(rs.getDouble("max_points"));
                    answer.setSelectedOptionText(rs.getString("selected_option_text"));
                    answers.add(answer);
                }
            }
        }
        
        return answers;
    }
    
    // Helper methods
    private TestSubmission mapTestSubmission(ResultSet rs) throws SQLException {
        TestSubmission submission = new TestSubmission();
        submission.setTestSubmissionId(rs.getInt("test_submission_id"));
        submission.setTestId(rs.getInt("test_id"));
        submission.setStudentId(rs.getInt("student_id"));
        submission.setStartedAt(rs.getTimestamp("started_at"));
        submission.setSubmittedAt(rs.getTimestamp("submitted_at"));
        submission.setScore(rs.getObject("score", Double.class));
        submission.setStatus(rs.getString("status"));
        submission.setTimeSpentMinutes(rs.getObject("time_spent_minutes", Integer.class));
        return submission;
    }
    
    private TestAnswer mapTestAnswer(ResultSet rs) throws SQLException {
        TestAnswer answer = new TestAnswer();
        answer.setAnswerId(rs.getInt("answer_id"));
        answer.setTestSubmissionId(rs.getInt("test_submission_id"));
        answer.setQuestionId(rs.getInt("question_id"));
        answer.setSelectedOptionId(rs.getObject("selected_option_id", Integer.class));
        answer.setAnswerText(rs.getString("answer_text"));
        answer.setIsCorrect(rs.getObject("is_correct", Boolean.class));
        answer.setPointsEarned(rs.getDouble("points_earned"));
        return answer;
    }
}