package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Student;
import model.User;
import utils.DBConnection; // Bạn cần tạo class DBConnection để kết nối DB

public class StudentDAO {

    public List<Student> getStudentsByCourse(int courseId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT s.* FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    WHERE e.course_id = ?
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student s = new Student(
                        rs.getInt("student_id"),
                        rs.getInt("user_id"),
                        rs.getString("full_name"),
                        rs.getString("student_code"),
                        rs.getString("email"),
                        rs.getString("avatar_url"));
                list.add(s);
            }
        }
        return list;
    }

    // Thêm student mới
    public boolean insertStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students (user_id, full_name, student_code, email, avatar_url) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, student.getUserId());
            ps.setString(2, student.getFullName());
            ps.setString(3, student.getStudentCode());
            ps.setString(4, student.getEmail());
            ps.setString(5, student.getAvatarUrl());
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    private boolean updateUser(User user) {
        String sql = "UPDATE users SET full_name = ?, email = ?, avatar_url = ?, is_active = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getFullName());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getAvatarUrl());
            stmt.setBoolean(4, user.isActive());
            stmt.setInt(5, user.getUserId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Cập nhật thông tin student
//    public boolean updateStudent(Student student) {
//        String sql = "UPDATE students SET phone = ?, address = ? WHERE student_id = ?";
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setInt(1, student.getPhone());
//            stmt.setString(2, student.getAddress());
//            stmt.setInt(3, student.getStudentId());
//            int rows = stmt.executeUpdate();
//            if (rows > 0) {
//                return updateUser(student.getUser());
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
       
    public boolean updateStudentPassword(int userId, String oldPassword, String newPassword) {
        String getUserSql = "SELECT password FROM users WHERE user_id = ?";
        String updatePasswordSql = "UPDATE users SET password = ? WHERE user_id = ?";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Lấy mật khẩu hiện tại (đã hash)
            String currentHashedPassword = null;
            try (PreparedStatement stmt = conn.prepareStatement(getUserSql)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    currentHashedPassword = rs.getString("password");
                }
            }
            
            if (currentHashedPassword == null) {
                System.out.println("Không tìm thấy user với ID: " + userId);
                return false;
            }
            
            System.out.println("Current hashed password: " + currentHashedPassword);
            System.out.println("Input old password: " + oldPassword);
            
            // Kiểm tra mật khẩu cũ có đúng không
            boolean isOldPasswordCorrect = false;
            
            // Kiểm tra xem mật khẩu trong DB có phải BCrypt hash không
            if (currentHashedPassword.startsWith("$2a$") || currentHashedPassword.startsWith("$2b$") || currentHashedPassword.startsWith("$2y$")) {
                // Mật khẩu đã được hash bằng BCrypt
                isOldPasswordCorrect = utils.BCryptUtil.checkPassword(oldPassword, currentHashedPassword);
                System.out.println("BCrypt check result: " + isOldPasswordCorrect);
            } else {
                // Mật khẩu chưa được hash (plain text) - so sánh trực tiếp
                isOldPasswordCorrect = oldPassword.equals(currentHashedPassword);
                System.out.println("Plain text check result: " + isOldPasswordCorrect);
            }
            
            if (!isOldPasswordCorrect) {
                System.out.println("Mật khẩu cũ không đúng");
                return false;
            }
            
            // Hash mật khẩu mới bằng BCrypt
            String hashedNewPassword = utils.BCryptUtil.hashPassword(newPassword);
            System.out.println("New hashed password: " + hashedNewPassword);
            
            // Cập nhật mật khẩu mới (đã hash)
            try (PreparedStatement stmt = conn.prepareStatement(updatePasswordSql)) {
                stmt.setString(1, hashedNewPassword);
                stmt.setInt(2, userId);
                int rowsUpdated = stmt.executeUpdate();
                System.out.println("Rows updated: " + rowsUpdated);
                return rowsUpdated > 0;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Lỗi trong updateStudentPassword: " + e.getMessage());
        }
        return false;
    }

    // Xóa student theo student_id
    public boolean deleteStudent(int studentId) throws SQLException {
        String sql = "DELETE FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    // Lấy student theo student_id
    public Student getStudentById(int studentId) throws SQLException {
        String sql = "SELECT * FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    return s;
                }
            }
        }
        return null;
    }

    // Lấy danh sách tất cả student
    public List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Student s = new Student();
                s.setStudentId(rs.getInt("student_id"));
                s.setUserId(rs.getInt("user_id"));
                s.setFullName(rs.getString("full_name"));
                s.setStudentCode(rs.getString("student_code"));
                s.setEmail(rs.getString("email"));
                s.setAvatarUrl(rs.getString("avatar_url"));
                list.add(s);
            }
        }
        return list;
    }

    public boolean enrollStudent(int userId, int courseId) {
        String sql = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            // cần lấy student_id từ user_id
            int studentId = getStudentIdByUserId(userId);
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private int getStudentIdByUserId(int userId) throws SQLException {
        String sql = "SELECT student_id FROM students WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("student_id");
            }
        }
        throw new SQLException("Student not found for user_id: " + userId);
    }

    // Lấy danh sách sinh viên chưa đăng ký khóa học
    public List<Student> getStudentsNotInCourse(int courseId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, u.username, u.email, u.full_name, u.avatar_url "
                + "FROM students s "
                + "INNER JOIN users u ON s.user_id = u.user_id "
                + "WHERE s.student_id NOT IN ("
                + "    SELECT e.student_id FROM enrollments e "
                + "    WHERE e.course_id = ? AND e.status = 'active'"
                + ") "
                + "ORDER BY u.full_name";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setStudentCode(rs.getString("student_code"));

                    // Set thông tin từ bảng users
                    s.setFullName(rs.getString("full_name"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));

                    list.add(s);
                }
            }
        }
        return list;
    }

    // Đếm số lượng sinh viên
    public int countStudents() throws SQLException {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // Đếm số lượng sinh viên theo giảng viên
    public int getStudentCountByLecturerId(int lecturerId) throws SQLException {
        String sql = """
        SELECT COUNT(DISTINCT s.student_id)
        FROM lecturers l
        JOIN courses c ON l.lecturer_id = c.lecturer_id
        JOIN enrollments e ON c.course_id = e.course_id
        JOIN students s ON e.student_id = s.student_id
        WHERE l.lecturer_id = ?
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, lecturerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        return 0;
    }

    // Lấy danh sách sinh viên theo giảng viên
    public List<Student> getStudentsByLecturerId(int lecturerId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT DISTINCT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    JOIN courses c ON e.course_id = c.course_id
                    WHERE c.lecturer_id = ?
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    // Tìm kiếm sinh viên theo từ khóa
    public List<Student> searchStudentsByLecturer(int lecturerId, String keyword) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT DISTINCT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    JOIN courses c ON e.course_id = c.course_id
                    WHERE c.lecturer_id = ? 
                    AND (s.full_name LIKE ? OR s.student_code LIKE ? OR s.email LIKE ?)
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            String searchTerm = "%" + keyword + "%";
            ps.setString(2, searchTerm);
            ps.setString(3, searchTerm);
            ps.setString(4, searchTerm);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    // Tìm kiếm sinh viên theo khóa học và từ khóa
    public List<Student> searchStudentsByCourse(int courseId, String keyword) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = """
                    SELECT s.* 
                    FROM students s
                    JOIN enrollments e ON s.student_id = e.student_id
                    WHERE e.course_id = ? 
                    AND (s.full_name LIKE ? OR s.student_code LIKE ? OR s.email LIKE ?)
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            String searchTerm = "%" + keyword + "%";
            ps.setString(2, searchTerm);
            ps.setString(3, searchTerm);
            ps.setString(4, searchTerm);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    public List<Student> getStudentsByCourseId(int courseId) {
        List<Student> students = new ArrayList<>();
        String sql = """
        SELECT s.* FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        WHERE e.course_id = ?
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setFullName(rs.getString("full_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getInt("phone"));
                student.setUserId(rs.getInt("user_id"));
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public Student getStudentByUserId(int userId) {
        String sql = "SELECT * FROM students WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setUserId(rs.getInt("user_id"));
                    s.setFullName(rs.getString("full_name"));
                    s.setStudentCode(rs.getString("student_code"));
                    s.setEmail(rs.getString("email"));
                    s.setAvatarUrl(rs.getString("avatar_url"));
                    s.setPhone(rs.getInt("phone"));
                    s.setAddress(rs.getString("address"));
                    return s;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
     
   
    
           // Lấy thông tin chi tiết student theo user_id
        // Lấy thông tin chi tiết student theo user_id - với default values
    public Student getStudentWithDetailsByUserId(int userId) {
        String sql = "SELECT s.student_id, s.user_id, s.full_name, s.student_code, s.email, " +
                    "s.avatar_url, s.class_name, s.phone, s.date_of_birth, s.address, " +
                    "s.enrollment_year, u.email as user_email " +
                    "FROM students s " +
                    "JOIN users u ON s.user_id = u.user_id " +
                    "WHERE s.user_id = ?";
        
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setUserId(rs.getInt("user_id"));
                student.setFullName(rs.getString("full_name"));
                student.setStudentCode(rs.getString("student_code"));
                student.setEmail(rs.getString("user_email"));
                student.setAvatarUrl(rs.getString("avatar_url"));
                
                // Handle className - luôn có giá trị
                String className = rs.getString("class_name");
                if (className != null && !className.trim().isEmpty()) {
                    student.setClassName(className);
                } else {
                    student.setClassName(""); // Để trống thay vì "Chưa có lớp"
                }
                
                // Handle int phone
                int phoneInt = rs.getInt("phone");
                if (rs.wasNull()) {
                    student.setPhone(0);
                } else {
                    student.setPhone(phoneInt);
                }
                
                // Handle address
                String address = rs.getString("address");
                if (address != null) {
                    student.setAddress(address);
                } else {
                    student.setAddress(""); // Default empty
                }
                
                // Handle enrollmentYear - luôn có giá trị
                int enrollmentYear = rs.getInt("enrollment_year");
                if (rs.wasNull() || enrollmentYear == 0) {
                    // Set default enrollment year (năm hiện tại)
                    int currentYear = java.time.Year.now().getValue();
                    student.setEnrollmentYear(currentYear);
                } else {
                    student.setEnrollmentYear(enrollmentYear);
                }
                
                // Handle dateOfBirth - luôn có giá trị
                Date dateOfBirth = rs.getDate("date_of_birth");
                if (dateOfBirth != null) {
                    student.setDateOfBirth(dateOfBirth);
                } else {
                    // Set default date (1/1/2000)
                    student.setDateOfBirth(Date.valueOf("2000-01-01"));
                }
                
                System.out.println("=== LOADED STUDENT DATA ===");
                System.out.println("Student ID: " + student.getStudentId());
                System.out.println("Full Name: " + student.getFullName());
                System.out.println("Student Code: " + student.getStudentCode());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Phone: " + student.getPhone());
                System.out.println("Class: " + student.getClassName());
                System.out.println("Address: " + student.getAddress());
                System.out.println("Enrollment Year: " + student.getEnrollmentYear());
                System.out.println("Date of Birth: " + student.getDateOfBirth());
                System.out.println("==========================");
                
                return student;
            } else {
                System.out.println("No student found for user_id: " + userId);
            }
        } catch (SQLException e) {
            System.err.println("SQL Error in getStudentWithDetailsByUserId: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

        // Cập nhật thông tin cá nhân của student (thêm className và enrollmentYear)
    public boolean updateStudentInfo(int userId, String fullName, String phoneStr, String address, 
                                   String dateOfBirth, String className, String enrollmentYearStr) {
        String updateStudentSql = "UPDATE students SET full_name = ?, phone = ?, address = ?, date_of_birth = ?, class_name = ?, enrollment_year = ? WHERE user_id = ?";
        String updateUserSql = "UPDATE users SET full_name = ? WHERE user_id = ?";
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            
            // Convert phone string to int
            Integer phoneInt = null;
            if (phoneStr != null && !phoneStr.trim().isEmpty()) {
                try {
                    phoneInt = Integer.parseInt(phoneStr.trim());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid phone number format: " + phoneStr);
                    return false;
                }
            }
            
            // Convert enrollment year string to int
            Integer enrollmentYear = null;
            if (enrollmentYearStr != null && !enrollmentYearStr.trim().isEmpty()) {
                try {
                    enrollmentYear = Integer.parseInt(enrollmentYearStr.trim());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid enrollment year format: " + enrollmentYearStr);
                    return false;
                }
            }
            
            // Cập nhật bảng students
            try (PreparedStatement stmt1 = conn.prepareStatement(updateStudentSql)) {
                stmt1.setString(1, fullName);
                if (phoneInt != null) {
                    stmt1.setInt(2, phoneInt);
                } else {
                    stmt1.setNull(2, java.sql.Types.INTEGER);
                }
                stmt1.setString(3, address);
                if (dateOfBirth != null && !dateOfBirth.isEmpty()) {
                    stmt1.setDate(4, java.sql.Date.valueOf(dateOfBirth));
                } else {
                    stmt1.setNull(4, java.sql.Types.DATE);
                }
                stmt1.setString(5, className);
                if (enrollmentYear != null) {
                    stmt1.setInt(6, enrollmentYear);
                } else {
                    stmt1.setNull(6, java.sql.Types.INTEGER);
                }
                stmt1.setInt(7, userId);
                stmt1.executeUpdate();
            }
            
            // Cập nhật bảng users
            try (PreparedStatement stmt2 = conn.prepareStatement(updateUserSql)) {
                stmt2.setString(1, fullName);
                stmt2.setInt(2, userId);
                stmt2.executeUpdate();
            }
            
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

  public Map<String, Object> getDashboardStats(int studentId) {
        Map<String, Object> stats = new HashMap<>();
        
        String enrolledCoursesSQL = "SELECT COUNT(*) FROM enrollments WHERE student_id = ? AND status = 'active'";
        String pendingAssignmentsSQL = "SELECT COUNT(*) FROM assignments a " +
                                     "JOIN enrollments e ON a.course_id = e.course_id " +
                                     "LEFT JOIN submissions s ON a.assignment_id = s.assignment_id AND s.student_id = ? " +
                                     "WHERE e.student_id = ? AND e.status = 'active' " +
                                     "AND s.submission_id IS NULL AND a.due_date > GETDATE()";
        String unreadAnnouncementsSQL = "SELECT COUNT(*) FROM announcements a " +
                                      "JOIN enrollments e ON a.course_id = e.course_id " +
                                      "WHERE e.student_id = ? AND e.status = 'active' " +
                                      "AND a.created_at > DATEADD(day, -7, GETDATE())";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Số khóa học đang học
            try (PreparedStatement stmt = conn.prepareStatement(enrolledCoursesSQL)) {
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    stats.put("enrolledCourses", rs.getInt(1));
                }
            }
            
            // Số bài tập chưa nộp
            try (PreparedStatement stmt = conn.prepareStatement(pendingAssignmentsSQL)) {
                stmt.setInt(1, studentId);
                stmt.setInt(2, studentId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    stats.put("pendingAssignments", rs.getInt(1));
                }
            }
            
            // Số thông báo mới
            try (PreparedStatement stmt = conn.prepareStatement(unreadAnnouncementsSQL)) {
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    stats.put("unreadAnnouncements", rs.getInt(1));
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return stats;
    }
}
