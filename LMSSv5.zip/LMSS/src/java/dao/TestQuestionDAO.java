package dao;

import model.TestQuestion;
import model.TestQuestionOption;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestQuestionDAO {
    
    private static final Logger logger = Logger.getLogger(TestQuestionDAO.class.getName());
    
    // Lấy tất cả câu hỏi của một bài test
    public List<TestQuestion> getQuestionsByTestId(int testId) throws SQLException {
        List<TestQuestion> questions = new ArrayList<>();
        String sql = "SELECT * FROM test_questions WHERE test_id = ? ORDER BY question_order";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, testId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestQuestion question = mapTestQuestion(rs);
                    
                    // Lấy options cho câu hỏi trắc nghiệm
                    if (question.isMultipleChoice() || question.isTrueFalse()) {
                        question.setOptions(getOptionsByQuestionId(question.getQuestionId()));
                    }
                    
                    questions.add(question);
                }
            }
        }
        
        return questions;
    }
    
    // Lấy options của một câu hỏi
    public List<TestQuestionOption> getOptionsByQuestionId(int questionId) throws SQLException {
        List<TestQuestionOption> options = new ArrayList<>();
        String sql = "SELECT * FROM test_question_options WHERE question_id = ? ORDER BY option_order";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, questionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TestQuestionOption option = mapTestQuestionOption(rs);
                    options.add(option);
                }
            }
        }
        
        return options;
    }
    
    // Lấy câu hỏi theo ID
    public TestQuestion getQuestionById(int questionId) throws SQLException {
        String sql = "SELECT * FROM test_questions WHERE question_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, questionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TestQuestion question = mapTestQuestion(rs);
                    
                    // Lấy options nếu là câu hỏi trắc nghiệm
                    if (question.isMultipleChoice() || question.isTrueFalse()) {
                        question.setOptions(getOptionsByQuestionId(questionId));
                    }
                    
                    return question;
                }
            }
        }
        
        return null;
    }
    
    // Lấy option theo ID
    public TestQuestionOption getOptionById(int optionId) throws SQLException {
        String sql = "SELECT * FROM test_question_options WHERE option_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, optionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapTestQuestionOption(rs);
                }
            }
        }
        
        return null;
    }
    
    // Tạo câu hỏi mới
    public int createQuestion(TestQuestion question) throws SQLException {
        String sql = "INSERT INTO test_questions (test_id, question_text, question_type, points, question_order) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setInt(1, question.getTestId());
            ps.setString(2, question.getQuestionText());
            ps.setString(3, question.getQuestionType());
            ps.setDouble(4, question.getPoints());
            ps.setInt(5, question.getQuestionOrder());
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating question failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int questionId = generatedKeys.getInt(1);
                    
                    // Tạo options nếu có
                    if (question.getOptions() != null) {
                        for (TestQuestionOption option : question.getOptions()) {
                            option.setQuestionId(questionId);
                            createOption(option);
                        }
                    }
                    
                    return questionId;
                } else {
                    throw new SQLException("Creating question failed, no ID obtained.");
                }
            }
        }
    }
    
    // Tạo option mới
    public int createOption(TestQuestionOption option) throws SQLException {
        String sql = "INSERT INTO test_question_options (question_id, option_text, is_correct, option_order) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setInt(1, option.getQuestionId());
            ps.setString(2, option.getOptionText());
            ps.setBoolean(3, option.isCorrect());
            ps.setInt(4, option.getOptionOrder());
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating option failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating option failed, no ID obtained.");
                }
            }
        }
    }
    
    // Helper methods
    private TestQuestion mapTestQuestion(ResultSet rs) throws SQLException {
        TestQuestion question = new TestQuestion();
        question.setQuestionId(rs.getInt("question_id"));
        question.setTestId(rs.getInt("test_id"));
        question.setQuestionText(rs.getString("question_text"));
        question.setQuestionType(rs.getString("question_type"));
        question.setPoints(rs.getDouble("points"));
        question.setQuestionOrder(rs.getInt("question_order"));
        return question;
    }
    
    private TestQuestionOption mapTestQuestionOption(ResultSet rs) throws SQLException {
        TestQuestionOption option = new TestQuestionOption();
        option.setOptionId(rs.getInt("option_id"));
        option.setQuestionId(rs.getInt("question_id"));
        option.setOptionText(rs.getString("option_text"));
        option.setCorrect(rs.getBoolean("is_correct"));
        option.setOptionOrder(rs.getInt("option_order"));
        return option;
    }
}