package dao;

import java.sql.*;
import java.util.*;
import model.Forum;
import utils.DBConnection;

public class ForumDAO {
    public List<Forum> getForumsByCourse(int courseId) throws Exception {
        List<Forum> list = new ArrayList<>();
        String sql = "SELECT * FROM forums WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Forum f = new Forum(
                        rs.getInt("forum_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getInt("created_by"),
                        rs.getTimestamp("created_at")
                    );
                    list.add(f);
                }
            }
        }
        return list;
    }
    
    public Forum getForumById(int forumId) throws Exception {
        String sql = "SELECT * FROM forums WHERE forum_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, forumId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Forum(
                        rs.getInt("forum_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getInt("created_by"),
                        rs.getTimestamp("created_at")
                    );
                }
            }
        }
        return null;
    }
    
    public int createForum(Forum forum) throws Exception {
        String sql = "INSERT INTO forums (course_id, title, created_by, created_at) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, forum.getCourseId());
            ps.setString(2, forum.getTitle());
            ps.setInt(3, forum.getCreatedBy());
            
            // If createdAt is null, use current timestamp
            if (forum.getCreatedAt() == null) {
                ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            } else {
                ps.setTimestamp(4, forum.getCreatedAt());
            }
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating forum failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating forum failed, no ID obtained.");
                }
            }
        }
    }
    
    public boolean updateForum(Forum forum) throws Exception {
        String sql = "UPDATE forums SET title = ? WHERE forum_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, forum.getTitle());
            ps.setInt(2, forum.getForumId());
            return ps.executeUpdate() > 0;
        }
    }
    
    public boolean deleteForum(int forumId) throws Exception {
        String sql = "DELETE FROM forums WHERE forum_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, forumId);
            return ps.executeUpdate() > 0;
        }
    }
    
    public List<Forum> getForumsByLecturerId(int lecturerId) throws Exception {
        List<Forum> list = new ArrayList<>();
        String sql = """
                    SELECT f.* 
                    FROM forums f 
                    JOIN courses c ON f.course_id = c.course_id 
                    WHERE c.lecturer_id = ?
                    ORDER BY f.created_at DESC
                """;
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Forum f = new Forum(
                        rs.getInt("forum_id"),
                        rs.getInt("course_id"),
                        rs.getString("title"),
                        rs.getInt("created_by"),
                        rs.getTimestamp("created_at")
                    );
                    list.add(f);
                }
            }
        }
        return list;
    }
    
    public int countForumsByCourseId(int courseId) throws Exception {
        String sql = "SELECT COUNT(*) FROM forums WHERE course_id = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
}
