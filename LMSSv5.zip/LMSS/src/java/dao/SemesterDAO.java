package dao;

import model.Semester;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SemesterDAO {

    public SemesterDAO() {
    }

    // Thêm học kỳ mới
    public boolean addSemester(Semester semester) throws SQLException {
        String sql = "INSERT INTO semesters (name, code, start_date, end_date, is_active) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, semester.getName());
            stmt.setString(2, semester.getCode());
            stmt.setDate(3, semester.getStartDate());
            stmt.setDate(4, semester.getEndDate());
            stmt.setBoolean(5, semester.isActive());

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        semester.setSemesterId(rs.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    // Lấy tất cả học kỳ
    public List<Semester> getAllSemesters() throws SQLException {
        List<Semester> semesters = new ArrayList<>();
        String sql = "SELECT semester_id, name, code, start_date, end_date, is_active, created_at FROM semesters ORDER BY created_at DESC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Semester semester = new Semester(
                        rs.getInt("semester_id"),
                        rs.getString("name"),
                        rs.getString("code"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getBoolean("is_active"),
                        rs.getTimestamp("created_at"));
                semesters.add(semester);
            }
        }
        return semesters;
    }

    // Lấy học kỳ theo ID
    public Semester getSemesterById(int semesterId) throws SQLException {
        String sql = "SELECT semester_id, name, code, start_date, end_date, is_active, created_at FROM semesters WHERE semester_id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, semesterId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Semester(
                            rs.getInt("semester_id"),
                            rs.getString("name"),
                            rs.getString("code"),
                            rs.getDate("start_date"),
                            rs.getDate("end_date"),
                            rs.getBoolean("is_active"),
                            rs.getTimestamp("created_at"));
                }
            }
        }
        return null;
    }

    // Lấy học kỳ theo mã code
    public Semester getSemesterByCode(String code) throws SQLException {
        String sql = "SELECT semester_id, name, code, start_date, end_date, is_active, created_at FROM semesters WHERE code = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, code);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Semester(
                            rs.getInt("semester_id"),
                            rs.getString("name"),
                            rs.getString("code"),
                            rs.getDate("start_date"),
                            rs.getDate("end_date"),
                            rs.getBoolean("is_active"),
                            rs.getTimestamp("created_at"));
                }
            }
        }
        return null;
    }

    // Cập nhật học kỳ
    public boolean updateSemester(Semester semester) throws SQLException {
        String sql = "UPDATE semesters SET name = ?, code = ?, start_date = ?, end_date = ?, is_active = ? WHERE semester_id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, semester.getName());
            stmt.setString(2, semester.getCode());
            stmt.setDate(3, semester.getStartDate());
            stmt.setDate(4, semester.getEndDate());
            stmt.setBoolean(5, semester.isActive());
            stmt.setInt(6, semester.getSemesterId());

            return stmt.executeUpdate() > 0;
        }
    }

    // Xóa học kỳ
    public boolean deleteSemester(int semesterId) throws SQLException {
        String sql = "DELETE FROM semesters WHERE semester_id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, semesterId);
            return stmt.executeUpdate() > 0;
        }
    }

    // Lấy học kỳ đang hoạt động
    public List<Semester> getActiveSemesters() throws SQLException {
        List<Semester> semesters = new ArrayList<>();
        String sql = "SELECT semester_id, name, code, start_date, end_date, is_active, created_at FROM semesters WHERE is_active = 1 ORDER BY start_date DESC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Semester semester = new Semester(
                        rs.getInt("semester_id"),
                        rs.getString("name"),
                        rs.getString("code"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getBoolean("is_active"),
                        rs.getTimestamp("created_at"));
                semesters.add(semester);
            }
        }
        return semesters;
    }

    // Lấy học kỳ hiện tại (đang trong thời gian học)
    public Semester getCurrentSemester() throws SQLException {
        String sql = "SELECT semester_id, name, code, start_date, end_date, is_active, created_at " +
                "FROM semesters " +
                "WHERE is_active = 1 AND start_date <= GETDATE() AND end_date >= GETDATE() " +
                "ORDER BY start_date DESC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return new Semester(
                        rs.getInt("semester_id"),
                        rs.getString("name"),
                        rs.getString("code"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getBoolean("is_active"),
                        rs.getTimestamp("created_at"));
            }
        }
        return null;
    }

    // Kiểm tra tên học kỳ đã tồn tại chưa
    public boolean isSemesterNameExists(String name) throws SQLException {
        String sql = "SELECT COUNT(*) FROM semesters WHERE name = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    // Kiểm tra tên học kỳ đã tồn tại chưa (trừ ID hiện tại)
    public boolean isSemesterNameExists(String name, int excludeId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM semesters WHERE name = ? AND semester_id != ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setInt(2, excludeId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
}
