package dao;

import model.Material;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MaterialDAO {

    private static final Logger logger = Logger.getLogger(MaterialDAO.class.getName());

    public MaterialDAO() {
    }

    public List<Material> getMaterialsByCourse(int courseId) {
        List<Material> materials = new ArrayList<>();

        String sql = """
        SELECT material_id, course_id, title, description, file_url, file_type,
               file_size, material_type, is_public, uploaded_by, uploaded_at, download_count
        FROM course_materials
        WHERE course_id = ?
        ORDER BY uploaded_at DESC
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Material m = new Material();
                    m.setMaterialId(rs.getInt("material_id"));
                    m.setCourseId(rs.getInt("course_id"));
                    m.setTitle(rs.getString("title"));
                    m.setDescription(rs.getString("description"));
                    m.setFilePath(rs.getString("file_url")); // map sang filePath trong model
                    m.setMaterialType(rs.getString("material_type"));
                    m.setUploadDate(rs.getTimestamp("uploaded_at"));
                    m.setUploadedBy(rs.getInt("uploaded_by"));
                    // Các trường còn lại nếu cần có thể thêm vào model

                    materials.add(m);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return materials;
    }

    public int addMaterial(Material material) throws SQLException {
        String sql = "INSERT INTO Materials (title, description, file_path, course_id, uploaded_by, material_type) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, material.getTitle());
            pstmt.setString(2, material.getDescription());
            pstmt.setString(3, material.getFilePath());
            pstmt.setInt(4, material.getCourseId());
            pstmt.setInt(5, material.getUploadedBy());
            pstmt.setString(6, material.getMaterialType());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating material failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating material failed, no ID obtained.");
                }
            }
        }
    }

//    public List<Material> getRecentMaterialsByStudentId(int studentId) {
//        List<Material> list = new ArrayList<>();
//        String sql = """
//        SELECT cm.material_id, cm.course_id, cm.title, cm.description,
//               cm.file_url, cm.file_type, cm.file_size, cm.material_type,
//               cm.is_public, cm.uploaded_by, cm.uploaded_at, cm.download_count
//        FROM course_materials cm
//        JOIN courses c ON cm.course_id = c.course_id
//        JOIN enrollments e ON c.course_id = e.course_id
//        WHERE e.student_id = ?
//        ORDER BY cm.uploaded_at DESC
//        OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY
//    """;
//
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            ps.setInt(1, studentId);
//            ResultSet rs = ps.executeQuery();
//
//            while (rs.next()) {
//                Material m = new Material();
//                m.setMaterialId(rs.getInt("material_id"));
//                m.setCourseId(rs.getInt("course_id"));
//                m.setTitle(rs.getString("title"));
//                m.setDescription(rs.getString("description"));
//                m.setFileUrl(rs.getString("file_url"));
//                m.setFileType(rs.getString("file_type"));
//                m.setFileSize(rs.getLong("file_size"));
//                m.setMaterialType(rs.getString("material_type"));
//                m.setPublic(rs.getBoolean("is_public"));
//                m.setUploadedBy(rs.getInt("uploaded_by"));
//                m.setUploadedAt(rs.getTimestamp("uploaded_at"));
//                m.setDownloadCount(rs.getInt("download_count"));
//
//                list.add(m);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        return list;
//    }

    public boolean updateMaterial(Material material) throws SQLException {
        String sql = "UPDATE Materials SET title = ?, description = ?, file_path = ?, "
                + "course_id = ?, material_type = ? WHERE material_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, material.getTitle());
            pstmt.setString(2, material.getDescription());
            pstmt.setString(3, material.getFilePath());
            pstmt.setInt(4, material.getCourseId());
            pstmt.setString(5, material.getMaterialType());
            pstmt.setInt(6, material.getMaterialId());

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public boolean deleteMaterial(int materialId) throws SQLException {
        String sql = "DELETE FROM Materials WHERE material_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, materialId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public Material getMaterialById(int materialId) throws SQLException {
        String sql = """
            SELECT m.material_id, m.course_id, m.title, m.description, m.file_url,
                   m.file_type, m.file_size, m.material_type, m.is_public,
                   m.uploaded_by, m.uploaded_at, m.download_count
            FROM course_materials m
            WHERE m.material_id = ?
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, materialId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Material material = new Material();
                    material.setMaterialId(rs.getInt("material_id"));
                    material.setCourseId(rs.getInt("course_id"));
                    material.setTitle(rs.getString("title"));
                    material.setDescription(rs.getString("description"));
                    material.setFilePath(rs.getString("file_url"));
                    material.setFileType(rs.getString("file_type"));
                    material.setFileSize(rs.getLong("file_size"));
                    material.setMaterialType(rs.getString("material_type"));
                    material.setPublic(rs.getBoolean("is_public"));
                    material.setUploadedBy(rs.getInt("uploaded_by"));
                    material.setUploadDate(rs.getTimestamp("uploaded_at"));
                    material.setDownloadCount(rs.getInt("download_count"));
                    
                    return material;
                }
            }
        }
        
        return null;
    }

    public List<Material> getMaterialsByCourseId(int courseId) throws SQLException {
        List<Material> materials = new ArrayList<>();
        
        String sql = """
            SELECT m.material_id, m.course_id, m.title, m.description, m.file_url,
                   m.file_type, m.file_size, m.material_type, m.is_public,
                   m.uploaded_by, m.uploaded_at, m.download_count,
                   u.full_name as uploader_name
            FROM course_materials m
            INNER JOIN users u ON m.uploaded_by = u.user_id
            WHERE m.course_id = ? AND m.is_public = 1
            ORDER BY m.uploaded_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Material material = new Material();
                    material.setMaterialId(rs.getInt("material_id"));
                    material.setCourseId(rs.getInt("course_id"));
                    material.setTitle(rs.getString("title"));
                    material.setDescription(rs.getString("description"));
                    material.setFilePath(rs.getString("file_url"));
                    material.setFileType(rs.getString("file_type"));
                    material.setFileSize(rs.getLong("file_size"));
                    material.setMaterialType(rs.getString("material_type"));
                    material.setPublic(rs.getBoolean("is_public"));
                    material.setUploadedBy(rs.getInt("uploaded_by"));
                    material.setUploadDate(rs.getTimestamp("uploaded_at"));
                    material.setDownloadCount(rs.getInt("download_count"));
                    
                    materials.add(material);
                }
            }
        }
        
        return materials;
    }

    public List<Material> getMaterialsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT m.* FROM Materials m "
                + "JOIN Courses c ON m.course_id = c.course_id "
                + "WHERE c.lecturer_id = ? "
                + "ORDER BY m.upload_date DESC";
        List<Material> materials = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    materials.add(mapMaterial(rs));
                }
            }
        }

        return materials;
    }
    public void incrementDownloadCount(int materialId) throws SQLException {
        String sql = "UPDATE course_materials SET download_count = download_count + 1 WHERE material_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, materialId);
            pstmt.executeUpdate();
        }
    }

    public int countMaterialsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Materials m "
                + "JOIN Courses c ON m.course_id = c.course_id "
                + "WHERE c.lecturer_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        return 0;
    }
    

    // New method to get all materials for a student based on enrolled courses
    public boolean canAccessMaterial(int materialId, int studentId) throws SQLException {
        String sql = """
            SELECT 1 FROM course_materials m
            INNER JOIN enrollments e ON m.course_id = e.course_id
            WHERE m.material_id = ? AND e.student_id = ? 
            AND e.status = 'active' AND m.is_public = 1
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, materialId);
            pstmt.setInt(2, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
    
    // Lấy tài liệu mới nhất cho sinh viên
    public List<Material> getRecentMaterialsByStudentId(int studentId) throws SQLException {
        List<Material> materials = new ArrayList<>();
        
        String sql = """
            SELECT TOP 10 m.material_id, m.course_id, m.title, m.description, 
                   m.file_url, m.file_type, m.material_type, m.uploaded_at,
                   c.name as course_name, c.code as course_code
            FROM course_materials m
            INNER JOIN courses c ON m.course_id = c.course_id
            INNER JOIN enrollments e ON c.course_id = e.course_id
            WHERE e.student_id = ? AND e.status = 'active' AND m.is_public = 1
            ORDER BY m.uploaded_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Material material = new Material();
                    material.setMaterialId(rs.getInt("material_id"));
                    material.setCourseId(rs.getInt("course_id"));
                    material.setTitle(rs.getString("title"));
                    material.setDescription(rs.getString("description"));
                    material.setFilePath(rs.getString("file_url"));
                    material.setFileType(rs.getString("file_type"));
                    material.setMaterialType(rs.getString("material_type"));
                    material.setUploadDate(rs.getTimestamp("uploaded_at"));
                    
                    materials.add(material);
                }
            }
        }
        
        return materials;
    }
    
    // Lấy tất cả tài liệu mà sinh viên có thể truy cập
    public List<Material> getAllMaterialsForStudent(int studentId) throws SQLException {
        List<Material> materials = new ArrayList<>();
        
        String sql = """
            SELECT m.material_id, m.course_id, m.title, m.description, 
                   m.file_url, m.file_type, m.file_size, m.material_type, 
                   m.uploaded_at, m.download_count,
                   c.name as course_name, c.code as course_code
            FROM course_materials m
            INNER JOIN courses c ON m.course_id = c.course_id
            INNER JOIN enrollments e ON c.course_id = e.course_id
            WHERE e.student_id = ? AND e.status = 'active' AND m.is_public = 1
            ORDER BY c.name, m.uploaded_at DESC
        """;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Material material = new Material();
                    material.setMaterialId(rs.getInt("material_id"));
                    material.setCourseId(rs.getInt("course_id"));
                    material.setTitle(rs.getString("title"));
                    material.setDescription(rs.getString("description"));
                    material.setFilePath(rs.getString("file_url"));
                    material.setFileType(rs.getString("file_type"));
                    material.setFileSize(rs.getLong("file_size"));
                    material.setMaterialType(rs.getString("material_type"));
                    material.setUploadDate(rs.getTimestamp("uploaded_at"));
                    material.setDownloadCount(rs.getInt("download_count"));
                    
                    materials.add(material);
                }
            }
        }
        
        return materials;
    }

    // New method to get materials by type for a student
    public List<Material> getMaterialsByTypeForStudent(int studentId, String materialType) {
        String sql = "SELECT m.* FROM Materials m "
                + "JOIN Courses c ON m.course_id = c.course_id "
                + "JOIN Enrollments e ON c.course_id = e.course_id "
                + "WHERE e.student_id = ? AND m.material_type = ? "
                + "ORDER BY m.upload_date DESC";
        List<Material> materials = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setString(2, materialType);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    materials.add(mapMaterial(rs));
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving materials by type for student", e);
        }

        return materials;
    }

    // New method to get count of materials for a student
    public int countMaterialsForStudent(int studentId) {
        String sql = "SELECT COUNT(*) FROM Materials m "
                + "JOIN Courses c ON m.course_id = c.course_id "
                + "JOIN Enrollments e ON c.course_id = e.course_id "
                + "WHERE e.student_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error counting materials for student", e);
        }

        return 0;
    }

    private Material mapMaterial(ResultSet rs) throws SQLException {
        Material material = new Material();
        material.setMaterialId(rs.getInt("material_id"));
        material.setTitle(rs.getString("title"));
        material.setDescription(rs.getString("description"));
        material.setFilePath(rs.getString("file_path"));
        material.setCourseId(rs.getInt("course_id"));
        material.setUploadDate(rs.getTimestamp("upload_date"));
        material.setUploadedBy(rs.getInt("uploaded_by"));
        material.setMaterialType(rs.getString("material_type"));

        return material;
    }
}
