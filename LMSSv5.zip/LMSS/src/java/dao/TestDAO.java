package dao;

import model.Test;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.TestSubmission;

public class TestDAO {

    private static final Logger logger = Logger.getLogger(TestDAO.class.getName());

    public TestDAO() {
    }

    public int createTest(Test test) throws SQLException {
        String sql = "INSERT INTO tests (title, description, course_id, test_type, duration_minutes, max_score, start_time, end_time, created_by, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, test.getTitle());
            pstmt.setString(2, test.getDescription());
            pstmt.setInt(3, test.getCourseId());
            pstmt.setString(4, test.getTestType());
            pstmt.setInt(5, test.getDuration_minutes());
            pstmt.setDouble(6, test.getMax_score());
            pstmt.setTimestamp(7, new Timestamp(test.getStart_time().getTime()));
            pstmt.setTimestamp(8, new Timestamp(test.getEnd_time().getTime()));
            pstmt.setInt(9, test.getCreatedBy());
            pstmt.setTimestamp(10, new Timestamp(test.getCreatedAt().getTime()));

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating test failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating test failed, no ID obtained.");
                }
            }
        }
    }

    public boolean updateTest(Test test) throws SQLException {
        String sql = "UPDATE tests SET title = ?, description = ?, course_id = ?, test_type = ?, duration_minutes = ?, max_score = ?, start_time = ?, end_time = ? WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, test.getTitle());
            stmt.setString(2, test.getDescription());
            stmt.setInt(3, test.getCourseId());
            stmt.setString(4, test.getTestType());
            stmt.setInt(5, test.getDuration_minutes());
            stmt.setDouble(6, test.getMax_score());
            stmt.setTimestamp(7, new Timestamp(test.getStart_time().getTime()));
            stmt.setTimestamp(8, new Timestamp(test.getEnd_time().getTime()));
            stmt.setInt(9, test.getTestId());

            return stmt.executeUpdate() > 0;
        }
    }

    public List<Test> getUpcomingTestsByStudentId(int studentId) {
        List<Test> tests = new ArrayList<>();
        String sql = """
        SELECT t.* FROM tests t
        JOIN courses c ON t.course_id = c.course_id
        JOIN enrollments e ON c.course_id = e.course_id
        WHERE e.student_id = ? AND t.test_date > NOW()
        ORDER BY t.test_date ASC
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Test test = new Test();
                test.setTestId(rs.getInt("test_id"));
                test.setCourseId(rs.getInt("course_id"));
                test.setTitle(rs.getString("title"));
                test.setStart_time(rs.getTimestamp("test_date"));
                tests.add(test);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tests;
    }

    public boolean deleteTest(int testId) throws SQLException {
        String sql = "DELETE FROM tests WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public Test getTestById(int testId) throws SQLException {
        String sql = "SELECT * FROM tests WHERE test_id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, testId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapTest(rs);
                }
            }
        }

        return null;
    }

    public List<Test> getTestsByCourseId(int courseId) throws SQLException {
        String sql = "SELECT * FROM tests WHERE course_id = ? ORDER BY start_time";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }

        return tests;
    }

    public List<Test> getTestsByLecturerId(int lecturerId) throws SQLException {
        String sql = "SELECT t.* FROM tests t "
                + "JOIN courses c ON t.course_id = c.course_id "
                + "WHERE c.lecturer_id = ? "
                + "ORDER BY t.start_time";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }

        return tests;
    }

    private Test mapTest(ResultSet rs) throws SQLException {
        Test test = new Test();
        test.setTestId(rs.getInt("test_id"));
        test.setTitle(rs.getString("title"));
        test.setDescription(rs.getString("description"));
        test.setCourseId(rs.getInt("course_id"));
        test.setTestType(rs.getString("test_type"));
        test.setDuration_minutes(rs.getInt("duration_minutes"));
        test.setMax_score(rs.getDouble("max_score"));
        test.setStart_time(rs.getTimestamp("start_time"));
        test.setEnd_time(rs.getTimestamp("end_time"));
        test.setCreatedBy(rs.getInt("created_by"));
        test.setCreatedAt(rs.getTimestamp("created_at"));
        return test;
    }

    public List<Test> getTestsByStudentId(int studentId, int lecturerId) throws SQLException {
        String sql = "SELECT DISTINCT t.* FROM Tests t "
                + "JOIN Courses c ON t.course_id = c.course_id "
                + "JOIN Enrollments e ON c.course_id = e.course_id "
                + "WHERE e.student_id = ? AND c.lecturer_id = ?";

        List<Test> tests = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }
        return tests;
    }

    public List<Test> getUpcomingTestsByLecturerId(int lecturerId, int i) {
        String sql = "SELECT t.* FROM Tests t "
                + "JOIN Courses c ON t.course_id = c.course_id "
                + "WHERE c.lecturer_id = ? AND t.deadline > NOW() "
                + "ORDER BY t.deadline ASC LIMIT ?, 5";
        List<Test> tests = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);
            pstmt.setInt(2, i);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error getting upcoming tests for lecturer", e);
        }

        return tests;
    }

    public int countTestsByLecturerId(int lecturerId) throws SQLException {
        String sql = """
        SELECT COUNT(*) AS total
        FROM tests t
        JOIN courses c ON t.course_id = c.course_id
        WHERE c.lecturer_id = ?
    """;

        int total = 0;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lecturerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    total = rs.getInt("total");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error in countTestsByLecturerId: " + e.getMessage());
            throw e;
        }

        return total;
    }

    public List<Test> getAvailableTestsByStudentId(int studentId) throws SQLException {
        List<Test> tests = new ArrayList<>();
        String sql = """
        SELECT DISTINCT t.*, 
               CASE WHEN ts.test_submission_id IS NOT NULL THEN 1 ELSE 0 END as has_submission,
               ts.status as submission_status
        FROM tests t
        JOIN courses c ON t.course_id = c.course_id
        JOIN enrollments e ON c.course_id = e.course_id
        LEFT JOIN test_submissions ts ON t.test_id = ts.test_id AND ts.student_id = ?
        WHERE e.student_id = ? AND e.status = 'active'
        AND (t.start_time IS NULL OR t.start_time <= GETDATE())
        AND (t.end_time IS NULL OR t.end_time >= GETDATE())
        ORDER BY t.start_time ASC
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, studentId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Test test = mapTest(rs);
                    tests.add(test);
                }
            }
        }

        return tests;
    }

// Thêm method để lấy upcoming tests cho course detail
    public List<Test> getUpcomingTestsByCourseId(int courseId) throws SQLException {
        List<Test> tests = new ArrayList<>();
        String sql = """
        SELECT * FROM tests 
        WHERE course_id = ? 
        AND (start_time IS NULL OR start_time <= GETDATE())
        AND (end_time IS NULL OR end_time >= GETDATE())
        ORDER BY start_time ASC
    """;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tests.add(mapTest(rs));
                }
            }
        }

        return tests;
    }
        // Lấy danh sách bài kiểm tra đã hoàn thành của student
    public List<Test> getCompletedTestsByStudent(int studentId) {
        List<Test> tests = new ArrayList<>();
        String sql = "SELECT DISTINCT t.test_id, t.course_id, t.title, t.description, " +
                    "t.test_type, t.duration_minutes, t.max_score, t.start_time, t.end_time, " +
                    "c.name as course_name, c.code as course_code, " +
                    "l.full_name as lecturer_name " +
                    "FROM tests t " +
                    "JOIN courses c ON t.course_id = c.course_id " +
                    "JOIN lecturers l ON c.lecturer_id = l.lecturer_id " +
                    "JOIN test_submissions ts ON t.test_id = ts.test_id " +
                    "WHERE ts.student_id = ? AND ts.status = 'submitted' " +
                    "ORDER BY t.end_time DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Test test = new Test();
                test.setTestId(rs.getInt("test_id"));
                test.setCourseId(rs.getInt("course_id"));
                test.setTitle(rs.getString("title"));
                test.setDescription(rs.getString("description"));
                test.setTestType(rs.getString("test_type"));
                test.setDuration(rs.getInt("duration_minutes"));
                test.setMaxScore(rs.getFloat("max_score"));
                test.setStartTime(rs.getTimestamp("start_time"));
                test.setEndTime(rs.getTimestamp("end_time"));
                test.setCourseName(rs.getString("course_name"));
                test.setCourseCode(rs.getString("course_code"));
                test.setLecturerName(rs.getString("lecturer_name"));
                tests.add(test);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tests;
    }
    
    // Lấy tất cả test submissions của student
    public Map<Integer, TestSubmission> getTestSubmissionsByStudent(int studentId) {
        Map<Integer, TestSubmission> submissions = new HashMap<>();
        String sql = "SELECT ts.test_submission_id, ts.test_id, ts.student_id, " +
                    "ts.started_at, ts.submitted_at, ts.score, ts.status, ts.time_spent_minutes " +
                    "FROM test_submissions ts " +
                    "WHERE ts.student_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                TestSubmission submission = new TestSubmission();
                submission.setTestSubmissionId(rs.getInt("test_submission_id"));
                submission.setTestId(rs.getInt("test_id"));
                submission.setStudentId(rs.getInt("student_id"));
                submission.setStartedAt(rs.getTimestamp("started_at"));
                submission.setSubmittedAt(rs.getTimestamp("submitted_at"));
                submission.setScore(rs.getDouble("score"));
                submission.setStatus(rs.getString("status"));
                submission.setTimeSpentMinutes(rs.getInt("time_spent_minutes"));
                
                submissions.put(submission.getTestId(), submission);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return submissions;
    }

}
