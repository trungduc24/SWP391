package model;

public class CourseDisplayModel {
    // Thông tin khóa học
    private int courseId;
    private String name;
    private String code;
    private String description;
    private String room;
    private String schedule;
    private int totalSessions;
    private int credits;
    private int maxStudents;
    private String status;
    
    // Thông tin giảng viên
    private int lecturerId;
    private String lecturerName;
    private String lecturerCode;
    private String lecturerDepartment;
    
    // Thông tin học kỳ
    private int semesterId;
    private String semesterName;
    
    // Thông tin tiến độ
    private int currentSession;
    private int progressPercentage;
    private int enrollmentId;
    private String enrollmentStatus;
    
    // Thông tin điểm số
    private Double finalGrade;
    private int enrolledStudents;
    
    // Constructor rỗng
    public CourseDisplayModel() {
    }
    
    // Constructor đầy đủ
    public CourseDisplayModel(int courseId, String name, String code, String description, 
                              String room, String schedule, int totalSessions, int credits, 
                              int maxStudents, String status, int lecturerId, String lecturerName, 
                              String lecturerCode, String lecturerDepartment, int semesterId, 
                              String semesterName, int currentSession, int progressPercentage, 
                              int enrollmentId, String enrollmentStatus, Double finalGrade, 
                              int enrolledStudents) {
        this.courseId = courseId;
        this.name = name;
        this.code = code;
        this.description = description;
        this.room = room;
        this.schedule = schedule;
        this.totalSessions = totalSessions;
        this.credits = credits;
        this.maxStudents = maxStudents;
        this.status = status;
        this.lecturerId = lecturerId;
        this.lecturerName = lecturerName;
        this.lecturerCode = lecturerCode;
        this.lecturerDepartment = lecturerDepartment;
        this.semesterId = semesterId;
        this.semesterName = semesterName;
        this.currentSession = currentSession;
        this.progressPercentage = progressPercentage;
        this.enrollmentId = enrollmentId;
        this.enrollmentStatus = enrollmentStatus;
        this.finalGrade = finalGrade;
        this.enrolledStudents = enrolledStudents;
    }
    
    // Getters and Setters
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }
    
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    
    public int getTotalSessions() { return totalSessions; }
    public void setTotalSessions(int totalSessions) { this.totalSessions = totalSessions; }
    
    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }
    
    public int getMaxStudents() { return maxStudents; }
    public void setMaxStudents(int maxStudents) { this.maxStudents = maxStudents; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public int getLecturerId() { return lecturerId; }
    public void setLecturerId(int lecturerId) { this.lecturerId = lecturerId; }
    
    public String getLecturerName() { return lecturerName; }
    public void setLecturerName(String lecturerName) { this.lecturerName = lecturerName; }
    
    public String getLecturerCode() { return lecturerCode; }
    public void setLecturerCode(String lecturerCode) { this.lecturerCode = lecturerCode; }
    
    public String getLecturerDepartment() { return lecturerDepartment; }
    public void setLecturerDepartment(String lecturerDepartment) { this.lecturerDepartment = lecturerDepartment; }
    
    public int getSemesterId() { return semesterId; }
    public void setSemesterId(int semesterId) { this.semesterId = semesterId; }
    
    public String getSemesterName() { return semesterName; }
    public void setSemesterName(String semesterName) { this.semesterName = semesterName; }
    
    public int getCurrentSession() { return currentSession; }
    public void setCurrentSession(int currentSession) { this.currentSession = currentSession; }
    
    public int getProgressPercentage() { return progressPercentage; }
    public void setProgressPercentage(int progressPercentage) { this.progressPercentage = progressPercentage; }
    
    public int getEnrollmentId() { return enrollmentId; }
    public void setEnrollmentId(int enrollmentId) { this.enrollmentId = enrollmentId; }
    
    public String getEnrollmentStatus() { return enrollmentStatus; }
    public void setEnrollmentStatus(String enrollmentStatus) { this.enrollmentStatus = enrollmentStatus; }
    
    public Double getFinalGrade() { return finalGrade; }
    public void setFinalGrade(Double finalGrade) { this.finalGrade = finalGrade; }
    
    public int getEnrolledStudents() { return enrolledStudents; }
    public void setEnrolledStudents(int enrolledStudents) { this.enrolledStudents = enrolledStudents; }
    
    // Phương thức tiện ích
    public String getStatusDisplay() {
        if (progressPercentage >= 100) {
            return "Hoàn thành";
        } else if (progressPercentage > 0) {
            return "Đang học";
        } else {
            return "Chưa bắt đầu";
        }
    }
    
    public String getProgressDisplay() {
        return currentSession + "/" + totalSessions + " buổi";
    }
    
    // Phương thức để lấy icon màu sắc theo môn học
    public String getCourseIcon() {
        String lowerName = name.toLowerCase();
        if (lowerName.contains("lập trình") || lowerName.contains("programming")) {
            return "ri-code-s-slash-line";
        } else if (lowerName.contains("cơ sở dữ liệu") || lowerName.contains("database")) {
            return "ri-database-2-line";
        } else if (lowerName.contains("mạng") || lowerName.contains("network")) {
            return "ri-global-line";
        } else if (lowerName.contains("thiết kế") || lowerName.contains("design")) {
            return "ri-pencil-ruler-2-line";
        } else if (lowerName.contains("trí tuệ") || lowerName.contains("ai")) {
            return "ri-brain-line";
        } else if (lowerName.contains("toán") || lowerName.contains("math")) {
            return "ri-calculator-line";
        } else {
            return "ri-book-open-line";
        }
    }
    
    public String getCourseColorClass() {
        String lowerName = name.toLowerCase();
        if (lowerName.contains("lập trình") || lowerName.contains("programming")) {
            return "bg-blue-100 text-blue-600";
        } else if (lowerName.contains("cơ sở dữ liệu") || lowerName.contains("database")) {
            return "bg-purple-100 text-purple-600";
        } else if (lowerName.contains("mạng") || lowerName.contains("network")) {
            return "bg-green-100 text-green-600";
        } else if (lowerName.contains("thiết kế") || lowerName.contains("design")) {
            return "bg-yellow-100 text-yellow-600";
        } else if (lowerName.contains("trí tuệ") || lowerName.contains("ai")) {
            return "bg-red-100 text-red-600";
        } else if (lowerName.contains("toán") || lowerName.contains("math")) {
            return "bg-indigo-100 text-indigo-600";
        } else {
            return "bg-gray-100 text-gray-600";
        }
    }
}