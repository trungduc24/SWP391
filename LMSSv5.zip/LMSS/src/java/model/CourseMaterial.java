package model;

import java.time.LocalDateTime; // Sử dụng LocalDateTime cho created_at

public class CourseMaterial {
    private int materialId;
    private int courseId;
    private String title;
    private String description;
    private String fileUrl;
    private LocalDateTime uploadedAt; // Kiểu dữ liệu phù hợp với DATETIME trong SQL Server

    // Constructor đầy đủ
    public CourseMaterial(int materialId, int courseId, String title, String description, String fileUrl, LocalDateTime uploadedAt) {
        this.materialId = materialId;
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.fileUrl = fileUrl;
        this.uploadedAt = uploadedAt;
    }

    // Constructor cho việc thêm mới (materialId và uploadedAt sẽ được DB tạo)
    public CourseMaterial(int courseId, String title, String description, String fileUrl) {
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.fileUrl = fileUrl;
        this.uploadedAt = null; // Sẽ được DB tự động tạo (GETDATE())
    }

    // Getters
    public int getMaterialId() {
        return materialId;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }

    // Setters
    public void setMaterialId(int materialId) {
        this.materialId = materialId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public void setUploadedAt(LocalDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }
}