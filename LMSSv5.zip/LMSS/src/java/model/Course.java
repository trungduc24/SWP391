package model;

import java.sql.Timestamp;

public class Course {
    private int courseId;
    private String name;
    private String code;
    private String description;
    private String room;
    private int lecturerId;
    private int semesterId;
    private int totalSessions;
    private int credits;
    private int maxStudents;
    private String schedule;
    private boolean isActive;
    private Timestamp createdAt;

    // Constructor rỗng
    public Course() {
    }

    // Constructor đầy đủ với courseId (dùng khi đọc từ DB)
    public Course(int courseId, String name, String code, String room, int lecturerId, int semesterId,
            int totalSessions) {
        this.courseId = courseId;
        this.name = name;
        this.code = code;
        this.room = room;
        this.lecturerId = lecturerId;
        this.semesterId = semesterId;
        this.totalSessions = totalSessions;
        this.credits = 3; // default
        this.maxStudents = 50; // default
        this.isActive = true; // default
    }

    // Constructor KHÔNG CÓ courseId (dùng khi tạo course mới từ form)
    public Course(String name, String code, String room, int lecturerId, int semesterId, int totalSessions) {
        this.name = name;
        this.code = code;
        this.room = room;
        this.lecturerId = lecturerId;
        this.semesterId = semesterId;
        this.totalSessions = totalSessions;
        this.credits = 3; // default
        this.maxStudents = 50; // default
        this.isActive = true; // default
    }

    // Constructor mới với đầy đủ thông tin (không có courseId)
    public Course(String name, String code, String description, String room, int lecturerId, int semesterId,
            int totalSessions, int credits, int maxStudents) {
        this.name = name;
        this.code = code;
        this.description = description;
        this.room = room;
        this.lecturerId = lecturerId;
        this.semesterId = semesterId;
        this.totalSessions = totalSessions;
        this.credits = credits;
        this.maxStudents = maxStudents;
        this.isActive = true; // default
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }

    public void setTotalSessions(int totalSessions) {
        this.totalSessions = totalSessions;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getRoom() {
        return room;
    }

    public int getLecturerId() {
        return lecturerId;
    }

    public int getSemesterId() {
        return semesterId;
    }

    public int getTotalSessions() {
        return totalSessions;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public int getMaxStudents() {
        return maxStudents;
    }

    public void setMaxStudents(int maxStudents) {
        this.maxStudents = maxStudents;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }
}