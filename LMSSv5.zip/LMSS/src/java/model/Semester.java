package model;

import java.sql.Date;
import java.sql.Timestamp;

public class Semester {
    private int semesterId;
    private String name;
    private String code;
    private Date startDate;
    private Date endDate;
    private boolean isActive;
    private Timestamp createdAt;

    // Constructor đầy đủ
    public Semester(int semesterId, String name, String code, Date startDate, Date endDate, boolean isActive,
            Timestamp createdAt) {
        this.semesterId = semesterId;
        this.name = name;
        this.code = code;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isActive = isActive;
        this.createdAt = createdAt;
    }

    // Constructor đầy đủ không có ID (để tạo mới)
    public Semester(String name, String code, Date startDate, Date endDate, boolean isActive) {
        this.name = name;
        this.code = code;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isActive = isActive;
    }

    // Constructor không có ID (để tạo mới)
    public Semester(String name, Date startDate, Date endDate) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isActive = true; // mặc định active
    }

    // Constructor mặc định
    public Semester() {
    }

    // Getters and Setters
    public int getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Semester{" +
                "semesterId=" + semesterId +
                ", name='" + name + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", isActive=" + isActive +
                ", createdAt=" + createdAt +
                '}';
    }
}
