package model;

import java.util.List;

public class Student {

    private int studentId;
    private int userId;
    private String fullName;
    private String studentCode;
    private String email;
    private String avatarUrl;

    // Mở rộng (không bắt buộc, dùng nếu cần trong JSP)
    private List<Grade> grades;
    private List<Attendance> attendanceList;

    public Student() {
    }

    public Student(int studentId, int userId, String fullName, String studentCode, String email, String avatarUrl) {
        this.studentId = studentId;
        this.userId = userId;
        this.fullName = fullName;
        this.studentCode = studentCode;
        this.email = email;
        this.avatarUrl = avatarUrl;
    }

    // Getters và Setters cho các trường cơ bản
    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    // Getters & setters mở rộng
    public List<Grade> getGrades() {
        return grades;
    }

    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }

    public List<Attendance> getAttendanceList() {
        return attendanceList;
    }

    public void setAttendanceList(List<Attendance> attendanceList) {
        this.attendanceList = attendanceList;
    }
}
